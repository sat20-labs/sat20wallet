var content = function() {
  "use strict";var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});

  var _a, _b, _port, _connected, _portName, _reconnectAttempts, _maxReconnectAttempts, _reconnectDelay, _onConnectCallback, _Port_instances, createPort_fn, handleReconnect_fn, _port2, _timer, _origin, _isConnected, _reconnectAttempts2, _currentReconnectDelay, _reconnectTimer, _KeepAliveConnection_instances, handleDisconnect_fn, cleanup_fn, startHeartbeat_fn, sendHeartbeat_fn;
  function defineContentScript(definition2) {
    return definition2;
  }
  const browser = (
    // @ts-expect-error
    ((_b = (_a = globalThis.browser) == null ? void 0 : _a.runtime) == null ? void 0 : _b.id) == null ? globalThis.chrome : (
      // @ts-expect-error
      globalThis.browser
    )
  );
  function print$1(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger$1 = {
    debug: (...args) => print$1(console.debug, ...args),
    log: (...args) => print$1(console.log, ...args),
    warn: (...args) => print$1(console.warn, ...args),
    error: (...args) => print$1(console.error, ...args)
  };
  const _WxtLocationChangeEvent = class _WxtLocationChangeEvent extends Event {
    constructor(newUrl, oldUrl) {
      super(_WxtLocationChangeEvent.EVENT_NAME, {});
      this.newUrl = newUrl;
      this.oldUrl = oldUrl;
    }
  };
  __publicField(_WxtLocationChangeEvent, "EVENT_NAME", getUniqueEventName("wxt:locationchange"));
  let WxtLocationChangeEvent = _WxtLocationChangeEvent;
  function getUniqueEventName(eventName) {
    var _a2;
    return `${(_a2 = browser == null ? void 0 : browser.runtime) == null ? void 0 : _a2.id}:${"content"}:${eventName}`;
  }
  function createLocationWatcher(ctx) {
    let interval;
    let oldUrl;
    return {
      /**
       * Ensure the location watcher is actively looking for URL changes. If it's already watching,
       * this is a noop.
       */
      run() {
        if (interval != null) return;
        oldUrl = new URL(location.href);
        interval = ctx.setInterval(() => {
          let newUrl = new URL(location.href);
          if (newUrl.href !== oldUrl.href) {
            window.dispatchEvent(new WxtLocationChangeEvent(newUrl, oldUrl));
            oldUrl = newUrl;
          }
        }, 1e3);
      }
    };
  }
  const _ContentScriptContext = class _ContentScriptContext {
    constructor(contentScriptName, options) {
      __publicField(this, "isTopFrame", window.self === window.top);
      __publicField(this, "abortController");
      __publicField(this, "locationWatcher", createLocationWatcher(this));
      __publicField(this, "receivedMessageIds", /* @__PURE__ */ new Set());
      this.contentScriptName = contentScriptName;
      this.options = options;
      this.abortController = new AbortController();
      if (this.isTopFrame) {
        this.listenForNewerScripts({ ignoreFirstEvent: true });
        this.stopOldScripts();
      } else {
        this.listenForNewerScripts();
      }
    }
    get signal() {
      return this.abortController.signal;
    }
    abort(reason) {
      return this.abortController.abort(reason);
    }
    get isInvalid() {
      if (browser.runtime.id == null) {
        this.notifyInvalidated();
      }
      return this.signal.aborted;
    }
    get isValid() {
      return !this.isInvalid;
    }
    /**
     * Add a listener that is called when the content script's context is invalidated.
     *
     * @returns A function to remove the listener.
     *
     * @example
     * browser.runtime.onMessage.addListener(cb);
     * const removeInvalidatedListener = ctx.onInvalidated(() => {
     *   browser.runtime.onMessage.removeListener(cb);
     * })
     * // ...
     * removeInvalidatedListener();
     */
    onInvalidated(cb) {
      this.signal.addEventListener("abort", cb);
      return () => this.signal.removeEventListener("abort", cb);
    }
    /**
     * Return a promise that never resolves. Useful if you have an async function that shouldn't run
     * after the context is expired.
     *
     * @example
     * const getValueFromStorage = async () => {
     *   if (ctx.isInvalid) return ctx.block();
     *
     *   // ...
     * }
     */
    block() {
      return new Promise(() => {
      });
    }
    /**
     * Wrapper around `window.setInterval` that automatically clears the interval when invalidated.
     */
    setInterval(handler, timeout) {
      const id = setInterval(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearInterval(id));
      return id;
    }
    /**
     * Wrapper around `window.setTimeout` that automatically clears the interval when invalidated.
     */
    setTimeout(handler, timeout) {
      const id = setTimeout(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearTimeout(id));
      return id;
    }
    /**
     * Wrapper around `window.requestAnimationFrame` that automatically cancels the request when
     * invalidated.
     */
    requestAnimationFrame(callback) {
      const id = requestAnimationFrame((...args) => {
        if (this.isValid) callback(...args);
      });
      this.onInvalidated(() => cancelAnimationFrame(id));
      return id;
    }
    /**
     * Wrapper around `window.requestIdleCallback` that automatically cancels the request when
     * invalidated.
     */
    requestIdleCallback(callback, options) {
      const id = requestIdleCallback((...args) => {
        if (!this.signal.aborted) callback(...args);
      }, options);
      this.onInvalidated(() => cancelIdleCallback(id));
      return id;
    }
    addEventListener(target, type, handler, options) {
      var _a2;
      if (type === "wxt:locationchange") {
        if (this.isValid) this.locationWatcher.run();
      }
      (_a2 = target.addEventListener) == null ? void 0 : _a2.call(
        target,
        type.startsWith("wxt:") ? getUniqueEventName(type) : type,
        handler,
        {
          ...options,
          signal: this.signal
        }
      );
    }
    /**
     * @internal
     * Abort the abort controller and execute all `onInvalidated` listeners.
     */
    notifyInvalidated() {
      this.abort("Content script context invalidated");
      logger$1.debug(
        `Content script "${this.contentScriptName}" context invalidated`
      );
    }
    stopOldScripts() {
      window.postMessage(
        {
          type: _ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE,
          contentScriptName: this.contentScriptName,
          messageId: Math.random().toString(36).slice(2)
        },
        "*"
      );
    }
    verifyScriptStartedEvent(event) {
      var _a2, _b2, _c;
      const isScriptStartedEvent = ((_a2 = event.data) == null ? void 0 : _a2.type) === _ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE;
      const isSameContentScript = ((_b2 = event.data) == null ? void 0 : _b2.contentScriptName) === this.contentScriptName;
      const isNotDuplicate = !this.receivedMessageIds.has((_c = event.data) == null ? void 0 : _c.messageId);
      return isScriptStartedEvent && isSameContentScript && isNotDuplicate;
    }
    listenForNewerScripts(options) {
      let isFirst = true;
      const cb = (event) => {
        if (this.verifyScriptStartedEvent(event)) {
          this.receivedMessageIds.add(event.data.messageId);
          const wasFirst = isFirst;
          isFirst = false;
          if (wasFirst && (options == null ? void 0 : options.ignoreFirstEvent)) return;
          this.notifyInvalidated();
        }
      };
      addEventListener("message", cb);
      this.onInvalidated(() => removeEventListener("message", cb));
    }
  };
  __publicField(_ContentScriptContext, "SCRIPT_STARTED_MESSAGE_TYPE", getUniqueEventName(
    "wxt:content-script-started"
  ));
  let ContentScriptContext = _ContentScriptContext;
  const nullKey = Symbol("null");
  let keyCounter = 0;
  class ManyKeysMap extends Map {
    constructor() {
      super();
      this._objectHashes = /* @__PURE__ */ new WeakMap();
      this._symbolHashes = /* @__PURE__ */ new Map();
      this._publicKeys = /* @__PURE__ */ new Map();
      const [pairs] = arguments;
      if (pairs === null || pairs === void 0) {
        return;
      }
      if (typeof pairs[Symbol.iterator] !== "function") {
        throw new TypeError(typeof pairs + " is not iterable (cannot read property Symbol(Symbol.iterator))");
      }
      for (const [keys, value] of pairs) {
        this.set(keys, value);
      }
    }
    _getPublicKeys(keys, create = false) {
      if (!Array.isArray(keys)) {
        throw new TypeError("The keys parameter must be an array");
      }
      const privateKey = this._getPrivateKey(keys, create);
      let publicKey;
      if (privateKey && this._publicKeys.has(privateKey)) {
        publicKey = this._publicKeys.get(privateKey);
      } else if (create) {
        publicKey = [...keys];
        this._publicKeys.set(privateKey, publicKey);
      }
      return { privateKey, publicKey };
    }
    _getPrivateKey(keys, create = false) {
      const privateKeys = [];
      for (let key of keys) {
        if (key === null) {
          key = nullKey;
        }
        const hashes = typeof key === "object" || typeof key === "function" ? "_objectHashes" : typeof key === "symbol" ? "_symbolHashes" : false;
        if (!hashes) {
          privateKeys.push(key);
        } else if (this[hashes].has(key)) {
          privateKeys.push(this[hashes].get(key));
        } else if (create) {
          const privateKey = `@@mkm-ref-${keyCounter++}@@`;
          this[hashes].set(key, privateKey);
          privateKeys.push(privateKey);
        } else {
          return false;
        }
      }
      return JSON.stringify(privateKeys);
    }
    set(keys, value) {
      const { publicKey } = this._getPublicKeys(keys, true);
      return super.set(publicKey, value);
    }
    get(keys) {
      const { publicKey } = this._getPublicKeys(keys);
      return super.get(publicKey);
    }
    has(keys) {
      const { publicKey } = this._getPublicKeys(keys);
      return super.has(publicKey);
    }
    delete(keys) {
      const { publicKey, privateKey } = this._getPublicKeys(keys);
      return Boolean(publicKey && super.delete(publicKey) && this._publicKeys.delete(privateKey));
    }
    clear() {
      super.clear();
      this._symbolHashes.clear();
      this._publicKeys.clear();
    }
    get [Symbol.toStringTag]() {
      return "ManyKeysMap";
    }
    get size() {
      return super.size;
    }
  }
  new ManyKeysMap();
  async function injectScript(path, options) {
    const url = browser.runtime.getURL(path);
    const script = document.createElement("script");
    if (browser.runtime.getManifest().manifest_version === 2) {
      script.innerHTML = await fetch(url).then((res) => res.text());
    } else {
      script.src = url;
    }
    (document.head ?? document.documentElement).append(script);
  }
  class Port {
    constructor(connectInfo, opts) {
      __privateAdd(this, _Port_instances);
      __privateAdd(this, _port);
      __privateAdd(this, _connected, false);
      __privateAdd(this, _portName);
      __privateAdd(this, _reconnectAttempts, 0);
      __privateAdd(this, _maxReconnectAttempts, 5);
      __privateAdd(this, _reconnectDelay, 1e3);
      __privateAdd(this, _onConnectCallback);
      if (!connectInfo.name) {
        throw new Error("port name is required");
      }
      __privateSet(this, _portName, connectInfo.name);
      __privateSet(this, _onConnectCallback, (opts == null ? void 0 : opts.onConnect) ?? (() => {
      }));
      __privateSet(this, _maxReconnectAttempts, (opts == null ? void 0 : opts.maxReconnectAttempts) ?? 5);
      __privateSet(this, _reconnectDelay, (opts == null ? void 0 : opts.reconnectDelay) ?? 1e3);
      __privateSet(this, _port, __privateMethod(this, _Port_instances, createPort_fn).call(this));
    }
    async postMessage(message) {
      if (!__privateGet(this, _connected)) {
        console.debug("postMessage: chrome port not connected, attempting to reconnect");
        try {
          __privateSet(this, _port, __privateMethod(this, _Port_instances, createPort_fn).call(this));
        } catch (error) {
          console.error("Failed to reconnect port during postMessage:", error);
          throw new Error("Failed to send message: port disconnected");
        }
      }
      try {
        __privateGet(this, _port).postMessage(message);
      } catch (error) {
        console.error("Failed to post message:", error);
        __privateSet(this, _connected, false);
        __privateMethod(this, _Port_instances, handleReconnect_fn).call(this);
        throw error;
      }
    }
    disconnect() {
      if (__privateGet(this, _connected)) {
        __privateGet(this, _port).disconnect();
        __privateSet(this, _connected, false);
      }
    }
    get connected() {
      return __privateGet(this, _connected);
    }
    get sender() {
      return __privateGet(this, _port).sender;
    }
    get onDisconnect() {
      return __privateGet(this, _port).onDisconnect;
    }
    get onMessage() {
      return __privateGet(this, _port).onMessage;
    }
    get name() {
      return __privateGet(this, _port).name;
    }
  }
  _port = new WeakMap();
  _connected = new WeakMap();
  _portName = new WeakMap();
  _reconnectAttempts = new WeakMap();
  _maxReconnectAttempts = new WeakMap();
  _reconnectDelay = new WeakMap();
  _onConnectCallback = new WeakMap();
  _Port_instances = new WeakSet();
  createPort_fn = function() {
    try {
      const newPort = chrome.runtime.connect({
        name: __privateGet(this, _portName)
      });
      __privateSet(this, _connected, true);
      __privateSet(this, _reconnectAttempts, 0);
      console.log(`chrome port ${__privateGet(this, _portName)} connected`);
      newPort.onDisconnect.addListener(() => {
        var _a2;
        const lastError = chrome.runtime.lastError;
        __privateSet(this, _connected, false);
        console.log(`chrome port ${__privateGet(this, _portName)} disconnected`, lastError == null ? void 0 : lastError.message);
        if ((_a2 = lastError == null ? void 0 : lastError.message) == null ? void 0 : _a2.includes("back/forward cache")) {
          console.log("Port disconnected due to bfcache, will wait for page restore");
          return;
        }
        __privateMethod(this, _Port_instances, handleReconnect_fn).call(this);
      });
      __privateGet(this, _onConnectCallback).call(this, newPort);
      return newPort;
    } catch (error) {
      console.error(`Failed to create port ${__privateGet(this, _portName)}:`, error);
      __privateSet(this, _connected, false);
      __privateMethod(this, _Port_instances, handleReconnect_fn).call(this);
      throw error;
    }
  };
  handleReconnect_fn = function() {
    if (__privateGet(this, _reconnectAttempts) >= __privateGet(this, _maxReconnectAttempts)) {
      console.error(`Max reconnection attempts (${__privateGet(this, _maxReconnectAttempts)}) reached for port ${__privateGet(this, _portName)}`);
      return;
    }
    __privateWrapper(this, _reconnectAttempts)._++;
    console.log(`Attempting to reconnect port ${__privateGet(this, _portName)} (attempt ${__privateGet(this, _reconnectAttempts)}/${__privateGet(this, _maxReconnectAttempts)})`);
    setTimeout(() => {
      try {
        __privateSet(this, _port, __privateMethod(this, _Port_instances, createPort_fn).call(this));
      } catch (error) {
        console.error(`Reconnection attempt ${__privateGet(this, _reconnectAttempts)} failed:`, error);
      }
    }, __privateGet(this, _reconnectDelay) * __privateGet(this, _reconnectAttempts));
  };
  content;
  const _KeepAliveConnection = class _KeepAliveConnection {
    constructor(origin) {
      __privateAdd(this, _KeepAliveConnection_instances);
      // 私有属性
      __privateAdd(this, _port2, null);
      __privateAdd(this, _timer, null);
      __privateAdd(this, _origin, "UNKNOWN");
      __privateAdd(this, _isConnected, false);
      __privateAdd(this, _reconnectAttempts2, 0);
      __privateAdd(this, _currentReconnectDelay, _KeepAliveConnection.INITIAL_RECONNECT_DELAY);
      __privateAdd(this, _reconnectTimer, null);
      __privateSet(this, _origin, origin);
    }
    /**
     * Workaround to avoid service-worker be killed by Chrome
     * https://stackoverflow.com/questions/66618136/persistent-service-worker-in-chrome-extension
     */
    connect() {
      if (__privateGet(this, _isConnected)) {
        console.log("Already connected, skipping connection attempt");
        return;
      }
      try {
        const newPort = new Port({ name: "KEEP_ALIVE_INTERVAL" });
        newPort.onDisconnect.addListener(() => {
          console.log(`Keep alive connection disconnected from ${__privateGet(this, _origin)}`);
          __privateMethod(this, _KeepAliveConnection_instances, handleDisconnect_fn).call(this);
        });
        __privateSet(this, _port2, newPort);
        __privateSet(this, _isConnected, true);
        __privateSet(this, _reconnectAttempts2, 0);
        __privateSet(this, _currentReconnectDelay, _KeepAliveConnection.INITIAL_RECONNECT_DELAY);
        __privateMethod(this, _KeepAliveConnection_instances, startHeartbeat_fn).call(this);
        console.log(`Keep alive connection established for ${__privateGet(this, _origin)}`);
      } catch (error) {
        console.error("Failed to establish keep alive connection:", error);
        __privateMethod(this, _KeepAliveConnection_instances, handleDisconnect_fn).call(this);
      }
    }
    /**
     * 主动断开连接
     */
    disconnect() {
      console.log(`Manually disconnecting keep alive connection for ${__privateGet(this, _origin)}`);
      __privateMethod(this, _KeepAliveConnection_instances, cleanup_fn).call(this);
      if (__privateGet(this, _reconnectTimer)) {
        clearTimeout(__privateGet(this, _reconnectTimer));
        __privateSet(this, _reconnectTimer, null);
      }
      __privateSet(this, _reconnectAttempts2, 0);
      __privateSet(this, _currentReconnectDelay, _KeepAliveConnection.INITIAL_RECONNECT_DELAY);
    }
  };
  _port2 = new WeakMap();
  _timer = new WeakMap();
  _origin = new WeakMap();
  _isConnected = new WeakMap();
  _reconnectAttempts2 = new WeakMap();
  _currentReconnectDelay = new WeakMap();
  _reconnectTimer = new WeakMap();
  _KeepAliveConnection_instances = new WeakSet();
  /**
   * 处理断开连接的情况
   */
  handleDisconnect_fn = function() {
    __privateMethod(this, _KeepAliveConnection_instances, cleanup_fn).call(this);
    if (__privateGet(this, _reconnectAttempts2) >= _KeepAliveConnection.MAX_RECONNECT_ATTEMPTS) {
      console.log(`Max reconnection attempts (${_KeepAliveConnection.MAX_RECONNECT_ATTEMPTS}) reached, stopping reconnection`);
      return;
    }
    __privateSet(this, _currentReconnectDelay, Math.min(
      __privateGet(this, _currentReconnectDelay) * 2,
      _KeepAliveConnection.MAX_RECONNECT_DELAY
    ));
    console.log(`Scheduling reconnection attempt ${__privateGet(this, _reconnectAttempts2) + 1} in ${__privateGet(this, _currentReconnectDelay)}ms`);
    if (__privateGet(this, _reconnectTimer)) {
      clearTimeout(__privateGet(this, _reconnectTimer));
    }
    __privateSet(this, _reconnectTimer, setTimeout(() => {
      __privateWrapper(this, _reconnectAttempts2)._++;
      this.connect();
    }, __privateGet(this, _currentReconnectDelay)));
  };
  /**
   * 清理当前连接的资源
   */
  cleanup_fn = function() {
    __privateSet(this, _isConnected, false);
    if (__privateGet(this, _timer)) {
      clearInterval(__privateGet(this, _timer));
      __privateSet(this, _timer, null);
    }
    if (__privateGet(this, _port2)) {
      try {
        __privateGet(this, _port2).disconnect();
      } catch (e) {
      }
      __privateSet(this, _port2, null);
    }
  };
  /**
   * 启动心跳机制
   */
  startHeartbeat_fn = function() {
    if (__privateGet(this, _timer)) {
      clearInterval(__privateGet(this, _timer));
    }
    __privateSet(this, _timer, setInterval(() => {
      __privateMethod(this, _KeepAliveConnection_instances, sendHeartbeat_fn).call(this);
    }, _KeepAliveConnection.KEEP_ALIVE_INTERVAL));
  };
  /**
   * 发送心跳包
   */
  sendHeartbeat_fn = function() {
    if (!__privateGet(this, _port2) || !__privateGet(this, _isConnected)) {
      console.log("Cannot send heartbeat: connection not established");
      return;
    }
    try {
      __privateGet(this, _port2).postMessage({
        type: "KEEP_ALIVE",
        origin: __privateGet(this, _origin),
        payload: "PING",
        timestamp: Date.now()
        // 添加时间戳以便调试
      });
    } catch (error) {
      console.error("Failed to send heartbeat:", error);
      __privateMethod(this, _KeepAliveConnection_instances, handleDisconnect_fn).call(this);
    }
  };
  // 配置常量
  __publicField(_KeepAliveConnection, "KEEP_ALIVE_INTERVAL", 5e3);
  // 增加到5秒
  __publicField(_KeepAliveConnection, "MAX_RECONNECT_ATTEMPTS", 5);
  __publicField(_KeepAliveConnection, "INITIAL_RECONNECT_DELAY", 1e3);
  __publicField(_KeepAliveConnection, "MAX_RECONNECT_DELAY", 3e4);
  let KeepAliveConnection = _KeepAliveConnection;
  content;
  var Message;
  ((Message2) => {
    ((Channel2) => {
      Channel2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Channel2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Channel || (Message2.Channel = {}));
    ((Port2) => {
      Port2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Port2["CONTENT_BG"] = "CONTENT_BG";
      Port2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Port || (Message2.Port = {}));
    ((MessageType2) => {
      MessageType2["REQUEST"] = "REQUEST";
      MessageType2["APPROVE"] = "APPROVE";
      MessageType2["EVENT"] = "EVENT";
      MessageType2["CONNECTION_READY"] = "CONNECTION_READY";
    })(Message2.MessageType || (Message2.MessageType = {}));
    ((MessageFrom2) => {
      MessageFrom2["INJECTED"] = "INJECTED";
      MessageFrom2["CONTENT"] = "CONTENT";
      MessageFrom2["BACKGROUND"] = "BACKGROUND";
      MessageFrom2["POPUP"] = "POPUP";
      MessageFrom2["SETTINGS_PAGE"] = "settings_page";
    })(Message2.MessageFrom || (Message2.MessageFrom = {}));
    ((MessageTo2) => {
      MessageTo2["INJECTED"] = "INJECTED";
      MessageTo2["CONTENT"] = "CONTENT";
      MessageTo2["BACKGROUND"] = "BACKGROUND";
      MessageTo2["POPUP"] = "POPUP";
    })(Message2.MessageTo || (Message2.MessageTo = {}));
    ((MessageAction2) => {
      MessageAction2["GET_APPROVE_DATA"] = "GET_APPROVE_DATA";
      MessageAction2["GET_APPROVE_DATA_RESPONSE"] = "GET_APPROVE_DATA_RESPONSE";
      MessageAction2["APPROVE_RESPONSE"] = "APPROVE_RESPONSE";
      MessageAction2["REJECT_RESPONSE"] = "REJECT_RESPONSE";
      MessageAction2["REQUEST_ACCOUNTS"] = "REQUEST_ACCOUNTS";
      MessageAction2["GET_ACCOUNTS"] = "GET_ACCOUNTS";
      MessageAction2["GET_NETWORK"] = "GET_NETWORK";
      MessageAction2["SWITCH_NETWORK"] = "SWITCH_NETWORK";
      MessageAction2["GET_PUBLIC_KEY"] = "GET_PUBLIC_KEY";
      MessageAction2["BUILD_BATCH_SELL_ORDER"] = "BUILD_BATCH_SELL_ORDER";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT"] = "SPLIT_BATCH_SIGNED_PSBT";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT_SATSNET"] = "SPLIT_BATCH_SIGNED_PSBT_SATSNET";
      MessageAction2["GET_BALANCE"] = "GET_BALANCE";
      MessageAction2["SEND_BITCOIN"] = "SEND_BITCOIN";
      MessageAction2["SIGN_MESSAGE"] = "SIGN_MESSAGE";
      MessageAction2["SIGN_PSBT"] = "SIGN_PSBT";
      MessageAction2["SIGN_PSBTS"] = "SIGN_PSBTS";
      MessageAction2["PUSH_TX"] = "PUSH_TX";
      MessageAction2["PUSH_PSBT"] = "PUSH_PSBT";
      MessageAction2["GET_INSCRIPTIONS"] = "GET_INSCRIPTIONS";
      MessageAction2["SEND_INSCRIPTION"] = "SEND_INSCRIPTION";
      MessageAction2["FINALIZE_SELL_ORDER"] = "FINALIZE_SELL_ORDER";
      MessageAction2["MERGE_BATCH_SIGNED_PSBT"] = "MERGE_BATCH_SIGNED_PSBT";
      MessageAction2["ADD_INPUTS_TO_PSBT"] = "ADD_INPUTS_TO_PSBT";
      MessageAction2["ADD_OUTPUTS_TO_PSBT"] = "ADD_OUTPUTS_TO_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT"] = "EXTRACT_TX_FROM_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT_SATSNET"] = "EXTRACT_TX_FROM_PSBT_SATSNET";
      MessageAction2["BACKGROUND_MESSAGE"] = "BACKGROUND_MESSAGE";
      MessageAction2["BACKGROUND_RECONNECT"] = "BACKGROUND_RECONNECT";
      MessageAction2["EVENT_MESSAGE"] = "EVENT_MESSAGE";
      MessageAction2["CONNECTION_CHECK"] = "CONNECTION_CHECK";
      MessageAction2["SPLIT_ASSET"] = "SPLIT_ASSET";
      MessageAction2["BATCH_SEND_ASSETS_SATSNET"] = "BATCH_SEND_ASSETS_SATSNET";
      MessageAction2["LOCK_UTXO"] = "LOCK_UTXO";
      MessageAction2["LOCK_UTXO_SATSNET"] = "LOCK_UTXO_SATSNET";
      MessageAction2["UNLOCK_UTXO"] = "UNLOCK_UTXO";
      MessageAction2["UNLOCK_UTXO_SATSNET"] = "UNLOCK_UTXO_SATSNET";
      MessageAction2["GET_ALL_LOCKED_UTXO"] = "GET_ALL_LOCKED_UTXO";
      MessageAction2["GET_ALL_LOCKED_UTXO_SATSNET"] = "GET_ALL_LOCKED_UTXO_SATSNET";
      MessageAction2["LOCK_TO_CHANNEL"] = "LOCK_TO_CHANNEL";
      MessageAction2["UNLOCK_FROM_CHANNEL"] = "UNLOCK_FROM_CHANNEL";
      MessageAction2["GET_UTXOS"] = "GET_UTXOS";
      MessageAction2["GET_UTXOS_SATSNET"] = "GET_UTXOS_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET"] = "GET_UTXOS_WITH_ASSET";
      MessageAction2["GET_UTXOS_WITH_ASSET_SATSNET"] = "GET_UTXOS_WITH_ASSET_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2"] = "GET_UTXOS_WITH_ASSET_V2";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2_SATSNET"] = "GET_UTXOS_WITH_ASSET_V2_SATSNET";
      MessageAction2["GET_ASSET_AMOUNT"] = "GET_ASSET_AMOUNT";
      MessageAction2["GET_ASSET_AMOUNT_SATSNET"] = "GET_ASSET_AMOUNT_SATSNET";
      MessageAction2["ENV_CHANGED"] = "ENV_CHANGED";
      MessageAction2["GET_TICKER_INFO"] = "GET_TICKER_INFO";
    })(Message2.MessageAction || (Message2.MessageAction = {}));
  })(Message || (Message = {}));
  content;
  const definition = defineContentScript({
    matches: ["*://*/*"],
    async main() {
      console.log("Hello content script! 12");
      let keepAlive = null;
      let port = null;
      let channel = null;
      let isExtensionValid = true;
      const handleExtensionInvalidation = () => {
        console.log("Extension context invalidated, cleaning up...");
        isExtensionValid = false;
        cleanup();
      };
      const cleanup = () => {
        if (channel) {
          channel.close();
          channel = null;
        }
        if (port) {
          try {
            port.disconnect();
          } catch (e) {
            console.warn("Error during port cleanup:", e);
          }
          port = null;
        }
        if (keepAlive) {
          try {
            keepAlive.disconnect();
          } catch (e) {
            console.warn("Error during keepAlive cleanup:", e);
          }
          keepAlive = null;
        }
      };
      const initializeConnection = async () => {
        try {
          if (!isExtensionValid) {
            console.warn("Extension context is invalid, skipping connection initialization");
            return;
          }
          await injectScript("/injected.js", {
            keepInDom: true
          });
          if (!keepAlive) {
            keepAlive = new KeepAliveConnection("CONTENT_SCRIPT");
            keepAlive.connect();
          }
          if (!port) {
            console.log("初始化端口");
            console.log(Port);
            port = new Port({
              name: Message.Port.CONTENT_BG
            });
            port.onMessage.addListener(async (event) => {
              if (!isExtensionValid) {
                console.warn("Extension context is invalid, ignoring port message");
                return;
              }
              console.log("Content 收到 BACKGROUND 消息:", event);
              const { metadata = {} } = event;
              const { to, from } = metadata;
              if (from === Message.MessageFrom.BACKGROUND && to === Message.MessageTo.INJECTED) {
                channel == null ? void 0 : channel.postMessage(event);
              }
            });
            port.onDisconnect.addListener(() => {
              console.log("Port disconnected, checking extension context...");
              const error = browser.runtime.lastError;
              if (error && typeof error === "object" && "message" in error && typeof error.message === "string" && error.message.includes("Extension context invalidated")) {
                handleExtensionInvalidation();
              } else {
                cleanup();
                setTimeout(initializeConnection, 2e3);
              }
            });
          }
          if (!channel) {
            channel = new BroadcastChannel(Message.Channel.INJECT_CONTENT);
          }
          console.log("Connection initialization completed");
        } catch (error) {
          console.error("Failed to initialize connection:", error);
          if (error instanceof Error && error.message.includes("Extension context invalidated")) {
            handleExtensionInvalidation();
          } else {
            cleanup();
            setTimeout(initializeConnection, 2e3);
          }
        }
      };
      const sendToBackground = async (data) => {
        if (!isExtensionValid) {
          console.warn("Extension context is invalid, cannot send message");
          return;
        }
        if (!port) {
          console.warn("Port not available, attempting to reinitialize connection");
          await initializeConnection();
          if (!port) {
            console.error("Failed to establish port connection");
            return;
          }
        }
        try {
          console.log(port);
          await port.postMessage(data);
          console.log("Content 发送 BACKGROUND 消息成功:", data);
        } catch (error) {
          console.error("Failed to send message to background:", error);
          if (error instanceof Error && error.message.includes("Extension context invalidated")) {
            handleExtensionInvalidation();
          } else {
            await initializeConnection();
          }
        }
      };
      await initializeConnection();
      if (browser.runtime.onMessage) {
        browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
          isExtensionValid = true;
          return void 0;
        });
      }
      window.addEventListener("message", async (event) => {
        if (!isExtensionValid) {
          console.warn("Extension context is invalid, ignoring message");
          return;
        }
        const eventData = event.data;
        const { metadata = {} } = eventData;
        const { to, from } = metadata;
        if (event.source !== window) return;
        if (from === Message.MessageTo.INJECTED) {
          console.log("Content 收到 INJECTED 消息:", event.data);
          eventData.metadata.from = Message.MessageFrom.CONTENT;
          if (to === Message.MessageTo.BACKGROUND) {
            await sendToBackground(eventData);
          }
        }
      });
      return () => {
        console.log("Content script cleanup initiated");
        cleanup();
      };
    }
  });
  content;
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (async () => {
    try {
      initPlugins();
      const { main, ...options } = definition;
      const ctx = new ContentScriptContext("content", options);
      return await main(ctx);
    } catch (err) {
      logger.error(
        `The content script "${"content"}" crashed on startup!`,
        err
      );
      throw err;
    }
  })();
  return result;
}();
content;
