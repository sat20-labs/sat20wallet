var background = function() {
  "use strict";var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  var _a, _b, _c, _d;
  function defineBackground(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  var _MatchPattern = class {
    constructor(matchPattern) {
      if (matchPattern === "<all_urls>") {
        this.isAllUrls = true;
        this.protocolMatches = [..._MatchPattern.PROTOCOLS];
        this.hostnameMatch = "*";
        this.pathnameMatch = "*";
      } else {
        const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
        if (groups == null)
          throw new InvalidMatchPattern(matchPattern, "Incorrect format");
        const [_, protocol, hostname, pathname] = groups;
        validateProtocol(matchPattern, protocol);
        validateHostname(matchPattern, hostname);
        this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
        this.hostnameMatch = hostname;
        this.pathnameMatch = pathname;
      }
    }
    includes(url) {
      if (this.isAllUrls)
        return true;
      const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
      return !!this.protocolMatches.find((protocol) => {
        if (protocol === "http")
          return this.isHttpMatch(u);
        if (protocol === "https")
          return this.isHttpsMatch(u);
        if (protocol === "file")
          return this.isFileMatch(u);
        if (protocol === "ftp")
          return this.isFtpMatch(u);
        if (protocol === "urn")
          return this.isUrnMatch(u);
      });
    }
    isHttpMatch(url) {
      return url.protocol === "http:" && this.isHostPathMatch(url);
    }
    isHttpsMatch(url) {
      return url.protocol === "https:" && this.isHostPathMatch(url);
    }
    isHostPathMatch(url) {
      if (!this.hostnameMatch || !this.pathnameMatch)
        return false;
      const hostnameMatchRegexs = [
        this.convertPatternToRegex(this.hostnameMatch),
        this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))
      ];
      const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
      return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
    }
    isFileMatch(url) {
      throw Error("Not implemented: file:// pattern matching. Open a PR to add support");
    }
    isFtpMatch(url) {
      throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
    }
    isUrnMatch(url) {
      throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
    }
    convertPatternToRegex(pattern) {
      const escaped = this.escapeForRegex(pattern);
      const starsReplaced = escaped.replace(/\\\*/g, ".*");
      return RegExp(`^${starsReplaced}$`);
    }
    escapeForRegex(string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
  };
  var MatchPattern = _MatchPattern;
  MatchPattern.PROTOCOLS = ["http", "https", "file", "ftp", "urn"];
  var InvalidMatchPattern = class extends Error {
    constructor(matchPattern, reason) {
      super(`Invalid match pattern "${matchPattern}": ${reason}`);
    }
  };
  function validateProtocol(matchPattern, protocol) {
    if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*")
      throw new InvalidMatchPattern(
        matchPattern,
        `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`
      );
  }
  function validateHostname(matchPattern, hostname) {
    if (hostname.includes(":"))
      throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
    if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*."))
      throw new InvalidMatchPattern(
        matchPattern,
        `If using a wildcard (*), it must go at the start of the hostname`
      );
  }
  class WalletError {
    constructor() {
      __publicField(this, "noWallet", {
        code: 0,
        message: "No wallet"
        /* NO_WALLET */
      });
      __publicField(this, "userReject", {
        code: 1,
        message: "User rejected"
        /* REJECT */
      });
    }
  }
  const walletError = new WalletError();
  background;
  var has = Object.prototype.hasOwnProperty;
  function dequal(foo, bar) {
    var ctor, len;
    if (foo === bar) return true;
    if (foo && bar && (ctor = foo.constructor) === bar.constructor) {
      if (ctor === Date) return foo.getTime() === bar.getTime();
      if (ctor === RegExp) return foo.toString() === bar.toString();
      if (ctor === Array) {
        if ((len = foo.length) === bar.length) {
          while (len-- && dequal(foo[len], bar[len])) ;
        }
        return len === -1;
      }
      if (!ctor || typeof foo === "object") {
        len = 0;
        for (ctor in foo) {
          if (has.call(foo, ctor) && ++len && !has.call(bar, ctor)) return false;
          if (!(ctor in bar) || !dequal(foo[ctor], bar[ctor])) return false;
        }
        return Object.keys(bar).length === len;
      }
    }
    return foo !== foo && bar !== bar;
  }
  const E_CANCELED = new Error("request for lock canceled");
  var __awaiter$2 = function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }
      function step(result2) {
        result2.done ? resolve(result2.value) : adopt(result2.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  };
  class Semaphore {
    constructor(_value, _cancelError = E_CANCELED) {
      this._value = _value;
      this._cancelError = _cancelError;
      this._queue = [];
      this._weightedWaiters = [];
    }
    acquire(weight = 1, priority = 0) {
      if (weight <= 0)
        throw new Error(`invalid weight ${weight}: must be positive`);
      return new Promise((resolve, reject) => {
        const task = { resolve, reject, weight, priority };
        const i = findIndexFromEnd(this._queue, (other) => priority <= other.priority);
        if (i === -1 && weight <= this._value) {
          this._dispatchItem(task);
        } else {
          this._queue.splice(i + 1, 0, task);
        }
      });
    }
    runExclusive(callback_1) {
      return __awaiter$2(this, arguments, void 0, function* (callback, weight = 1, priority = 0) {
        const [value, release] = yield this.acquire(weight, priority);
        try {
          return yield callback(value);
        } finally {
          release();
        }
      });
    }
    waitForUnlock(weight = 1, priority = 0) {
      if (weight <= 0)
        throw new Error(`invalid weight ${weight}: must be positive`);
      if (this._couldLockImmediately(weight, priority)) {
        return Promise.resolve();
      } else {
        return new Promise((resolve) => {
          if (!this._weightedWaiters[weight - 1])
            this._weightedWaiters[weight - 1] = [];
          insertSorted(this._weightedWaiters[weight - 1], { resolve, priority });
        });
      }
    }
    isLocked() {
      return this._value <= 0;
    }
    getValue() {
      return this._value;
    }
    setValue(value) {
      this._value = value;
      this._dispatchQueue();
    }
    release(weight = 1) {
      if (weight <= 0)
        throw new Error(`invalid weight ${weight}: must be positive`);
      this._value += weight;
      this._dispatchQueue();
    }
    cancel() {
      this._queue.forEach((entry) => entry.reject(this._cancelError));
      this._queue = [];
    }
    _dispatchQueue() {
      this._drainUnlockWaiters();
      while (this._queue.length > 0 && this._queue[0].weight <= this._value) {
        this._dispatchItem(this._queue.shift());
        this._drainUnlockWaiters();
      }
    }
    _dispatchItem(item) {
      const previousValue = this._value;
      this._value -= item.weight;
      item.resolve([previousValue, this._newReleaser(item.weight)]);
    }
    _newReleaser(weight) {
      let called = false;
      return () => {
        if (called)
          return;
        called = true;
        this.release(weight);
      };
    }
    _drainUnlockWaiters() {
      if (this._queue.length === 0) {
        for (let weight = this._value; weight > 0; weight--) {
          const waiters = this._weightedWaiters[weight - 1];
          if (!waiters)
            continue;
          waiters.forEach((waiter) => waiter.resolve());
          this._weightedWaiters[weight - 1] = [];
        }
      } else {
        const queuedPriority = this._queue[0].priority;
        for (let weight = this._value; weight > 0; weight--) {
          const waiters = this._weightedWaiters[weight - 1];
          if (!waiters)
            continue;
          const i = waiters.findIndex((waiter) => waiter.priority <= queuedPriority);
          (i === -1 ? waiters : waiters.splice(0, i)).forEach((waiter) => waiter.resolve());
        }
      }
    }
    _couldLockImmediately(weight, priority) {
      return (this._queue.length === 0 || this._queue[0].priority < priority) && weight <= this._value;
    }
  }
  function insertSorted(a, v) {
    const i = findIndexFromEnd(a, (other) => v.priority <= other.priority);
    a.splice(i + 1, 0, v);
  }
  function findIndexFromEnd(a, predicate) {
    for (let i = a.length - 1; i >= 0; i--) {
      if (predicate(a[i])) {
        return i;
      }
    }
    return -1;
  }
  var __awaiter$1 = function(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }
      function step(result2) {
        result2.done ? resolve(result2.value) : adopt(result2.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  };
  class Mutex {
    constructor(cancelError) {
      this._semaphore = new Semaphore(1, cancelError);
    }
    acquire() {
      return __awaiter$1(this, arguments, void 0, function* (priority = 0) {
        const [, releaser] = yield this._semaphore.acquire(1, priority);
        return releaser;
      });
    }
    runExclusive(callback, priority = 0) {
      return this._semaphore.runExclusive(() => callback(), 1, priority);
    }
    isLocked() {
      return this._semaphore.isLocked();
    }
    waitForUnlock(priority = 0) {
      return this._semaphore.waitForUnlock(1, priority);
    }
    release() {
      if (this._semaphore.isLocked())
        this._semaphore.release();
    }
    cancel() {
      return this._semaphore.cancel();
    }
  }
  const browser$1 = (
    // @ts-expect-error
    ((_b = (_a = globalThis.browser) == null ? void 0 : _a.runtime) == null ? void 0 : _b.id) == null ? globalThis.chrome : (
      // @ts-expect-error
      globalThis.browser
    )
  );
  const storage = createStorage();
  function createStorage() {
    const drivers = {
      local: createDriver("local"),
      session: createDriver("session"),
      sync: createDriver("sync"),
      managed: createDriver("managed")
    };
    const getDriver = (area) => {
      const driver = drivers[area];
      if (driver == null) {
        const areaNames = Object.keys(drivers).join(", ");
        throw Error(`Invalid area "${area}". Options: ${areaNames}`);
      }
      return driver;
    };
    const resolveKey = (key) => {
      const deliminatorIndex = key.indexOf(":");
      const driverArea = key.substring(0, deliminatorIndex);
      const driverKey = key.substring(deliminatorIndex + 1);
      if (driverKey == null)
        throw Error(
          `Storage key should be in the form of "area:key", but received "${key}"`
        );
      return {
        driverArea,
        driverKey,
        driver: getDriver(driverArea)
      };
    };
    const getMetaKey = (key) => key + "$";
    const mergeMeta = (oldMeta, newMeta) => {
      const newFields = { ...oldMeta };
      Object.entries(newMeta).forEach(([key, value]) => {
        if (value == null) delete newFields[key];
        else newFields[key] = value;
      });
      return newFields;
    };
    const getValueOrFallback = (value, fallback) => value ?? fallback ?? null;
    const getMetaValue = (properties) => typeof properties === "object" && !Array.isArray(properties) ? properties : {};
    const getItem = async (driver, driverKey, opts) => {
      const res = await driver.getItem(driverKey);
      return getValueOrFallback(res, (opts == null ? void 0 : opts.fallback) ?? (opts == null ? void 0 : opts.defaultValue));
    };
    const getMeta = async (driver, driverKey) => {
      const metaKey = getMetaKey(driverKey);
      const res = await driver.getItem(metaKey);
      return getMetaValue(res);
    };
    const setItem = async (driver, driverKey, value) => {
      await driver.setItem(driverKey, value ?? null);
    };
    const setMeta = async (driver, driverKey, properties) => {
      const metaKey = getMetaKey(driverKey);
      const existingFields = getMetaValue(await driver.getItem(metaKey));
      await driver.setItem(metaKey, mergeMeta(existingFields, properties));
    };
    const removeItem = async (driver, driverKey, opts) => {
      await driver.removeItem(driverKey);
      if (opts == null ? void 0 : opts.removeMeta) {
        const metaKey = getMetaKey(driverKey);
        await driver.removeItem(metaKey);
      }
    };
    const removeMeta = async (driver, driverKey, properties) => {
      const metaKey = getMetaKey(driverKey);
      if (properties == null) {
        await driver.removeItem(metaKey);
      } else {
        const newFields = getMetaValue(await driver.getItem(metaKey));
        [properties].flat().forEach((field) => delete newFields[field]);
        await driver.setItem(metaKey, newFields);
      }
    };
    const watch = (driver, driverKey, cb) => {
      return driver.watch(driverKey, cb);
    };
    const storage2 = {
      getItem: async (key, opts) => {
        const { driver, driverKey } = resolveKey(key);
        return await getItem(driver, driverKey, opts);
      },
      getItems: async (keys) => {
        const areaToKeyMap = /* @__PURE__ */ new Map();
        const keyToOptsMap = /* @__PURE__ */ new Map();
        const orderedKeys = [];
        keys.forEach((key) => {
          let keyStr;
          let opts;
          if (typeof key === "string") {
            keyStr = key;
          } else if ("getValue" in key) {
            keyStr = key.key;
            opts = { fallback: key.fallback };
          } else {
            keyStr = key.key;
            opts = key.options;
          }
          orderedKeys.push(keyStr);
          const { driverArea, driverKey } = resolveKey(keyStr);
          const areaKeys = areaToKeyMap.get(driverArea) ?? [];
          areaToKeyMap.set(driverArea, areaKeys.concat(driverKey));
          keyToOptsMap.set(keyStr, opts);
        });
        const resultsMap = /* @__PURE__ */ new Map();
        await Promise.all(
          Array.from(areaToKeyMap.entries()).map(async ([driverArea, keys2]) => {
            const driverResults = await drivers[driverArea].getItems(keys2);
            driverResults.forEach((driverResult) => {
              const key = `${driverArea}:${driverResult.key}`;
              const opts = keyToOptsMap.get(key);
              const value = getValueOrFallback(
                driverResult.value,
                (opts == null ? void 0 : opts.fallback) ?? (opts == null ? void 0 : opts.defaultValue)
              );
              resultsMap.set(key, value);
            });
          })
        );
        return orderedKeys.map((key) => ({
          key,
          value: resultsMap.get(key)
        }));
      },
      getMeta: async (key) => {
        const { driver, driverKey } = resolveKey(key);
        return await getMeta(driver, driverKey);
      },
      getMetas: async (args) => {
        const keys = args.map((arg) => {
          const key = typeof arg === "string" ? arg : arg.key;
          const { driverArea, driverKey } = resolveKey(key);
          return {
            key,
            driverArea,
            driverKey,
            driverMetaKey: getMetaKey(driverKey)
          };
        });
        const areaToDriverMetaKeysMap = keys.reduce((map2, key) => {
          var _a2;
          map2[_a2 = key.driverArea] ?? (map2[_a2] = []);
          map2[key.driverArea].push(key);
          return map2;
        }, {});
        const resultsMap = {};
        await Promise.all(
          Object.entries(areaToDriverMetaKeysMap).map(async ([area, keys2]) => {
            const areaRes = await browser$1.storage[area].get(
              keys2.map((key) => key.driverMetaKey)
            );
            keys2.forEach((key) => {
              resultsMap[key.key] = areaRes[key.driverMetaKey] ?? {};
            });
          })
        );
        return keys.map((key) => ({
          key: key.key,
          meta: resultsMap[key.key]
        }));
      },
      setItem: async (key, value) => {
        const { driver, driverKey } = resolveKey(key);
        await setItem(driver, driverKey, value);
      },
      setItems: async (items) => {
        const areaToKeyValueMap = {};
        items.forEach((item) => {
          const { driverArea, driverKey } = resolveKey(
            "key" in item ? item.key : item.item.key
          );
          areaToKeyValueMap[driverArea] ?? (areaToKeyValueMap[driverArea] = []);
          areaToKeyValueMap[driverArea].push({
            key: driverKey,
            value: item.value
          });
        });
        await Promise.all(
          Object.entries(areaToKeyValueMap).map(async ([driverArea, values]) => {
            const driver = getDriver(driverArea);
            await driver.setItems(values);
          })
        );
      },
      setMeta: async (key, properties) => {
        const { driver, driverKey } = resolveKey(key);
        await setMeta(driver, driverKey, properties);
      },
      setMetas: async (items) => {
        const areaToMetaUpdatesMap = {};
        items.forEach((item) => {
          const { driverArea, driverKey } = resolveKey(
            "key" in item ? item.key : item.item.key
          );
          areaToMetaUpdatesMap[driverArea] ?? (areaToMetaUpdatesMap[driverArea] = []);
          areaToMetaUpdatesMap[driverArea].push({
            key: driverKey,
            properties: item.meta
          });
        });
        await Promise.all(
          Object.entries(areaToMetaUpdatesMap).map(
            async ([storageArea, updates]) => {
              const driver = getDriver(storageArea);
              const metaKeys = updates.map(({ key }) => getMetaKey(key));
              console.log(storageArea, metaKeys);
              const existingMetas = await driver.getItems(metaKeys);
              const existingMetaMap = Object.fromEntries(
                existingMetas.map(({ key, value }) => [key, getMetaValue(value)])
              );
              const metaUpdates = updates.map(({ key, properties }) => {
                const metaKey = getMetaKey(key);
                return {
                  key: metaKey,
                  value: mergeMeta(existingMetaMap[metaKey] ?? {}, properties)
                };
              });
              await driver.setItems(metaUpdates);
            }
          )
        );
      },
      removeItem: async (key, opts) => {
        const { driver, driverKey } = resolveKey(key);
        await removeItem(driver, driverKey, opts);
      },
      removeItems: async (keys) => {
        const areaToKeysMap = {};
        keys.forEach((key) => {
          let keyStr;
          let opts;
          if (typeof key === "string") {
            keyStr = key;
          } else if ("getValue" in key) {
            keyStr = key.key;
          } else if ("item" in key) {
            keyStr = key.item.key;
            opts = key.options;
          } else {
            keyStr = key.key;
            opts = key.options;
          }
          const { driverArea, driverKey } = resolveKey(keyStr);
          areaToKeysMap[driverArea] ?? (areaToKeysMap[driverArea] = []);
          areaToKeysMap[driverArea].push(driverKey);
          if (opts == null ? void 0 : opts.removeMeta) {
            areaToKeysMap[driverArea].push(getMetaKey(driverKey));
          }
        });
        await Promise.all(
          Object.entries(areaToKeysMap).map(async ([driverArea, keys2]) => {
            const driver = getDriver(driverArea);
            await driver.removeItems(keys2);
          })
        );
      },
      clear: async (base) => {
        const driver = getDriver(base);
        await driver.clear();
      },
      removeMeta: async (key, properties) => {
        const { driver, driverKey } = resolveKey(key);
        await removeMeta(driver, driverKey, properties);
      },
      snapshot: async (base, opts) => {
        var _a2;
        const driver = getDriver(base);
        const data = await driver.snapshot();
        (_a2 = opts == null ? void 0 : opts.excludeKeys) == null ? void 0 : _a2.forEach((key) => {
          delete data[key];
          delete data[getMetaKey(key)];
        });
        return data;
      },
      restoreSnapshot: async (base, data) => {
        const driver = getDriver(base);
        await driver.restoreSnapshot(data);
      },
      watch: (key, cb) => {
        const { driver, driverKey } = resolveKey(key);
        return watch(driver, driverKey, cb);
      },
      unwatch() {
        Object.values(drivers).forEach((driver) => {
          driver.unwatch();
        });
      },
      defineItem: (key, opts) => {
        const { driver, driverKey } = resolveKey(key);
        const { version: targetVersion = 1, migrations = {} } = opts ?? {};
        if (targetVersion < 1) {
          throw Error(
            "Storage item version cannot be less than 1. Initial versions should be set to 1, not 0."
          );
        }
        const migrate = async () => {
          var _a2;
          const driverMetaKey = getMetaKey(driverKey);
          const [{ value }, { value: meta }] = await driver.getItems([
            driverKey,
            driverMetaKey
          ]);
          if (value == null) return;
          const currentVersion = (meta == null ? void 0 : meta.v) ?? 1;
          if (currentVersion > targetVersion) {
            throw Error(
              `Version downgrade detected (v${currentVersion} -> v${targetVersion}) for "${key}"`
            );
          }
          if (currentVersion === targetVersion) {
            return;
          }
          console.debug(
            `[@wxt-dev/storage] Running storage migration for ${key}: v${currentVersion} -> v${targetVersion}`
          );
          const migrationsToRun = Array.from(
            { length: targetVersion - currentVersion },
            (_, i) => currentVersion + i + 1
          );
          let migratedValue = value;
          for (const migrateToVersion of migrationsToRun) {
            try {
              migratedValue = await ((_a2 = migrations == null ? void 0 : migrations[migrateToVersion]) == null ? void 0 : _a2.call(migrations, migratedValue)) ?? migratedValue;
            } catch (err) {
              throw new MigrationError(key, migrateToVersion, {
                cause: err
              });
            }
          }
          await driver.setItems([
            { key: driverKey, value: migratedValue },
            { key: driverMetaKey, value: { ...meta, v: targetVersion } }
          ]);
          console.debug(
            `[@wxt-dev/storage] Storage migration completed for ${key} v${targetVersion}`,
            { migratedValue }
          );
        };
        const migrationsDone = (opts == null ? void 0 : opts.migrations) == null ? Promise.resolve() : migrate().catch((err) => {
          console.error(
            `[@wxt-dev/storage] Migration failed for ${key}`,
            err
          );
        });
        const initMutex = new Mutex();
        const getFallback = () => (opts == null ? void 0 : opts.fallback) ?? (opts == null ? void 0 : opts.defaultValue) ?? null;
        const getOrInitValue = () => initMutex.runExclusive(async () => {
          const value = await driver.getItem(driverKey);
          if (value != null || (opts == null ? void 0 : opts.init) == null) return value;
          const newValue = await opts.init();
          await driver.setItem(driverKey, newValue);
          return newValue;
        });
        migrationsDone.then(getOrInitValue);
        return {
          key,
          get defaultValue() {
            return getFallback();
          },
          get fallback() {
            return getFallback();
          },
          getValue: async () => {
            await migrationsDone;
            if (opts == null ? void 0 : opts.init) {
              return await getOrInitValue();
            } else {
              return await getItem(driver, driverKey, opts);
            }
          },
          getMeta: async () => {
            await migrationsDone;
            return await getMeta(driver, driverKey);
          },
          setValue: async (value) => {
            await migrationsDone;
            return await setItem(driver, driverKey, value);
          },
          setMeta: async (properties) => {
            await migrationsDone;
            return await setMeta(driver, driverKey, properties);
          },
          removeValue: async (opts2) => {
            await migrationsDone;
            return await removeItem(driver, driverKey, opts2);
          },
          removeMeta: async (properties) => {
            await migrationsDone;
            return await removeMeta(driver, driverKey, properties);
          },
          watch: (cb) => watch(
            driver,
            driverKey,
            (newValue, oldValue) => cb(newValue ?? getFallback(), oldValue ?? getFallback())
          ),
          migrate
        };
      }
    };
    return storage2;
  }
  function createDriver(storageArea) {
    const getStorageArea = () => {
      if (browser$1.runtime == null) {
        throw Error(
          [
            "'wxt/storage' must be loaded in a web extension environment",
            "\n - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371",
            " - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html\n"
          ].join("\n")
        );
      }
      if (browser$1.storage == null) {
        throw Error(
          "You must add the 'storage' permission to your manifest to use 'wxt/storage'"
        );
      }
      const area = browser$1.storage[storageArea];
      if (area == null)
        throw Error(`"browser.storage.${storageArea}" is undefined`);
      return area;
    };
    const watchListeners = /* @__PURE__ */ new Set();
    return {
      getItem: async (key) => {
        const res = await getStorageArea().get(key);
        return res[key];
      },
      getItems: async (keys) => {
        const result2 = await getStorageArea().get(keys);
        return keys.map((key) => ({ key, value: result2[key] ?? null }));
      },
      setItem: async (key, value) => {
        if (value == null) {
          await getStorageArea().remove(key);
        } else {
          await getStorageArea().set({ [key]: value });
        }
      },
      setItems: async (values) => {
        const map2 = values.reduce(
          (map22, { key, value }) => {
            map22[key] = value;
            return map22;
          },
          {}
        );
        await getStorageArea().set(map2);
      },
      removeItem: async (key) => {
        await getStorageArea().remove(key);
      },
      removeItems: async (keys) => {
        await getStorageArea().remove(keys);
      },
      clear: async () => {
        await getStorageArea().clear();
      },
      snapshot: async () => {
        return await getStorageArea().get();
      },
      restoreSnapshot: async (data) => {
        await getStorageArea().set(data);
      },
      watch(key, cb) {
        const listener = (changes) => {
          const change = changes[key];
          if (change == null) return;
          if (dequal(change.newValue, change.oldValue)) return;
          cb(change.newValue ?? null, change.oldValue ?? null);
        };
        getStorageArea().onChanged.addListener(listener);
        watchListeners.add(listener);
        return () => {
          getStorageArea().onChanged.removeListener(listener);
          watchListeners.delete(listener);
        };
      },
      unwatch() {
        watchListeners.forEach((listener) => {
          getStorageArea().onChanged.removeListener(listener);
        });
        watchListeners.clear();
      }
    };
  }
  class MigrationError extends Error {
    constructor(key, version, options) {
      super(`v${version} migration failed for "${key}"`, options);
      this.key = key;
      this.version = version;
    }
  }
  var Network = /* @__PURE__ */ ((Network2) => {
    Network2["LIVENET"] = "livenet";
    Network2["TESTNET"] = "testnet";
    return Network2;
  })(Network || {});
  var Chain = /* @__PURE__ */ ((Chain2) => {
    Chain2["BTC"] = "btc";
    Chain2["SATNET"] = "satnet";
    return Chain2;
  })(Chain || {});
  background;
  const defaultState = {
    env: "test",
    locked: true,
    hasWallet: false,
    address: null,
    isConnected: false,
    password: null,
    network: Network.LIVENET,
    chain: Chain.BTC,
    walletId: 0,
    accountIndex: 0,
    balance: { confirmed: 0, unconfirmed: 0, total: 0 },
    pubkey: null,
    passwordTime: null,
    wallets: []
  };
  const _WalletStorage = class _WalletStorage {
    constructor({
      storageType = "local"
    }) {
      __publicField(this, "state");
      __publicField(this, "storageType");
      __publicField(this, "listeners");
      __publicField(this, "updatePromises");
      this.storageType = storageType;
      this.state = JSON.parse(JSON.stringify(defaultState));
      this.listeners = /* @__PURE__ */ new Set();
      this.updatePromises = /* @__PURE__ */ new Map();
    }
    static getInstance(config2 = { storageType: "local" }) {
      if (!_WalletStorage.instance) {
        _WalletStorage.instance = new _WalletStorage(config2);
      }
      return _WalletStorage.instance;
    }
    getStorageKey(key) {
      return `${this.storageType}:wallet_${key}`;
    }
    // 初始化状态
    async initializeState() {
      const loadPromises = Object.keys(defaultState).map(async (key) => {
        const storageKey = key;
        const value = await storage.getItem(this.getStorageKey(storageKey));
        console.log("initializeState");
        console.log(storageKey, value);
        if (value !== null) {
          this.state[storageKey] = value;
        }
      });
      await Promise.all(loadPromises);
    }
    // 获取状态
    getState() {
      return { ...this.state };
    }
    // 获取单个状态值
    getValue(key) {
      return this.state[key];
    }
    // 更新单个状态
    async setValue(key, value) {
      console.log("setValue", key, value);
      const oldValue = this.state[key];
      console.log("oldValue", oldValue);
      try {
        await storage.setItem(this.getStorageKey(key), value);
        console.log("setValue", this.getStorageKey(key), value);
        console.log("storage", await storage.getItem(this.getStorageKey(key)));
        this.state[key] = value;
        this.notifyListeners(key, value, oldValue);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.error(`Failed to update ${key}:`, error);
        throw new Error(`Failed to update ${key}: ${errorMessage}`);
      }
    }
    // 批量更新状态
    async batchUpdate(updates) {
      const oldState = { ...this.state };
      const updatePromises = [];
      try {
        for (const [key, value] of Object.entries(updates)) {
          const typedKey = key;
          if (this.state[typedKey] !== value) {
            const typedValue = value;
            updatePromises.push(
              storage.setItem(this.getStorageKey(key), typedValue).then(() => {
                ;
                this.state[typedKey] = typedValue;
                this.notifyListeners(typedKey, typedValue, oldState[typedKey]);
              })
            );
          }
        }
        await Promise.all(updatePromises);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.error("Batch update failed:", error);
        this.state = oldState;
        throw new Error(`Batch update failed: ${errorMessage}`);
      }
    }
    // 特殊的更新方法，用于处理密码相关的状态
    async updatePassword(password) {
      const updates = {
        password,
        passwordTime: password ? (/* @__PURE__ */ new Date()).getTime() : null
      };
      await this.batchUpdate(updates);
    }
    // 订阅状态变化
    subscribe(callback) {
      this.listeners.add(callback);
      return () => {
        this.listeners.delete(callback);
      };
    }
    // 通知所有监听器
    notifyListeners(key, newValue, oldValue) {
      this.listeners.forEach((listener) => {
        try {
          listener(key, newValue, oldValue);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("Error in state change listener:", errorMessage);
        }
      });
    }
    // 清除所有状态
    async clear() {
      try {
        const keys = Object.keys(this.state).map((key) => this.getStorageKey(key));
        console.log("keys", keys);
        await storage.removeItems(keys);
        const oldState = { ...this.state };
        this.state = JSON.parse(JSON.stringify(defaultState));
        Object.keys(oldState).forEach((key) => {
          const typedKey = key;
          this.notifyListeners(typedKey, this.state[typedKey], oldState[typedKey]);
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.error("Failed to clear storage:", error);
        throw new Error(`Failed to clear storage: ${errorMessage}`);
      }
    }
  };
  __publicField(_WalletStorage, "instance", null);
  let WalletStorage = _WalletStorage;
  const walletStorage = WalletStorage.getInstance();
  background;
  const devConfig$1 = {
    ordxBaseUrl: "https://apidev.sat20.org",
    satnetBaseUrl: "https://apidev.sat20.org"
  };
  const testConfig$1 = {
    ordxBaseUrl: "https://apitest.sat20.org",
    satnetBaseUrl: "https://apitest.sat20.org"
  };
  const prodConfig$1 = {
    ordxBaseUrl: "https://apiprd.sat20.org",
    satnetBaseUrl: "https://apiprd.sat20.org"
  };
  const config$1 = {
    dev: devConfig$1,
    test: testConfig$1,
    prod: prodConfig$1
  };
  background;
  class OrdxApi {
    generatePath(path, network) {
      const env = walletStorage.getValue("env");
      const config2 = config$1[env];
      const BASE_URL = config2.ordxBaseUrl;
      return `${BASE_URL}${network === "testnet" ? "/btc/testnet" : "/btc/mainnet"}/${path}`;
    }
    async getUtxos({ address, network }) {
      const response = await fetch(
        this.generatePath(`allutxos/address/${address}`, network)
      );
      return response.json();
    }
    async getTxRaw({ txid, network }) {
      const response = await fetch(
        this.generatePath(`btc/rawtx/${txid}`, network)
      );
      return response.json();
    }
    async getPlainUtxos({ address, network }) {
      const response = await fetch(
        this.generatePath(`utxo/address/${address}/0`, network)
      );
      return response.json();
    }
    async getRareUtxos({ address, network }) {
      const response = await fetch(
        this.generatePath(`exotic/address/${address}`, network)
      );
      return response.json();
    }
    async getRecommendedFees({ network }) {
      const url = `https://apidev.ordx.market/${network === "livenet" ? "btc" : "testnet/"}ordx/GetRecommendedFees`;
      const response = await fetch(url);
      return response.json();
    }
    async getUtxo({ utxo, network }) {
      const response = await fetch(
        this.generatePath(`utxo/range/${utxo}`, network)
      );
      return response.json();
    }
    async getNsName({ name, network }) {
      const response = await fetch(this.generatePath(`ns/name/${name}`, network));
      return response.json();
    }
    async getAddressSummary({ address, network }) {
      const response = await fetch(
        this.generatePath(`v3/address/summary/${address}`, network)
      );
      return response.json();
    }
    async getNsListByAddress({ address, network }) {
      const response = await fetch(
        this.generatePath(`ns/address/${address}`, network)
      );
      return response.json();
    }
    async pushTx({ hex, network }) {
      const response = await fetch(this.generatePath(`btc/tx`, network), {
        method: "POST",
        body: JSON.stringify({ SignedTxHex: hex })
      });
      console.log("response", response);
      return response.json();
    }
    async getOrdxAddressHolders({
      address,
      ticker,
      network,
      start,
      limit
    }) {
      const response = await fetch(
        this.generatePath(
          `v3/address/asset/${address}/${ticker}?start=${start}&limit=${limit}`,
          network
        )
      );
      return response.json();
    }
    async getOrdxNsUxtos({
      address,
      sub,
      network,
      page,
      pagesize
    }) {
      const start = (page - 1) * pagesize;
      const limit = pagesize;
      const response = await fetch(
        this.generatePath(
          `ns/address/${address}/${sub}?start=${start}&limit=${limit}`,
          network
        )
      );
      return response.json();
    }
  }
  const ordxApi = new OrdxApi();
  background;
  /**
  * @vue/shared v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  const EMPTY_OBJ = Object.freeze({});
  const extend = Object.assign;
  const isArray = Array.isArray;
  const isFunction$1 = (val) => typeof val === "function";
  const isString = (val) => typeof val === "string";
  const isSymbol = (val) => typeof val === "symbol";
  const isObject = (val) => val !== null && typeof val === "object";
  let _globalThis;
  const getGlobalThis = () => {
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  };
  /**
  * @vue/reactivity v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
  );
  function isReactive(value) {
    if (isReadonly(value)) {
      return isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
  }
  function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
  }
  function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
  }
  function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? toRaw(raw) : observed;
  }
  function isRef(r) {
    return r ? r["__v_isRef"] === true : false;
  }
  /**
  * @vue/runtime-core v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  const stack = [];
  function pushWarningContext(vnode) {
    stack.push(vnode);
  }
  function popWarningContext() {
    stack.pop();
  }
  let isWarning = false;
  function warn$1(msg, ...args) {
    if (isWarning) return;
    isWarning = true;
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
      callWithErrorHandling(
        appWarnHandler,
        instance,
        11,
        [
          // eslint-disable-next-line no-restricted-syntax
          msg + args.map((a) => {
            var _a2, _b2;
            return (_b2 = (_a2 = a.toString) == null ? void 0 : _a2.call(a)) != null ? _b2 : JSON.stringify(a);
          }).join(""),
          instance && instance.proxy,
          trace.map(
            ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
          ).join("\n"),
          trace
        ]
      );
    } else {
      const warnArgs = [`[Vue warn]: ${msg}`, ...args];
      if (trace.length && // avoid spamming console during tests
      true) {
        warnArgs.push(`
`, ...formatTrace(trace));
      }
      console.warn(...warnArgs);
    }
    isWarning = false;
  }
  function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
      return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
      const last = normalizedStack[0];
      if (last && last.vnode === currentVNode) {
        last.recurseCount++;
      } else {
        normalizedStack.push({
          vnode: currentVNode,
          recurseCount: 0
        });
      }
      const parentInstance = currentVNode.component && currentVNode.component.parent;
      currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
  }
  function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
      logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
    });
    return logs;
  }
  function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
      vnode.component,
      vnode.type,
      isRoot
    )}`;
    const close = `>` + postfix;
    return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
  }
  function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
      res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
      res.push(` ...`);
    }
    return res;
  }
  function formatProp(key, value, raw) {
    if (isString(value)) {
      value = JSON.stringify(value);
      return raw ? value : [`${key}=${value}`];
    } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
      return raw ? value : [`${key}=${value}`];
    } else if (isRef(value)) {
      value = formatProp(key, toRaw(value.value), true);
      return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction$1(value)) {
      return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
      value = toRaw(value);
      return raw ? value : [`${key}=`, value];
    }
  }
  const ErrorTypeStrings$1 = {
    ["sp"]: "serverPrefetch hook",
    ["bc"]: "beforeCreate hook",
    ["c"]: "created hook",
    ["bm"]: "beforeMount hook",
    ["m"]: "mounted hook",
    ["bu"]: "beforeUpdate hook",
    ["u"]: "updated",
    ["bum"]: "beforeUnmount hook",
    ["um"]: "unmounted hook",
    ["a"]: "activated hook",
    ["da"]: "deactivated hook",
    ["ec"]: "errorCaptured hook",
    ["rtc"]: "renderTracked hook",
    ["rtg"]: "renderTriggered hook",
    [0]: "setup function",
    [1]: "render function",
    [2]: "watcher getter",
    [3]: "watcher callback",
    [4]: "watcher cleanup function",
    [5]: "native event handler",
    [6]: "component event handler",
    [7]: "vnode hook",
    [8]: "directive hook",
    [9]: "transition hook",
    [10]: "app errorHandler",
    [11]: "app warnHandler",
    [12]: "ref function",
    [13]: "async component loader",
    [14]: "scheduler flush",
    [15]: "component update",
    [16]: "app unmount cleanup function"
  };
  function callWithErrorHandling(fn, instance, type, args) {
    try {
      return args ? fn(...args) : fn();
    } catch (err) {
      handleError(err, instance, type);
    }
  }
  function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
    if (instance) {
      let cur = instance.parent;
      const exposedInstance = instance.proxy;
      const errorInfo = ErrorTypeStrings$1[type];
      while (cur) {
        const errorCapturedHooks = cur.ec;
        if (errorCapturedHooks) {
          for (let i = 0; i < errorCapturedHooks.length; i++) {
            if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
              return;
            }
          }
        }
        cur = cur.parent;
      }
      if (errorHandler) {
        callWithErrorHandling(errorHandler, null, 10, [
          err,
          exposedInstance,
          errorInfo
        ]);
        return;
      }
    }
    logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
  }
  function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
    {
      const info = ErrorTypeStrings$1[type];
      if (contextVNode) {
        pushWarningContext(contextVNode);
      }
      warn$1(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
      if (contextVNode) {
        popWarningContext();
      }
      if (throwInDev) {
        throw err;
      } else {
        console.error(err);
      }
    }
  }
  const queue = [];
  let flushIndex = -1;
  const pendingPostFlushCbs = [];
  let activePostFlushCbs = null;
  let postFlushIndex = 0;
  const resolvedPromise = /* @__PURE__ */ Promise.resolve();
  let currentFlushPromise = null;
  const RECURSION_LIMIT = 100;
  function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
      const middle = start + end >>> 1;
      const middleJob = queue[middle];
      const middleJobId = getId(middleJob);
      if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
        start = middle + 1;
      } else {
        end = middle;
      }
    }
    return start;
  }
  function queueJob(job) {
    if (!(job.flags & 1)) {
      const jobId = getId(job);
      const lastJob = queue[queue.length - 1];
      if (!lastJob || // fast path when the job id is larger than the tail
      !(job.flags & 2) && jobId >= getId(lastJob)) {
        queue.push(job);
      } else {
        queue.splice(findInsertionIndex(jobId), 0, job);
      }
      job.flags |= 1;
      queueFlush();
    }
  }
  function queueFlush() {
    if (!currentFlushPromise) {
      currentFlushPromise = resolvedPromise.then(flushJobs);
    }
  }
  function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
      if (activePostFlushCbs && cb.id === -1) {
        activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
      } else if (!(cb.flags & 1)) {
        pendingPostFlushCbs.push(cb);
        cb.flags |= 1;
      }
    } else {
      pendingPostFlushCbs.push(...cb);
    }
    queueFlush();
  }
  function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
      const deduped = [...new Set(pendingPostFlushCbs)].sort(
        (a, b) => getId(a) - getId(b)
      );
      pendingPostFlushCbs.length = 0;
      if (activePostFlushCbs) {
        activePostFlushCbs.push(...deduped);
        return;
      }
      activePostFlushCbs = deduped;
      {
        seen = seen || /* @__PURE__ */ new Map();
      }
      for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
        const cb = activePostFlushCbs[postFlushIndex];
        if (checkRecursiveUpdates(seen, cb)) {
          continue;
        }
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        if (!(cb.flags & 8)) cb();
        cb.flags &= -2;
      }
      activePostFlushCbs = null;
      postFlushIndex = 0;
    }
  }
  const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
  function flushJobs(seen) {
    {
      seen = seen || /* @__PURE__ */ new Map();
    }
    const check = (job) => checkRecursiveUpdates(seen, job);
    try {
      for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job && !(job.flags & 8)) {
          if (check(job)) {
            continue;
          }
          if (job.flags & 4) {
            job.flags &= ~1;
          }
          callWithErrorHandling(
            job,
            job.i,
            job.i ? 15 : 14
          );
          if (!(job.flags & 4)) {
            job.flags &= ~1;
          }
        }
      }
    } finally {
      for (; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job) {
          job.flags &= -2;
        }
      }
      flushIndex = -1;
      queue.length = 0;
      flushPostFlushCbs(seen);
      currentFlushPromise = null;
      if (queue.length || pendingPostFlushCbs.length) {
        flushJobs(seen);
      }
    }
  }
  function checkRecursiveUpdates(seen, fn) {
    const count = seen.get(fn) || 0;
    if (count > RECURSION_LIMIT) {
      const instance = fn.i;
      const componentName = instance && getComponentName(instance.type);
      handleError(
        `Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`,
        null,
        10
      );
      return true;
    }
    seen.set(fn, count + 1);
    return false;
  }
  const hmrDirtyComponents = /* @__PURE__ */ new Map();
  {
    getGlobalThis().__VUE_HMR_RUNTIME__ = {
      createRecord: tryWrap(createRecord),
      rerender: tryWrap(rerender),
      reload: tryWrap(reload)
    };
  }
  const map = /* @__PURE__ */ new Map();
  function createRecord(id, initialDef) {
    if (map.has(id)) {
      return false;
    }
    map.set(id, {
      initialDef: normalizeClassComponent(initialDef),
      instances: /* @__PURE__ */ new Set()
    });
    return true;
  }
  function normalizeClassComponent(component) {
    return isClassComponent(component) ? component.__vccOpts : component;
  }
  function rerender(id, newRender) {
    const record = map.get(id);
    if (!record) {
      return;
    }
    record.initialDef.render = newRender;
    [...record.instances].forEach((instance) => {
      if (newRender) {
        instance.render = newRender;
        normalizeClassComponent(instance.type).render = newRender;
      }
      instance.renderCache = [];
      instance.update();
    });
  }
  function reload(id, newComp) {
    const record = map.get(id);
    if (!record) return;
    newComp = normalizeClassComponent(newComp);
    updateComponentDef(record.initialDef, newComp);
    const instances = [...record.instances];
    for (let i = 0; i < instances.length; i++) {
      const instance = instances[i];
      const oldComp = normalizeClassComponent(instance.type);
      let dirtyInstances = hmrDirtyComponents.get(oldComp);
      if (!dirtyInstances) {
        if (oldComp !== record.initialDef) {
          updateComponentDef(oldComp, newComp);
        }
        hmrDirtyComponents.set(oldComp, dirtyInstances = /* @__PURE__ */ new Set());
      }
      dirtyInstances.add(instance);
      instance.appContext.propsCache.delete(instance.type);
      instance.appContext.emitsCache.delete(instance.type);
      instance.appContext.optionsCache.delete(instance.type);
      if (instance.ceReload) {
        dirtyInstances.add(instance);
        instance.ceReload(newComp.styles);
        dirtyInstances.delete(instance);
      } else if (instance.parent) {
        queueJob(() => {
          instance.parent.update();
          dirtyInstances.delete(instance);
        });
      } else if (instance.appContext.reload) {
        instance.appContext.reload();
      } else if (typeof window !== "undefined") {
        window.location.reload();
      } else {
        console.warn(
          "[HMR] Root or manually mounted instance modified. Full reload required."
        );
      }
      if (instance.root.ce && instance !== instance.root) {
        instance.root.ce._removeChildStyle(oldComp);
      }
    }
    queuePostFlushCb(() => {
      hmrDirtyComponents.clear();
    });
  }
  function updateComponentDef(oldComp, newComp) {
    extend(oldComp, newComp);
    for (const key in oldComp) {
      if (key !== "__file" && !(key in newComp)) {
        delete oldComp[key];
      }
    }
  }
  function tryWrap(fn) {
    return (id, arg) => {
      try {
        return fn(id, arg);
      } catch (e) {
        console.error(e);
        console.warn(
          `[HMR] Something went wrong during Vue component hot-reload. Full reload required.`
        );
      }
    };
  }
  getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
  getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
  const PublicInstanceProxyHandlers = {};
  {
    PublicInstanceProxyHandlers.ownKeys = (target) => {
      warn$1(
        `Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`
      );
      return Reflect.ownKeys(target);
    };
  }
  {
    const g = getGlobalThis();
    const registerGlobalSetter = (key, setter) => {
      let setters;
      if (!(setters = g[key])) setters = g[key] = [];
      setters.push(setter);
      return (v) => {
        if (setters.length > 1) setters.forEach((set) => set(v));
        else setters[0](v);
      };
    };
    registerGlobalSetter(
      `__VUE_INSTANCE_SETTERS__`,
      (v) => v
    );
    registerGlobalSetter(
      `__VUE_SSR_SETTERS__`,
      (v) => v
    );
  }
  const classifyRE = /(?:^|[-_])(\w)/g;
  const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
  function getComponentName(Component, includeInferred = true) {
    return isFunction$1(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
  }
  function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
      const match = Component.__file.match(/([^/\\]+)\.\w+$/);
      if (match) {
        name = match[1];
      }
    }
    if (!name && instance && instance.parent) {
      const inferFromRegistry = (registry) => {
        for (const key in registry) {
          if (registry[key] === Component) {
            return key;
          }
        }
      };
      name = inferFromRegistry(
        instance.components || instance.parent.type.components
      ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
  }
  function isClassComponent(value) {
    return isFunction$1(value) && "__vccOpts" in value;
  }
  function initCustomFormatter() {
    if (typeof window === "undefined") {
      return;
    }
    const vueStyle = { style: "color:#3ba776" };
    const numberStyle = { style: "color:#1677ff" };
    const stringStyle = { style: "color:#f5222d" };
    const keywordStyle = { style: "color:#eb2f96" };
    const formatter = {
      __vue_custom_formatter: true,
      header(obj) {
        if (!isObject(obj)) {
          return null;
        }
        if (obj.__isVue) {
          return ["div", vueStyle, `VueInstance`];
        } else if (isRef(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, genRefFlag(obj)],
            "<",
            // avoid debugger accessing value affecting behavior
            formatValue("_value" in obj ? obj._value : obj),
            `>`
          ];
        } else if (isReactive(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow(obj) ? "ShallowReactive" : "Reactive"],
            "<",
            formatValue(obj),
            `>${isReadonly(obj) ? ` (readonly)` : ``}`
          ];
        } else if (isReadonly(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow(obj) ? "ShallowReadonly" : "Readonly"],
            "<",
            formatValue(obj),
            ">"
          ];
        }
        return null;
      },
      hasBody(obj) {
        return obj && obj.__isVue;
      },
      body(obj) {
        if (obj && obj.__isVue) {
          return [
            "div",
            {},
            ...formatInstance(obj.$)
          ];
        }
      }
    };
    function formatInstance(instance) {
      const blocks = [];
      if (instance.type.props && instance.props) {
        blocks.push(createInstanceBlock("props", toRaw(instance.props)));
      }
      if (instance.setupState !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("setup", instance.setupState));
      }
      if (instance.data !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("data", toRaw(instance.data)));
      }
      const computed2 = extractKeys(instance, "computed");
      if (computed2) {
        blocks.push(createInstanceBlock("computed", computed2));
      }
      const injected = extractKeys(instance, "inject");
      if (injected) {
        blocks.push(createInstanceBlock("injected", injected));
      }
      blocks.push([
        "div",
        {},
        [
          "span",
          {
            style: keywordStyle.style + ";opacity:0.66"
          },
          "$ (internal): "
        ],
        ["object", { object: instance }]
      ]);
      return blocks;
    }
    function createInstanceBlock(type, target) {
      target = extend({}, target);
      if (!Object.keys(target).length) {
        return ["span", {}];
      }
      return [
        "div",
        { style: "line-height:1.25em;margin-bottom:0.6em" },
        [
          "div",
          {
            style: "color:#476582"
          },
          type
        ],
        [
          "div",
          {
            style: "padding-left:1.25em"
          },
          ...Object.keys(target).map((key) => {
            return [
              "div",
              {},
              ["span", keywordStyle, key + ": "],
              formatValue(target[key], false)
            ];
          })
        ]
      ];
    }
    function formatValue(v, asRaw = true) {
      if (typeof v === "number") {
        return ["span", numberStyle, v];
      } else if (typeof v === "string") {
        return ["span", stringStyle, JSON.stringify(v)];
      } else if (typeof v === "boolean") {
        return ["span", keywordStyle, v];
      } else if (isObject(v)) {
        return ["object", { object: asRaw ? toRaw(v) : v }];
      } else {
        return ["span", stringStyle, String(v)];
      }
    }
    function extractKeys(instance, type) {
      const Comp = instance.type;
      if (isFunction$1(Comp)) {
        return;
      }
      const extracted = {};
      for (const key in instance.ctx) {
        if (isKeyOfType(Comp, key, type)) {
          extracted[key] = instance.ctx[key];
        }
      }
      return extracted;
    }
    function isKeyOfType(Comp, key, type) {
      const opts = Comp[type];
      if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
        return true;
      }
      if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
        return true;
      }
      if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
        return true;
      }
    }
    function genRefFlag(v) {
      if (isShallow(v)) {
        return `ShallowRef`;
      }
      if (v.effect) {
        return `ComputedRef`;
      }
      return `Ref`;
    }
    if (window.devtoolsFormatters) {
      window.devtoolsFormatters.push(formatter);
    } else {
      window.devtoolsFormatters = [formatter];
    }
  }
  /**
  * vue v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  function initDev() {
    {
      initCustomFormatter();
    }
  }
  {
    initDev();
  }
  /*!
   * pinia v3.0.1
   * (c) 2025 Eduardo San Martin Morote
   * @license MIT
   */
  var MutationType;
  (function(MutationType2) {
    MutationType2["direct"] = "direct";
    MutationType2["patchObject"] = "patch object";
    MutationType2["patchFunction"] = "patch function";
  })(MutationType || (MutationType = {}));
  background;
  background;
  background;
  const isFunction = (value) => {
    return !!(value && value.constructor && value.call && value.apply);
  };
  const isPromise = (value) => {
    if (!value)
      return false;
    if (!value.then)
      return false;
    if (!isFunction(value.then))
      return false;
    return true;
  };
  const tryit = (func) => {
    return (...args) => {
      try {
        const result2 = func(...args);
        if (isPromise(result2)) {
          return result2.then((value) => [void 0, value]).catch((err) => [err, void 0]);
        }
        return [void 0, result2];
      } catch (err) {
        return [err, void 0];
      }
    };
  };
  class SatsnetStp {
    // Use WasmResponse for the result type
    async _handleRequest(methodName, ...args) {
      console.log("stp method", methodName);
      console.log("stp arg", args);
      const globalStp = globalThis.stp_wasm;
      const stpModuleTyped = globalStp ? globalStp : void 0;
      if (!stpModuleTyped || typeof stpModuleTyped[methodName] !== "function") {
        const errorMsg = `stp_wasm or method "${methodName}" not found on globalThis.`;
        console.error(errorMsg);
        return [new Error(errorMsg), void 0];
      }
      const method = stpModuleTyped[methodName];
      const [err, result2] = await tryit(method)(...args);
      if (err) {
        console.error(`stp ${methodName} error: ${err.message}`);
        return [err, void 0];
      }
      if (result2 && typeof result2.code === "number" && result2.code !== 0) {
        const errorMsg = result2.msg || `stp ${methodName} failed with code ${result2.code}`;
        console.error(errorMsg);
        return [new Error(errorMsg), void 0];
      }
      return [void 0, result2 == null ? void 0 : result2.data];
    }
    async closeChannel(chanPoint, feeRate, force) {
      return this._handleRequest(
        "closeChannel",
        // Pass method name as string (keyof StpWasmModule)
        chanPoint,
        String(feeRate),
        force
      );
    }
    async isWalletExisting() {
      return this._handleRequest("isWalletExisting");
    }
    async createWallet(password) {
      return this._handleRequest(
        "createWallet",
        password.toString()
      );
    }
    async switchWallet(id) {
      return this._handleRequest("switchWallet", id);
    }
    async switchAccount(id) {
      return this._handleRequest("switchAccount", id);
    }
    async hello() {
      return this._handleRequest("hello");
    }
    async start() {
      return this._handleRequest("start");
    }
    async importWallet(mnemonic, password) {
      return this._handleRequest(
        "importWallet",
        mnemonic,
        password.toString()
      );
    }
    async init(cfg, logLevel2) {
      return this._handleRequest("init", cfg, logLevel2);
    }
    async getVersion() {
      return this._handleRequest("getVersion");
    }
    async registerCallback(cb) {
      return this._handleRequest(
        "registerCallback",
        cb
      );
    }
    async lockUtxo(address, utxo, reason) {
      return this._handleRequest("lockUtxo", address, utxo, reason);
    }
    async lockUtxo_SatsNet(address, utxo, reason) {
      return this._handleRequest(
        "lockUtxo_SatsNet",
        address,
        utxo,
        reason
      );
    }
    async unlockUtxo(address, utxo) {
      return this._handleRequest("unlockUtxo", address, utxo);
    }
    async unlockUtxo_SatsNet(address, utxo) {
      return this._handleRequest(
        "unlockUtxo_SatsNet",
        address,
        utxo
      );
    }
    async getAllLockedUtxo(address) {
      return this._handleRequest(
        "getAllLockedUtxo",
        address
      );
    }
    async getAllLockedUtxo_SatsNet(address) {
      return this._handleRequest(
        "getAllLockedUtxo_SatsNet",
        address
      );
    }
    async openChannel(feeRate, amt, utxoList, memo) {
      return this._handleRequest(
        "openChannel",
        String(feeRate),
        String(amt),
        utxoList,
        memo
      );
    }
    async release() {
      return this._handleRequest("release");
    }
    async getWallet() {
      return this._handleRequest("getWallet");
    }
    async getTickerInfo(asset) {
      return this._handleRequest(
        "getTickerInfo",
        asset
      );
    }
    async runesAmtV2ToV3(asset, assetAmt) {
      return this._handleRequest(
        "runesAmtV2ToV3",
        asset,
        assetAmt
        // Keep original type, WASM might handle number/string
      );
    }
    async runesAmtV3ToV2(asset, assetAmt) {
      return this._handleRequest(
        "runesAmtV3ToV2",
        asset,
        String(assetAmt)
        // Explicitly convert to string if required by WASM
      );
    }
    async getAllChannels() {
      return this._handleRequest("getAllChannels");
    }
    async getChannel(id) {
      return this._handleRequest("getChannel", id);
    }
    async getChannelStatus(id) {
      return this._handleRequest(
        "getChannelStatus",
        id
      );
    }
    async sendAssets_SatsNet(address, assetName, amt) {
      return this._handleRequest(
        "sendAssets_SatsNet",
        address,
        assetName,
        String(amt)
      );
    }
    async sendAssets(address, assetName, amt, feeRate) {
      return this._handleRequest(
        "sendAssets",
        address,
        assetName,
        String(amt),
        String(feeRate)
      );
    }
    async deposit(destAddr, assetName, amt, utxos, fees, feeRate) {
      return this._handleRequest(
        "deposit",
        destAddr,
        assetName,
        amt,
        // Keep original type
        utxos,
        fees,
        String(feeRate)
      );
    }
    async withdraw(destAddr, assetName, amt, utxos, fees, feeRate) {
      return this._handleRequest(
        "withdraw",
        destAddr,
        assetName,
        amt,
        // Keep original type
        utxos,
        fees,
        String(feeRate)
      );
    }
    async unlockWallet(password) {
      return this._handleRequest(
        "unlockWallet",
        password.toString()
      );
    }
    async getMnemonice(password) {
      return this._handleRequest(
        "getMnemonice",
        password.toString()
      );
    }
    async splicingIn(chanPoint, assetName, utxos, fees, feeRate, amt) {
      return this._handleRequest(
        "splicingIn",
        chanPoint,
        assetName,
        utxos,
        fees,
        String(feeRate),
        String(amt)
      );
    }
    async splicingOut(chanPoint, toAddress, assetName, fees, feeRate, amt) {
      return this._handleRequest(
        "splicingOut",
        chanPoint,
        toAddress,
        assetName,
        fees,
        String(feeRate),
        String(amt)
      );
    }
    async lockToChannel(chanPoint, assetName, amt, utxos, feeUtxoList) {
      return this._handleRequest(
        "lockToChannel",
        chanPoint,
        assetName,
        String(amt),
        utxos,
        feeUtxoList
      );
    }
    async unlockFromChannel(channelUtxo, assetName, amt, feeUtxoList) {
      return this._handleRequest(
        "unlockFromChannel",
        channelUtxo,
        assetName,
        String(amt),
        feeUtxoList
      );
    }
    // --- Added UTXO Getter Methods ---
    async getUtxos() {
      return this._handleRequest("getUtxos");
    }
    async getUtxos_SatsNet() {
      return this._handleRequest("getUtxos_SatsNet");
    }
    async getUtxosWithAsset(address, amt, assetName) {
      return this._handleRequest("getUtxosWithAsset", address, amt, assetName);
    }
    async getUtxosWithAsset_SatsNet(address, amt, assetName) {
      return this._handleRequest("getUtxosWithAsset_SatsNet", address, amt, assetName);
    }
    async getUtxosWithAssetV2(address, amt, assetName) {
      return this._handleRequest("getUtxosWithAssetV2", address, amt, assetName);
    }
    async getUtxosWithAssetV2_SatsNet(address, amt, assetName) {
      return this._handleRequest("getUtxosWithAssetV2_SatsNet", address, amt, assetName);
    }
    // --- End Added UTXO Getter Methods ---
    // --- Added Asset Amount Getter Methods ---
    async getAssetAmount(address, assetName) {
      return this._handleRequest("getAssetAmount", address, assetName);
    }
    async getAssetAmount_SatsNet(address, assetName) {
      return this._handleRequest("getAssetAmount_SatsNet", address, assetName);
    }
    async batchSendAssets_SatsNet(destAddr, assetName, amt, n) {
      return this._handleRequest("batchSendAssets_SatsNet", destAddr, assetName, amt, n);
    }
    async getTxAssetInfoFromPsbt(psbtHex, network) {
      return this._handleRequest("getTxAssetInfoFromPsbt", psbtHex, network);
    }
    async getTxAssetInfoFromPsbt_SatsNet(psbtHex, network) {
      return this._handleRequest("getTxAssetInfoFromPsbt_SatsNet", psbtHex, network);
    }
    async getCommitTxAssetInfo(channelId) {
      return this._handleRequest("getCommitTxAssetInfo", channelId);
    }
    // --- End Added Asset Amount Getter Methods ---
  }
  const stp = new SatsnetStp();
  background;
  class Service {
    async getHasWallet() {
      console.log("walletStorage:", walletStorage);
      const hasWallet = walletStorage.getValue("hasWallet");
      console.log("walletStorage.hasWallet:", hasWallet);
      return hasWallet;
    }
    async getAccounts() {
      const address = walletStorage.getValue("address");
      return address ? [address] : [];
    }
    async getNetwork() {
      return walletStorage.getValue("network");
    }
    async getPublicKey() {
      const pubkey = walletStorage.getValue("pubkey");
      if (!pubkey) {
        throw new Error("Public key not available");
      }
      return pubkey;
    }
    async getBalance() {
      return walletStorage.getValue("balance");
    }
    async pushTx(rawtx) {
      const network = walletStorage.getValue("network");
      const res = await ordxApi.pushTx({ hex: rawtx, network });
      if (res.code === 0) {
        return [void 0, res.data];
      } else {
        return [new Error(res.msg), void 0];
      }
    }
    async pushPsbt(psbtHex) {
      console.log("pushPsbt", psbtHex);
      const txHexRes = await globalThis.sat20wallet_wasm.extractTxFromPsbt(psbtHex);
      const txHex = txHexRes.data.tx;
      const network = walletStorage.getValue("network");
      const res = await ordxApi.pushTx({ hex: txHex, network });
      console.log("res", res);
      if (res.code === 0) {
        return [void 0, res.data];
      } else {
        return [new Error(res.msg), void 0];
      }
    }
    async extractTxFromPsbt(psbtHex, { chain }) {
      let res = null;
      if (chain === "btc") {
        res = await globalThis.sat20wallet_wasm.extractTxFromPsbt(psbtHex);
      } else {
        res = await globalThis.sat20wallet_wasm.extractTxFromPsbt_SatsNet(psbtHex);
      }
      if (res.code === 0) {
        return [void 0, res.data];
      } else {
        return [new Error(res.msg), void 0];
      }
    }
    async buildBatchSellOrder_SatsNet(utxos, address, network) {
      console.log("buildBatchSellOrder_SatsNet", utxos, address, network);
      const res = await globalThis.sat20wallet_wasm.buildBatchSellOrder_SatsNet(
        utxos,
        address,
        network
      );
      console.log("res", res);
      return res;
    }
    async splitBatchSignedPsbt(signedHex, network) {
      console.log("splitBatchSignedPsbt", signedHex, network);
      const res = globalThis.sat20wallet_wasm.splitBatchSignedPsbt(
        signedHex,
        network
      );
      console.log("splitBatchSignedPsbt res", res);
      return res;
    }
    async splitBatchSignedPsbt_SatsNet(signedHex, network) {
      const res = globalThis.sat20wallet_wasm.splitBatchSignedPsbt_SatsNet(
        signedHex,
        network
      );
      return res;
    }
    async mergeBatchSignedPsbt_SatsNet(psbts, network) {
      const res = globalThis.sat20wallet_wasm.mergeBatchSignedPsbt_SatsNet(
        psbts,
        network
      );
      return res;
    }
    async finalizeSellOrder_SatsNet(psbtHex, utxos, buyerAddress, serverAddress, network, serviceFee, networkFee) {
      console.log("finalizeSellOrder_SatsNet", {
        psbtHex,
        utxos,
        buyerAddress,
        serverAddress,
        network,
        serviceFee,
        networkFee
      });
      const result2 = await globalThis.sat20wallet_wasm.finalizeSellOrder_SatsNet(
        psbtHex,
        utxos,
        buyerAddress,
        serverAddress,
        network,
        serviceFee,
        networkFee
      );
      if (result2.code === 0) {
        return [void 0, result2.data];
      } else {
        return [new Error(result2.msg), void 0];
      }
    }
    async addInputsToPsbt(psbtHex, utxos) {
      console.log("addInputsToPsbt", { psbtHex, utxos });
      const [err, res] = await globalThis.sat20wallet_wasm.addInputsToPsbt(
        psbtHex,
        utxos
      );
      if (err) {
        return [err, void 0];
      }
      return [void 0, res];
    }
    async addOutputsToPsbt(psbtHex, utxos) {
      console.log("addOutputsToPsbt", { psbtHex, utxos });
      const [err, res] = await globalThis.sat20wallet_wasm.addOutputsToPsbt(
        psbtHex,
        utxos
      );
      if (err) {
        return [err, void 0];
      }
      return [void 0, res];
    }
    async lockUtxo(address, utxo, reason) {
      return stp.lockUtxo(address, utxo, reason);
    }
    async lockUtxo_SatsNet(address, utxo, reason) {
      return stp.lockUtxo_SatsNet(address, utxo, reason);
    }
    async unlockUtxo(address, utxo) {
      return stp.unlockUtxo(address, utxo);
    }
    async unlockUtxo_SatsNet(address, utxo) {
      return stp.unlockUtxo_SatsNet(address, utxo);
    }
    async getAllLockedUtxo(address) {
      return stp.getAllLockedUtxo(address);
    }
    async getAllLockedUtxo_SatsNet(address) {
      return stp.getAllLockedUtxo_SatsNet(address);
    }
    async lockToChannel(chanPoint, assetName, amt, utxos, feeUtxoList) {
      return stp.lockToChannel(chanPoint, assetName, amt, utxos, feeUtxoList);
    }
    async unlockFromChannel(channelUtxo, assetName, amt, feeUtxoList) {
      return stp.unlockFromChannel(channelUtxo, assetName, amt, feeUtxoList);
    }
    async getUtxos() {
      return stp.getUtxos();
    }
    async getUtxos_SatsNet() {
      return stp.getUtxos_SatsNet();
    }
    async getUtxosWithAsset(address, amt, assetName) {
      return stp.getUtxosWithAsset(address, amt, assetName);
    }
    async getUtxosWithAsset_SatsNet(address, amt, assetName) {
      return stp.getUtxosWithAsset_SatsNet(address, amt.toString(), assetName);
    }
    async getUtxosWithAssetV2(address, amt, assetName) {
      return stp.getUtxosWithAssetV2(address, amt, assetName);
    }
    async getUtxosWithAssetV2_SatsNet(address, amt, assetName) {
      return stp.getUtxosWithAssetV2_SatsNet(address, amt, assetName);
    }
    async getAssetAmount(address, assetName) {
      return stp.getAssetAmount(address, assetName);
    }
    async getAssetAmount_SatsNet(address, assetName) {
      return stp.getAssetAmount_SatsNet(address, assetName);
    }
    async getTickerInfo(asset) {
      return stp.getTickerInfo(asset);
    }
  }
  const service = new Service();
  background;
  const browser = (
    // @ts-expect-error
    ((_d = (_c = globalThis.browser) == null ? void 0 : _c.runtime) == null ? void 0 : _d.id) == null ? globalThis.chrome : (
      // @ts-expect-error
      globalThis.browser
    )
  );
  const createPopup = (url, options = {}) => {
    const { width = 375, height = 700 } = options;
    return new Promise((resolve) => {
      browser.windows.create(
        {
          url,
          type: "popup",
          width,
          height
        },
        (newWindow) => {
          resolve(newWindow);
        }
      );
    });
  };
  background;
  var Message;
  ((Message2) => {
    ((Channel2) => {
      Channel2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Channel2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Channel || (Message2.Channel = {}));
    ((Port2) => {
      Port2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Port2["CONTENT_BG"] = "CONTENT_BG";
      Port2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Port || (Message2.Port = {}));
    ((MessageType2) => {
      MessageType2["REQUEST"] = "REQUEST";
      MessageType2["APPROVE"] = "APPROVE";
      MessageType2["EVENT"] = "EVENT";
      MessageType2["CONNECTION_READY"] = "CONNECTION_READY";
    })(Message2.MessageType || (Message2.MessageType = {}));
    ((MessageFrom2) => {
      MessageFrom2["INJECTED"] = "INJECTED";
      MessageFrom2["CONTENT"] = "CONTENT";
      MessageFrom2["BACKGROUND"] = "BACKGROUND";
      MessageFrom2["POPUP"] = "POPUP";
      MessageFrom2["SETTINGS_PAGE"] = "settings_page";
    })(Message2.MessageFrom || (Message2.MessageFrom = {}));
    ((MessageTo2) => {
      MessageTo2["INJECTED"] = "INJECTED";
      MessageTo2["CONTENT"] = "CONTENT";
      MessageTo2["BACKGROUND"] = "BACKGROUND";
      MessageTo2["POPUP"] = "POPUP";
    })(Message2.MessageTo || (Message2.MessageTo = {}));
    ((MessageAction2) => {
      MessageAction2["GET_APPROVE_DATA"] = "GET_APPROVE_DATA";
      MessageAction2["GET_APPROVE_DATA_RESPONSE"] = "GET_APPROVE_DATA_RESPONSE";
      MessageAction2["APPROVE_RESPONSE"] = "APPROVE_RESPONSE";
      MessageAction2["REJECT_RESPONSE"] = "REJECT_RESPONSE";
      MessageAction2["REQUEST_ACCOUNTS"] = "REQUEST_ACCOUNTS";
      MessageAction2["GET_ACCOUNTS"] = "GET_ACCOUNTS";
      MessageAction2["GET_NETWORK"] = "GET_NETWORK";
      MessageAction2["SWITCH_NETWORK"] = "SWITCH_NETWORK";
      MessageAction2["GET_PUBLIC_KEY"] = "GET_PUBLIC_KEY";
      MessageAction2["BUILD_BATCH_SELL_ORDER"] = "BUILD_BATCH_SELL_ORDER";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT"] = "SPLIT_BATCH_SIGNED_PSBT";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT_SATSNET"] = "SPLIT_BATCH_SIGNED_PSBT_SATSNET";
      MessageAction2["GET_BALANCE"] = "GET_BALANCE";
      MessageAction2["SEND_BITCOIN"] = "SEND_BITCOIN";
      MessageAction2["SIGN_MESSAGE"] = "SIGN_MESSAGE";
      MessageAction2["SIGN_PSBT"] = "SIGN_PSBT";
      MessageAction2["SIGN_PSBTS"] = "SIGN_PSBTS";
      MessageAction2["PUSH_TX"] = "PUSH_TX";
      MessageAction2["PUSH_PSBT"] = "PUSH_PSBT";
      MessageAction2["GET_INSCRIPTIONS"] = "GET_INSCRIPTIONS";
      MessageAction2["SEND_INSCRIPTION"] = "SEND_INSCRIPTION";
      MessageAction2["FINALIZE_SELL_ORDER"] = "FINALIZE_SELL_ORDER";
      MessageAction2["MERGE_BATCH_SIGNED_PSBT"] = "MERGE_BATCH_SIGNED_PSBT";
      MessageAction2["ADD_INPUTS_TO_PSBT"] = "ADD_INPUTS_TO_PSBT";
      MessageAction2["ADD_OUTPUTS_TO_PSBT"] = "ADD_OUTPUTS_TO_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT"] = "EXTRACT_TX_FROM_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT_SATSNET"] = "EXTRACT_TX_FROM_PSBT_SATSNET";
      MessageAction2["BACKGROUND_MESSAGE"] = "BACKGROUND_MESSAGE";
      MessageAction2["BACKGROUND_RECONNECT"] = "BACKGROUND_RECONNECT";
      MessageAction2["EVENT_MESSAGE"] = "EVENT_MESSAGE";
      MessageAction2["CONNECTION_CHECK"] = "CONNECTION_CHECK";
      MessageAction2["SPLIT_ASSET"] = "SPLIT_ASSET";
      MessageAction2["BATCH_SEND_ASSETS_SATSNET"] = "BATCH_SEND_ASSETS_SATSNET";
      MessageAction2["LOCK_UTXO"] = "LOCK_UTXO";
      MessageAction2["LOCK_UTXO_SATSNET"] = "LOCK_UTXO_SATSNET";
      MessageAction2["UNLOCK_UTXO"] = "UNLOCK_UTXO";
      MessageAction2["UNLOCK_UTXO_SATSNET"] = "UNLOCK_UTXO_SATSNET";
      MessageAction2["GET_ALL_LOCKED_UTXO"] = "GET_ALL_LOCKED_UTXO";
      MessageAction2["GET_ALL_LOCKED_UTXO_SATSNET"] = "GET_ALL_LOCKED_UTXO_SATSNET";
      MessageAction2["LOCK_TO_CHANNEL"] = "LOCK_TO_CHANNEL";
      MessageAction2["UNLOCK_FROM_CHANNEL"] = "UNLOCK_FROM_CHANNEL";
      MessageAction2["GET_UTXOS"] = "GET_UTXOS";
      MessageAction2["GET_UTXOS_SATSNET"] = "GET_UTXOS_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET"] = "GET_UTXOS_WITH_ASSET";
      MessageAction2["GET_UTXOS_WITH_ASSET_SATSNET"] = "GET_UTXOS_WITH_ASSET_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2"] = "GET_UTXOS_WITH_ASSET_V2";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2_SATSNET"] = "GET_UTXOS_WITH_ASSET_V2_SATSNET";
      MessageAction2["GET_ASSET_AMOUNT"] = "GET_ASSET_AMOUNT";
      MessageAction2["GET_ASSET_AMOUNT_SATSNET"] = "GET_ASSET_AMOUNT_SATSNET";
      MessageAction2["ENV_CHANGED"] = "ENV_CHANGED";
      MessageAction2["GET_TICKER_INFO"] = "GET_TICKER_INFO";
    })(Message2.MessageAction || (Message2.MessageAction = {}));
  })(Message || (Message = {}));
  background;
  var buffer = {};
  var base64Js = {};
  var hasRequiredBase64Js;
  function requireBase64Js() {
    if (hasRequiredBase64Js) return base64Js;
    hasRequiredBase64Js = 1;
    base64Js.byteLength = byteLength;
    base64Js.toByteArray = toByteArray;
    base64Js.fromByteArray = fromByteArray;
    var lookup = [];
    var revLookup = [];
    var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
    var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (var i = 0, len = code.length; i < len; ++i) {
      lookup[i] = code[i];
      revLookup[code.charCodeAt(i)] = i;
    }
    revLookup["-".charCodeAt(0)] = 62;
    revLookup["_".charCodeAt(0)] = 63;
    function getLens(b64) {
      var len2 = b64.length;
      if (len2 % 4 > 0) {
        throw new Error("Invalid string. Length must be a multiple of 4");
      }
      var validLen = b64.indexOf("=");
      if (validLen === -1) validLen = len2;
      var placeHoldersLen = validLen === len2 ? 0 : 4 - validLen % 4;
      return [validLen, placeHoldersLen];
    }
    function byteLength(b64) {
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function _byteLength(b64, validLen, placeHoldersLen) {
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }
    function toByteArray(b64) {
      var tmp;
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
      var curByte = 0;
      var len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
      var i2;
      for (i2 = 0; i2 < len2; i2 += 4) {
        tmp = revLookup[b64.charCodeAt(i2)] << 18 | revLookup[b64.charCodeAt(i2 + 1)] << 12 | revLookup[b64.charCodeAt(i2 + 2)] << 6 | revLookup[b64.charCodeAt(i2 + 3)];
        arr[curByte++] = tmp >> 16 & 255;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i2)] << 2 | revLookup[b64.charCodeAt(i2 + 1)] >> 4;
        arr[curByte++] = tmp & 255;
      }
      if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i2)] << 10 | revLookup[b64.charCodeAt(i2 + 1)] << 4 | revLookup[b64.charCodeAt(i2 + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 255;
        arr[curByte++] = tmp & 255;
      }
      return arr;
    }
    function tripletToBase64(num) {
      return lookup[num >> 18 & 63] + lookup[num >> 12 & 63] + lookup[num >> 6 & 63] + lookup[num & 63];
    }
    function encodeChunk(uint8, start, end) {
      var tmp;
      var output = [];
      for (var i2 = start; i2 < end; i2 += 3) {
        tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (uint8[i2 + 2] & 255);
        output.push(tripletToBase64(tmp));
      }
      return output.join("");
    }
    function fromByteArray(uint8) {
      var tmp;
      var len2 = uint8.length;
      var extraBytes = len2 % 3;
      var parts = [];
      var maxChunkLength = 16383;
      for (var i2 = 0, len22 = len2 - extraBytes; i2 < len22; i2 += maxChunkLength) {
        parts.push(encodeChunk(uint8, i2, i2 + maxChunkLength > len22 ? len22 : i2 + maxChunkLength));
      }
      if (extraBytes === 1) {
        tmp = uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 2] + lookup[tmp << 4 & 63] + "=="
        );
      } else if (extraBytes === 2) {
        tmp = (uint8[len2 - 2] << 8) + uint8[len2 - 1];
        parts.push(
          lookup[tmp >> 10] + lookup[tmp >> 4 & 63] + lookup[tmp << 2 & 63] + "="
        );
      }
      return parts.join("");
    }
    return base64Js;
  }
  var ieee754 = {};
  /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
  var hasRequiredIeee754;
  function requireIeee754() {
    if (hasRequiredIeee754) return ieee754;
    hasRequiredIeee754 = 1;
    ieee754.read = function(buffer2, offset, isLE, mLen, nBytes) {
      var e, m;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var nBits = -7;
      var i = isLE ? nBytes - 1 : 0;
      var d = isLE ? -1 : 1;
      var s = buffer2[offset + i];
      i += d;
      e = s & (1 << -nBits) - 1;
      s >>= -nBits;
      nBits += eLen;
      for (; nBits > 0; e = e * 256 + buffer2[offset + i], i += d, nBits -= 8) {
      }
      m = e & (1 << -nBits) - 1;
      e >>= -nBits;
      nBits += mLen;
      for (; nBits > 0; m = m * 256 + buffer2[offset + i], i += d, nBits -= 8) {
      }
      if (e === 0) {
        e = 1 - eBias;
      } else if (e === eMax) {
        return m ? NaN : (s ? -1 : 1) * Infinity;
      } else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
      }
      return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
    };
    ieee754.write = function(buffer2, value, offset, isLE, mLen, nBytes) {
      var e, m, c;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
      var i = isLE ? 0 : nBytes - 1;
      var d = isLE ? 1 : -1;
      var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
      value = Math.abs(value);
      if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
      } else {
        e = Math.floor(Math.log(value) / Math.LN2);
        if (value * (c = Math.pow(2, -e)) < 1) {
          e--;
          c *= 2;
        }
        if (e + eBias >= 1) {
          value += rt / c;
        } else {
          value += rt * Math.pow(2, 1 - eBias);
        }
        if (value * c >= 2) {
          e++;
          c /= 2;
        }
        if (e + eBias >= eMax) {
          m = 0;
          e = eMax;
        } else if (e + eBias >= 1) {
          m = (value * c - 1) * Math.pow(2, mLen);
          e = e + eBias;
        } else {
          m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
          e = 0;
        }
      }
      for (; mLen >= 8; buffer2[offset + i] = m & 255, i += d, m /= 256, mLen -= 8) {
      }
      e = e << mLen | m;
      eLen += mLen;
      for (; eLen > 0; buffer2[offset + i] = e & 255, i += d, e /= 256, eLen -= 8) {
      }
      buffer2[offset + i - d] |= s * 128;
    };
    return ieee754;
  }
  /*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  var hasRequiredBuffer;
  function requireBuffer() {
    if (hasRequiredBuffer) return buffer;
    hasRequiredBuffer = 1;
    (function(exports) {
      const base64 = requireBase64Js();
      const ieee7542 = requireIeee754();
      const customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" ? Symbol["for"]("nodejs.util.inspect.custom") : null;
      exports.Buffer = Buffer2;
      exports.SlowBuffer = SlowBuffer;
      exports.INSPECT_MAX_BYTES = 50;
      const K_MAX_LENGTH = 2147483647;
      exports.kMaxLength = K_MAX_LENGTH;
      Buffer2.TYPED_ARRAY_SUPPORT = typedArraySupport();
      if (!Buffer2.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
        console.error(
          "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
        );
      }
      function typedArraySupport() {
        try {
          const arr = new Uint8Array(1);
          const proto = { foo: function() {
            return 42;
          } };
          Object.setPrototypeOf(proto, Uint8Array.prototype);
          Object.setPrototypeOf(arr, proto);
          return arr.foo() === 42;
        } catch (e) {
          return false;
        }
      }
      Object.defineProperty(Buffer2.prototype, "parent", {
        enumerable: true,
        get: function() {
          if (!Buffer2.isBuffer(this)) return void 0;
          return this.buffer;
        }
      });
      Object.defineProperty(Buffer2.prototype, "offset", {
        enumerable: true,
        get: function() {
          if (!Buffer2.isBuffer(this)) return void 0;
          return this.byteOffset;
        }
      });
      function createBuffer(length) {
        if (length > K_MAX_LENGTH) {
          throw new RangeError('The value "' + length + '" is invalid for option "size"');
        }
        const buf = new Uint8Array(length);
        Object.setPrototypeOf(buf, Buffer2.prototype);
        return buf;
      }
      function Buffer2(arg, encodingOrOffset, length) {
        if (typeof arg === "number") {
          if (typeof encodingOrOffset === "string") {
            throw new TypeError(
              'The "string" argument must be of type string. Received type number'
            );
          }
          return allocUnsafe(arg);
        }
        return from(arg, encodingOrOffset, length);
      }
      Buffer2.poolSize = 8192;
      function from(value, encodingOrOffset, length) {
        if (typeof value === "string") {
          return fromString(value, encodingOrOffset);
        }
        if (ArrayBuffer.isView(value)) {
          return fromArrayView(value);
        }
        if (value == null) {
          throw new TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
          );
        }
        if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) {
          return fromArrayBuffer(value, encodingOrOffset, length);
        }
        if (typeof value === "number") {
          throw new TypeError(
            'The "value" argument must not be of type number. Received type number'
          );
        }
        const valueOf = value.valueOf && value.valueOf();
        if (valueOf != null && valueOf !== value) {
          return Buffer2.from(valueOf, encodingOrOffset, length);
        }
        const b = fromObject(value);
        if (b) return b;
        if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") {
          return Buffer2.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
        }
        throw new TypeError(
          "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value
        );
      }
      Buffer2.from = function(value, encodingOrOffset, length) {
        return from(value, encodingOrOffset, length);
      };
      Object.setPrototypeOf(Buffer2.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(Buffer2, Uint8Array);
      function assertSize(size) {
        if (typeof size !== "number") {
          throw new TypeError('"size" argument must be of type number');
        } else if (size < 0) {
          throw new RangeError('The value "' + size + '" is invalid for option "size"');
        }
      }
      function alloc(size, fill, encoding) {
        assertSize(size);
        if (size <= 0) {
          return createBuffer(size);
        }
        if (fill !== void 0) {
          return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
        }
        return createBuffer(size);
      }
      Buffer2.alloc = function(size, fill, encoding) {
        return alloc(size, fill, encoding);
      };
      function allocUnsafe(size) {
        assertSize(size);
        return createBuffer(size < 0 ? 0 : checked(size) | 0);
      }
      Buffer2.allocUnsafe = function(size) {
        return allocUnsafe(size);
      };
      Buffer2.allocUnsafeSlow = function(size) {
        return allocUnsafe(size);
      };
      function fromString(string, encoding) {
        if (typeof encoding !== "string" || encoding === "") {
          encoding = "utf8";
        }
        if (!Buffer2.isEncoding(encoding)) {
          throw new TypeError("Unknown encoding: " + encoding);
        }
        const length = byteLength(string, encoding) | 0;
        let buf = createBuffer(length);
        const actual = buf.write(string, encoding);
        if (actual !== length) {
          buf = buf.slice(0, actual);
        }
        return buf;
      }
      function fromArrayLike(array) {
        const length = array.length < 0 ? 0 : checked(array.length) | 0;
        const buf = createBuffer(length);
        for (let i = 0; i < length; i += 1) {
          buf[i] = array[i] & 255;
        }
        return buf;
      }
      function fromArrayView(arrayView) {
        if (isInstance(arrayView, Uint8Array)) {
          const copy = new Uint8Array(arrayView);
          return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
        }
        return fromArrayLike(arrayView);
      }
      function fromArrayBuffer(array, byteOffset, length) {
        if (byteOffset < 0 || array.byteLength < byteOffset) {
          throw new RangeError('"offset" is outside of buffer bounds');
        }
        if (array.byteLength < byteOffset + (length || 0)) {
          throw new RangeError('"length" is outside of buffer bounds');
        }
        let buf;
        if (byteOffset === void 0 && length === void 0) {
          buf = new Uint8Array(array);
        } else if (length === void 0) {
          buf = new Uint8Array(array, byteOffset);
        } else {
          buf = new Uint8Array(array, byteOffset, length);
        }
        Object.setPrototypeOf(buf, Buffer2.prototype);
        return buf;
      }
      function fromObject(obj) {
        if (Buffer2.isBuffer(obj)) {
          const len = checked(obj.length) | 0;
          const buf = createBuffer(len);
          if (buf.length === 0) {
            return buf;
          }
          obj.copy(buf, 0, 0, len);
          return buf;
        }
        if (obj.length !== void 0) {
          if (typeof obj.length !== "number" || numberIsNaN(obj.length)) {
            return createBuffer(0);
          }
          return fromArrayLike(obj);
        }
        if (obj.type === "Buffer" && Array.isArray(obj.data)) {
          return fromArrayLike(obj.data);
        }
      }
      function checked(length) {
        if (length >= K_MAX_LENGTH) {
          throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
        }
        return length | 0;
      }
      function SlowBuffer(length) {
        if (+length != length) {
          length = 0;
        }
        return Buffer2.alloc(+length);
      }
      Buffer2.isBuffer = function isBuffer(b) {
        return b != null && b._isBuffer === true && b !== Buffer2.prototype;
      };
      Buffer2.compare = function compare(a, b) {
        if (isInstance(a, Uint8Array)) a = Buffer2.from(a, a.offset, a.byteLength);
        if (isInstance(b, Uint8Array)) b = Buffer2.from(b, b.offset, b.byteLength);
        if (!Buffer2.isBuffer(a) || !Buffer2.isBuffer(b)) {
          throw new TypeError(
            'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
          );
        }
        if (a === b) return 0;
        let x = a.length;
        let y = b.length;
        for (let i = 0, len = Math.min(x, y); i < len; ++i) {
          if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      Buffer2.isEncoding = function isEncoding(encoding) {
        switch (String(encoding).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      };
      Buffer2.concat = function concat(list, length) {
        if (!Array.isArray(list)) {
          throw new TypeError('"list" argument must be an Array of Buffers');
        }
        if (list.length === 0) {
          return Buffer2.alloc(0);
        }
        let i;
        if (length === void 0) {
          length = 0;
          for (i = 0; i < list.length; ++i) {
            length += list[i].length;
          }
        }
        const buffer2 = Buffer2.allocUnsafe(length);
        let pos = 0;
        for (i = 0; i < list.length; ++i) {
          let buf = list[i];
          if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer2.length) {
              if (!Buffer2.isBuffer(buf)) buf = Buffer2.from(buf);
              buf.copy(buffer2, pos);
            } else {
              Uint8Array.prototype.set.call(
                buffer2,
                buf,
                pos
              );
            }
          } else if (!Buffer2.isBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
          } else {
            buf.copy(buffer2, pos);
          }
          pos += buf.length;
        }
        return buffer2;
      };
      function byteLength(string, encoding) {
        if (Buffer2.isBuffer(string)) {
          return string.length;
        }
        if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
          return string.byteLength;
        }
        if (typeof string !== "string") {
          throw new TypeError(
            'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string
          );
        }
        const len = string.length;
        const mustMatch = arguments.length > 2 && arguments[2] === true;
        if (!mustMatch && len === 0) return 0;
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "ascii":
            case "latin1":
            case "binary":
              return len;
            case "utf8":
            case "utf-8":
              return utf8ToBytes(string).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return len * 2;
            case "hex":
              return len >>> 1;
            case "base64":
              return base64ToBytes(string).length;
            default:
              if (loweredCase) {
                return mustMatch ? -1 : utf8ToBytes(string).length;
              }
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer2.byteLength = byteLength;
      function slowToString(encoding, start, end) {
        let loweredCase = false;
        if (start === void 0 || start < 0) {
          start = 0;
        }
        if (start > this.length) {
          return "";
        }
        if (end === void 0 || end > this.length) {
          end = this.length;
        }
        if (end <= 0) {
          return "";
        }
        end >>>= 0;
        start >>>= 0;
        if (end <= start) {
          return "";
        }
        if (!encoding) encoding = "utf8";
        while (true) {
          switch (encoding) {
            case "hex":
              return hexSlice(this, start, end);
            case "utf8":
            case "utf-8":
              return utf8Slice(this, start, end);
            case "ascii":
              return asciiSlice(this, start, end);
            case "latin1":
            case "binary":
              return latin1Slice(this, start, end);
            case "base64":
              return base64Slice(this, start, end);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return utf16leSlice(this, start, end);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = (encoding + "").toLowerCase();
              loweredCase = true;
          }
        }
      }
      Buffer2.prototype._isBuffer = true;
      function swap(b, n, m) {
        const i = b[n];
        b[n] = b[m];
        b[m] = i;
      }
      Buffer2.prototype.swap16 = function swap16() {
        const len = this.length;
        if (len % 2 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        }
        for (let i = 0; i < len; i += 2) {
          swap(this, i, i + 1);
        }
        return this;
      };
      Buffer2.prototype.swap32 = function swap32() {
        const len = this.length;
        if (len % 4 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 32-bits");
        }
        for (let i = 0; i < len; i += 4) {
          swap(this, i, i + 3);
          swap(this, i + 1, i + 2);
        }
        return this;
      };
      Buffer2.prototype.swap64 = function swap64() {
        const len = this.length;
        if (len % 8 !== 0) {
          throw new RangeError("Buffer size must be a multiple of 64-bits");
        }
        for (let i = 0; i < len; i += 8) {
          swap(this, i, i + 7);
          swap(this, i + 1, i + 6);
          swap(this, i + 2, i + 5);
          swap(this, i + 3, i + 4);
        }
        return this;
      };
      Buffer2.prototype.toString = function toString() {
        const length = this.length;
        if (length === 0) return "";
        if (arguments.length === 0) return utf8Slice(this, 0, length);
        return slowToString.apply(this, arguments);
      };
      Buffer2.prototype.toLocaleString = Buffer2.prototype.toString;
      Buffer2.prototype.equals = function equals(b) {
        if (!Buffer2.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
        if (this === b) return true;
        return Buffer2.compare(this, b) === 0;
      };
      Buffer2.prototype.inspect = function inspect() {
        let str = "";
        const max = exports.INSPECT_MAX_BYTES;
        str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
        if (this.length > max) str += " ... ";
        return "<Buffer " + str + ">";
      };
      if (customInspectSymbol) {
        Buffer2.prototype[customInspectSymbol] = Buffer2.prototype.inspect;
      }
      Buffer2.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
        if (isInstance(target, Uint8Array)) {
          target = Buffer2.from(target, target.offset, target.byteLength);
        }
        if (!Buffer2.isBuffer(target)) {
          throw new TypeError(
            'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target
          );
        }
        if (start === void 0) {
          start = 0;
        }
        if (end === void 0) {
          end = target ? target.length : 0;
        }
        if (thisStart === void 0) {
          thisStart = 0;
        }
        if (thisEnd === void 0) {
          thisEnd = this.length;
        }
        if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
          throw new RangeError("out of range index");
        }
        if (thisStart >= thisEnd && start >= end) {
          return 0;
        }
        if (thisStart >= thisEnd) {
          return -1;
        }
        if (start >= end) {
          return 1;
        }
        start >>>= 0;
        end >>>= 0;
        thisStart >>>= 0;
        thisEnd >>>= 0;
        if (this === target) return 0;
        let x = thisEnd - thisStart;
        let y = end - start;
        const len = Math.min(x, y);
        const thisCopy = this.slice(thisStart, thisEnd);
        const targetCopy = target.slice(start, end);
        for (let i = 0; i < len; ++i) {
          if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
          }
        }
        if (x < y) return -1;
        if (y < x) return 1;
        return 0;
      };
      function bidirectionalIndexOf(buffer2, val, byteOffset, encoding, dir) {
        if (buffer2.length === 0) return -1;
        if (typeof byteOffset === "string") {
          encoding = byteOffset;
          byteOffset = 0;
        } else if (byteOffset > 2147483647) {
          byteOffset = 2147483647;
        } else if (byteOffset < -2147483648) {
          byteOffset = -2147483648;
        }
        byteOffset = +byteOffset;
        if (numberIsNaN(byteOffset)) {
          byteOffset = dir ? 0 : buffer2.length - 1;
        }
        if (byteOffset < 0) byteOffset = buffer2.length + byteOffset;
        if (byteOffset >= buffer2.length) {
          if (dir) return -1;
          else byteOffset = buffer2.length - 1;
        } else if (byteOffset < 0) {
          if (dir) byteOffset = 0;
          else return -1;
        }
        if (typeof val === "string") {
          val = Buffer2.from(val, encoding);
        }
        if (Buffer2.isBuffer(val)) {
          if (val.length === 0) {
            return -1;
          }
          return arrayIndexOf(buffer2, val, byteOffset, encoding, dir);
        } else if (typeof val === "number") {
          val = val & 255;
          if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) {
              return Uint8Array.prototype.indexOf.call(buffer2, val, byteOffset);
            } else {
              return Uint8Array.prototype.lastIndexOf.call(buffer2, val, byteOffset);
            }
          }
          return arrayIndexOf(buffer2, [val], byteOffset, encoding, dir);
        }
        throw new TypeError("val must be string, number or Buffer");
      }
      function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
        let indexSize = 1;
        let arrLength = arr.length;
        let valLength = val.length;
        if (encoding !== void 0) {
          encoding = String(encoding).toLowerCase();
          if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) {
              return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
          }
        }
        function read(buf, i2) {
          if (indexSize === 1) {
            return buf[i2];
          } else {
            return buf.readUInt16BE(i2 * indexSize);
          }
        }
        let i;
        if (dir) {
          let foundIndex = -1;
          for (i = byteOffset; i < arrLength; i++) {
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
              if (foundIndex === -1) foundIndex = i;
              if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
              if (foundIndex !== -1) i -= i - foundIndex;
              foundIndex = -1;
            }
          }
        } else {
          if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
          for (i = byteOffset; i >= 0; i--) {
            let found = true;
            for (let j = 0; j < valLength; j++) {
              if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
              }
            }
            if (found) return i;
          }
        }
        return -1;
      }
      Buffer2.prototype.includes = function includes(val, byteOffset, encoding) {
        return this.indexOf(val, byteOffset, encoding) !== -1;
      };
      Buffer2.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
      };
      Buffer2.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
        return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
      };
      function hexWrite(buf, string, offset, length) {
        offset = Number(offset) || 0;
        const remaining = buf.length - offset;
        if (!length) {
          length = remaining;
        } else {
          length = Number(length);
          if (length > remaining) {
            length = remaining;
          }
        }
        const strLen = string.length;
        if (length > strLen / 2) {
          length = strLen / 2;
        }
        let i;
        for (i = 0; i < length; ++i) {
          const parsed = parseInt(string.substr(i * 2, 2), 16);
          if (numberIsNaN(parsed)) return i;
          buf[offset + i] = parsed;
        }
        return i;
      }
      function utf8Write(buf, string, offset, length) {
        return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
      }
      function asciiWrite(buf, string, offset, length) {
        return blitBuffer(asciiToBytes(string), buf, offset, length);
      }
      function base64Write(buf, string, offset, length) {
        return blitBuffer(base64ToBytes(string), buf, offset, length);
      }
      function ucs2Write(buf, string, offset, length) {
        return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
      }
      Buffer2.prototype.write = function write(string, offset, length, encoding) {
        if (offset === void 0) {
          encoding = "utf8";
          length = this.length;
          offset = 0;
        } else if (length === void 0 && typeof offset === "string") {
          encoding = offset;
          length = this.length;
          offset = 0;
        } else if (isFinite(offset)) {
          offset = offset >>> 0;
          if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === void 0) encoding = "utf8";
          } else {
            encoding = length;
            length = void 0;
          }
        } else {
          throw new Error(
            "Buffer.write(string, encoding, offset[, length]) is no longer supported"
          );
        }
        const remaining = this.length - offset;
        if (length === void 0 || length > remaining) length = remaining;
        if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
          throw new RangeError("Attempt to write outside buffer bounds");
        }
        if (!encoding) encoding = "utf8";
        let loweredCase = false;
        for (; ; ) {
          switch (encoding) {
            case "hex":
              return hexWrite(this, string, offset, length);
            case "utf8":
            case "utf-8":
              return utf8Write(this, string, offset, length);
            case "ascii":
            case "latin1":
            case "binary":
              return asciiWrite(this, string, offset, length);
            case "base64":
              return base64Write(this, string, offset, length);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return ucs2Write(this, string, offset, length);
            default:
              if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
              encoding = ("" + encoding).toLowerCase();
              loweredCase = true;
          }
        }
      };
      Buffer2.prototype.toJSON = function toJSON() {
        return {
          type: "Buffer",
          data: Array.prototype.slice.call(this._arr || this, 0)
        };
      };
      function base64Slice(buf, start, end) {
        if (start === 0 && end === buf.length) {
          return base64.fromByteArray(buf);
        } else {
          return base64.fromByteArray(buf.slice(start, end));
        }
      }
      function utf8Slice(buf, start, end) {
        end = Math.min(buf.length, end);
        const res = [];
        let i = start;
        while (i < end) {
          const firstByte = buf[i];
          let codePoint = null;
          let bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
          if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch (bytesPerSequence) {
              case 1:
                if (firstByte < 128) {
                  codePoint = firstByte;
                }
                break;
              case 2:
                secondByte = buf[i + 1];
                if ((secondByte & 192) === 128) {
                  tempCodePoint = (firstByte & 31) << 6 | secondByte & 63;
                  if (tempCodePoint > 127) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 3:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 12 | (secondByte & 63) << 6 | thirdByte & 63;
                  if (tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343)) {
                    codePoint = tempCodePoint;
                  }
                }
                break;
              case 4:
                secondByte = buf[i + 1];
                thirdByte = buf[i + 2];
                fourthByte = buf[i + 3];
                if ((secondByte & 192) === 128 && (thirdByte & 192) === 128 && (fourthByte & 192) === 128) {
                  tempCodePoint = (firstByte & 15) << 18 | (secondByte & 63) << 12 | (thirdByte & 63) << 6 | fourthByte & 63;
                  if (tempCodePoint > 65535 && tempCodePoint < 1114112) {
                    codePoint = tempCodePoint;
                  }
                }
            }
          }
          if (codePoint === null) {
            codePoint = 65533;
            bytesPerSequence = 1;
          } else if (codePoint > 65535) {
            codePoint -= 65536;
            res.push(codePoint >>> 10 & 1023 | 55296);
            codePoint = 56320 | codePoint & 1023;
          }
          res.push(codePoint);
          i += bytesPerSequence;
        }
        return decodeCodePointsArray(res);
      }
      const MAX_ARGUMENTS_LENGTH = 4096;
      function decodeCodePointsArray(codePoints) {
        const len = codePoints.length;
        if (len <= MAX_ARGUMENTS_LENGTH) {
          return String.fromCharCode.apply(String, codePoints);
        }
        let res = "";
        let i = 0;
        while (i < len) {
          res += String.fromCharCode.apply(
            String,
            codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
          );
        }
        return res;
      }
      function asciiSlice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i] & 127);
        }
        return ret;
      }
      function latin1Slice(buf, start, end) {
        let ret = "";
        end = Math.min(buf.length, end);
        for (let i = start; i < end; ++i) {
          ret += String.fromCharCode(buf[i]);
        }
        return ret;
      }
      function hexSlice(buf, start, end) {
        const len = buf.length;
        if (!start || start < 0) start = 0;
        if (!end || end < 0 || end > len) end = len;
        let out = "";
        for (let i = start; i < end; ++i) {
          out += hexSliceLookupTable[buf[i]];
        }
        return out;
      }
      function utf16leSlice(buf, start, end) {
        const bytes = buf.slice(start, end);
        let res = "";
        for (let i = 0; i < bytes.length - 1; i += 2) {
          res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
        }
        return res;
      }
      Buffer2.prototype.slice = function slice(start, end) {
        const len = this.length;
        start = ~~start;
        end = end === void 0 ? len : ~~end;
        if (start < 0) {
          start += len;
          if (start < 0) start = 0;
        } else if (start > len) {
          start = len;
        }
        if (end < 0) {
          end += len;
          if (end < 0) end = 0;
        } else if (end > len) {
          end = len;
        }
        if (end < start) end = start;
        const newBuf = this.subarray(start, end);
        Object.setPrototypeOf(newBuf, Buffer2.prototype);
        return newBuf;
      };
      function checkOffset(offset, ext, length) {
        if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
        if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
      }
      Buffer2.prototype.readUintLE = Buffer2.prototype.readUIntLE = function readUIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        return val;
      };
      Buffer2.prototype.readUintBE = Buffer2.prototype.readUIntBE = function readUIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          checkOffset(offset, byteLength2, this.length);
        }
        let val = this[offset + --byteLength2];
        let mul = 1;
        while (byteLength2 > 0 && (mul *= 256)) {
          val += this[offset + --byteLength2] * mul;
        }
        return val;
      };
      Buffer2.prototype.readUint8 = Buffer2.prototype.readUInt8 = function readUInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        return this[offset];
      };
      Buffer2.prototype.readUint16LE = Buffer2.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] | this[offset + 1] << 8;
      };
      Buffer2.prototype.readUint16BE = Buffer2.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        return this[offset] << 8 | this[offset + 1];
      };
      Buffer2.prototype.readUint32LE = Buffer2.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 16777216;
      };
      Buffer2.prototype.readUint32BE = Buffer2.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] * 16777216 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
      };
      Buffer2.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const lo = first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
        const hi = this[++offset] + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + last * 2 ** 24;
        return BigInt(lo) + (BigInt(hi) << BigInt(32));
      });
      Buffer2.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last;
        return (BigInt(hi) << BigInt(32)) + BigInt(lo);
      });
      Buffer2.prototype.readIntLE = function readIntLE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let val = this[offset];
        let mul = 1;
        let i = 0;
        while (++i < byteLength2 && (mul *= 256)) {
          val += this[offset + i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer2.prototype.readIntBE = function readIntBE(offset, byteLength2, noAssert) {
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) checkOffset(offset, byteLength2, this.length);
        let i = byteLength2;
        let mul = 1;
        let val = this[offset + --i];
        while (i > 0 && (mul *= 256)) {
          val += this[offset + --i] * mul;
        }
        mul *= 128;
        if (val >= mul) val -= Math.pow(2, 8 * byteLength2);
        return val;
      };
      Buffer2.prototype.readInt8 = function readInt8(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 1, this.length);
        if (!(this[offset] & 128)) return this[offset];
        return (255 - this[offset] + 1) * -1;
      };
      Buffer2.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset] | this[offset + 1] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer2.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 2, this.length);
        const val = this[offset + 1] | this[offset] << 8;
        return val & 32768 ? val | 4294901760 : val;
      };
      Buffer2.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
      };
      Buffer2.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
      };
      Buffer2.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = this[offset + 4] + this[offset + 5] * 2 ** 8 + this[offset + 6] * 2 ** 16 + (last << 24);
        return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 2 ** 8 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
      });
      Buffer2.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
        offset = offset >>> 0;
        validateNumber(offset, "offset");
        const first = this[offset];
        const last = this[offset + 7];
        if (first === void 0 || last === void 0) {
          boundsError(offset, this.length - 8);
        }
        const val = (first << 24) + // Overflow
        this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + this[++offset];
        return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 8 + last);
      });
      Buffer2.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee7542.read(this, offset, true, 23, 4);
      };
      Buffer2.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 4, this.length);
        return ieee7542.read(this, offset, false, 23, 4);
      };
      Buffer2.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee7542.read(this, offset, true, 52, 8);
      };
      Buffer2.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
        offset = offset >>> 0;
        if (!noAssert) checkOffset(offset, 8, this.length);
        return ieee7542.read(this, offset, false, 52, 8);
      };
      function checkInt(buf, value, offset, ext, max, min) {
        if (!Buffer2.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
      }
      Buffer2.prototype.writeUintLE = Buffer2.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let mul = 1;
        let i = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeUintBE = Buffer2.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        byteLength2 = byteLength2 >>> 0;
        if (!noAssert) {
          const maxBytes = Math.pow(2, 8 * byteLength2) - 1;
          checkInt(this, value, offset, byteLength2, maxBytes, 0);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          this[offset + i] = value / mul & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeUint8 = Buffer2.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 255, 0);
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer2.prototype.writeUint16LE = Buffer2.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer2.prototype.writeUint16BE = Buffer2.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 65535, 0);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer2.prototype.writeUint32LE = Buffer2.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 255;
        return offset + 4;
      };
      Buffer2.prototype.writeUint32BE = Buffer2.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 4294967295, 0);
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      function wrtBigUInt64LE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        lo = lo >> 8;
        buf[offset++] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        hi = hi >> 8;
        buf[offset++] = hi;
        return offset;
      }
      function wrtBigUInt64BE(buf, value, offset, min, max) {
        checkIntBI(value, min, max, buf, offset, 7);
        let lo = Number(value & BigInt(4294967295));
        buf[offset + 7] = lo;
        lo = lo >> 8;
        buf[offset + 6] = lo;
        lo = lo >> 8;
        buf[offset + 5] = lo;
        lo = lo >> 8;
        buf[offset + 4] = lo;
        let hi = Number(value >> BigInt(32) & BigInt(4294967295));
        buf[offset + 3] = hi;
        hi = hi >> 8;
        buf[offset + 2] = hi;
        hi = hi >> 8;
        buf[offset + 1] = hi;
        hi = hi >> 8;
        buf[offset] = hi;
        return offset + 8;
      }
      Buffer2.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer2.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
      });
      Buffer2.prototype.writeIntLE = function writeIntLE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = 0;
        let mul = 1;
        let sub = 0;
        this[offset] = value & 255;
        while (++i < byteLength2 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeIntBE = function writeIntBE(value, offset, byteLength2, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          const limit = Math.pow(2, 8 * byteLength2 - 1);
          checkInt(this, value, offset, byteLength2, limit - 1, -limit);
        }
        let i = byteLength2 - 1;
        let mul = 1;
        let sub = 0;
        this[offset + i] = value & 255;
        while (--i >= 0 && (mul *= 256)) {
          if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
          }
          this[offset + i] = (value / mul >> 0) - sub & 255;
        }
        return offset + byteLength2;
      };
      Buffer2.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 1, 127, -128);
        if (value < 0) value = 255 + value + 1;
        this[offset] = value & 255;
        return offset + 1;
      };
      Buffer2.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        return offset + 2;
      };
      Buffer2.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 2, 32767, -32768);
        this[offset] = value >>> 8;
        this[offset + 1] = value & 255;
        return offset + 2;
      };
      Buffer2.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        this[offset] = value & 255;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
        return offset + 4;
      };
      Buffer2.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) checkInt(this, value, offset, 4, 2147483647, -2147483648);
        if (value < 0) value = 4294967295 + value + 1;
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 255;
        return offset + 4;
      };
      Buffer2.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
        return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      Buffer2.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
        return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      });
      function checkIEEE754(buf, value, offset, ext, max, min) {
        if (offset + ext > buf.length) throw new RangeError("Index out of range");
        if (offset < 0) throw new RangeError("Index out of range");
      }
      function writeFloat(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 4);
        }
        ieee7542.write(buf, value, offset, littleEndian, 23, 4);
        return offset + 4;
      }
      Buffer2.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
        return writeFloat(this, value, offset, true, noAssert);
      };
      Buffer2.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
        return writeFloat(this, value, offset, false, noAssert);
      };
      function writeDouble(buf, value, offset, littleEndian, noAssert) {
        value = +value;
        offset = offset >>> 0;
        if (!noAssert) {
          checkIEEE754(buf, value, offset, 8);
        }
        ieee7542.write(buf, value, offset, littleEndian, 52, 8);
        return offset + 8;
      }
      Buffer2.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
        return writeDouble(this, value, offset, true, noAssert);
      };
      Buffer2.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
        return writeDouble(this, value, offset, false, noAssert);
      };
      Buffer2.prototype.copy = function copy(target, targetStart, start, end) {
        if (!Buffer2.isBuffer(target)) throw new TypeError("argument should be a Buffer");
        if (!start) start = 0;
        if (!end && end !== 0) end = this.length;
        if (targetStart >= target.length) targetStart = target.length;
        if (!targetStart) targetStart = 0;
        if (end > 0 && end < start) end = start;
        if (end === start) return 0;
        if (target.length === 0 || this.length === 0) return 0;
        if (targetStart < 0) {
          throw new RangeError("targetStart out of bounds");
        }
        if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
        if (end < 0) throw new RangeError("sourceEnd out of bounds");
        if (end > this.length) end = this.length;
        if (target.length - targetStart < end - start) {
          end = target.length - targetStart + start;
        }
        const len = end - start;
        if (this === target && typeof Uint8Array.prototype.copyWithin === "function") {
          this.copyWithin(targetStart, start, end);
        } else {
          Uint8Array.prototype.set.call(
            target,
            this.subarray(start, end),
            targetStart
          );
        }
        return len;
      };
      Buffer2.prototype.fill = function fill(val, start, end, encoding) {
        if (typeof val === "string") {
          if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
          } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
          }
          if (encoding !== void 0 && typeof encoding !== "string") {
            throw new TypeError("encoding must be a string");
          }
          if (typeof encoding === "string" && !Buffer2.isEncoding(encoding)) {
            throw new TypeError("Unknown encoding: " + encoding);
          }
          if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") {
              val = code;
            }
          }
        } else if (typeof val === "number") {
          val = val & 255;
        } else if (typeof val === "boolean") {
          val = Number(val);
        }
        if (start < 0 || this.length < start || this.length < end) {
          throw new RangeError("Out of range index");
        }
        if (end <= start) {
          return this;
        }
        start = start >>> 0;
        end = end === void 0 ? this.length : end >>> 0;
        if (!val) val = 0;
        let i;
        if (typeof val === "number") {
          for (i = start; i < end; ++i) {
            this[i] = val;
          }
        } else {
          const bytes = Buffer2.isBuffer(val) ? val : Buffer2.from(val, encoding);
          const len = bytes.length;
          if (len === 0) {
            throw new TypeError('The value "' + val + '" is invalid for argument "value"');
          }
          for (i = 0; i < end - start; ++i) {
            this[i + start] = bytes[i % len];
          }
        }
        return this;
      };
      const errors = {};
      function E(sym, getMessage, Base) {
        errors[sym] = class NodeError extends Base {
          constructor() {
            super();
            Object.defineProperty(this, "message", {
              value: getMessage.apply(this, arguments),
              writable: true,
              configurable: true
            });
            this.name = `${this.name} [${sym}]`;
            this.stack;
            delete this.name;
          }
          get code() {
            return sym;
          }
          set code(value) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${sym}]: ${this.message}`;
          }
        };
      }
      E(
        "ERR_BUFFER_OUT_OF_BOUNDS",
        function(name) {
          if (name) {
            return `${name} is outside of buffer bounds`;
          }
          return "Attempt to access memory outside buffer bounds";
        },
        RangeError
      );
      E(
        "ERR_INVALID_ARG_TYPE",
        function(name, actual) {
          return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
        },
        TypeError
      );
      E(
        "ERR_OUT_OF_RANGE",
        function(str, range, input) {
          let msg = `The value of "${str}" is out of range.`;
          let received = input;
          if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
            received = addNumericalSeparator(String(input));
          } else if (typeof input === "bigint") {
            received = String(input);
            if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
              received = addNumericalSeparator(received);
            }
            received += "n";
          }
          msg += ` It must be ${range}. Received ${received}`;
          return msg;
        },
        RangeError
      );
      function addNumericalSeparator(val) {
        let res = "";
        let i = val.length;
        const start = val[0] === "-" ? 1 : 0;
        for (; i >= start + 4; i -= 3) {
          res = `_${val.slice(i - 3, i)}${res}`;
        }
        return `${val.slice(0, i)}${res}`;
      }
      function checkBounds(buf, offset, byteLength2) {
        validateNumber(offset, "offset");
        if (buf[offset] === void 0 || buf[offset + byteLength2] === void 0) {
          boundsError(offset, buf.length - (byteLength2 + 1));
        }
      }
      function checkIntBI(value, min, max, buf, offset, byteLength2) {
        if (value > max || value < min) {
          const n = typeof min === "bigint" ? "n" : "";
          let range;
          {
            if (min === 0 || min === BigInt(0)) {
              range = `>= 0${n} and < 2${n} ** ${(byteLength2 + 1) * 8}${n}`;
            } else {
              range = `>= -(2${n} ** ${(byteLength2 + 1) * 8 - 1}${n}) and < 2 ** ${(byteLength2 + 1) * 8 - 1}${n}`;
            }
          }
          throw new errors.ERR_OUT_OF_RANGE("value", range, value);
        }
        checkBounds(buf, offset, byteLength2);
      }
      function validateNumber(value, name) {
        if (typeof value !== "number") {
          throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
        }
      }
      function boundsError(value, length, type) {
        if (Math.floor(value) !== value) {
          validateNumber(value, type);
          throw new errors.ERR_OUT_OF_RANGE("offset", "an integer", value);
        }
        if (length < 0) {
          throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
        }
        throw new errors.ERR_OUT_OF_RANGE(
          "offset",
          `>= ${0} and <= ${length}`,
          value
        );
      }
      const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
      function base64clean(str) {
        str = str.split("=")[0];
        str = str.trim().replace(INVALID_BASE64_RE, "");
        if (str.length < 2) return "";
        while (str.length % 4 !== 0) {
          str = str + "=";
        }
        return str;
      }
      function utf8ToBytes(string, units) {
        units = units || Infinity;
        let codePoint;
        const length = string.length;
        let leadSurrogate = null;
        const bytes = [];
        for (let i = 0; i < length; ++i) {
          codePoint = string.charCodeAt(i);
          if (codePoint > 55295 && codePoint < 57344) {
            if (!leadSurrogate) {
              if (codePoint > 56319) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              } else if (i + 1 === length) {
                if ((units -= 3) > -1) bytes.push(239, 191, 189);
                continue;
              }
              leadSurrogate = codePoint;
              continue;
            }
            if (codePoint < 56320) {
              if ((units -= 3) > -1) bytes.push(239, 191, 189);
              leadSurrogate = codePoint;
              continue;
            }
            codePoint = (leadSurrogate - 55296 << 10 | codePoint - 56320) + 65536;
          } else if (leadSurrogate) {
            if ((units -= 3) > -1) bytes.push(239, 191, 189);
          }
          leadSurrogate = null;
          if (codePoint < 128) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
          } else if (codePoint < 2048) {
            if ((units -= 2) < 0) break;
            bytes.push(
              codePoint >> 6 | 192,
              codePoint & 63 | 128
            );
          } else if (codePoint < 65536) {
            if ((units -= 3) < 0) break;
            bytes.push(
              codePoint >> 12 | 224,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else if (codePoint < 1114112) {
            if ((units -= 4) < 0) break;
            bytes.push(
              codePoint >> 18 | 240,
              codePoint >> 12 & 63 | 128,
              codePoint >> 6 & 63 | 128,
              codePoint & 63 | 128
            );
          } else {
            throw new Error("Invalid code point");
          }
        }
        return bytes;
      }
      function asciiToBytes(str) {
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          byteArray.push(str.charCodeAt(i) & 255);
        }
        return byteArray;
      }
      function utf16leToBytes(str, units) {
        let c, hi, lo;
        const byteArray = [];
        for (let i = 0; i < str.length; ++i) {
          if ((units -= 2) < 0) break;
          c = str.charCodeAt(i);
          hi = c >> 8;
          lo = c % 256;
          byteArray.push(lo);
          byteArray.push(hi);
        }
        return byteArray;
      }
      function base64ToBytes(str) {
        return base64.toByteArray(base64clean(str));
      }
      function blitBuffer(src, dst, offset, length) {
        let i;
        for (i = 0; i < length; ++i) {
          if (i + offset >= dst.length || i >= src.length) break;
          dst[i + offset] = src[i];
        }
        return i;
      }
      function isInstance(obj, type) {
        return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
      }
      function numberIsNaN(obj) {
        return obj !== obj;
      }
      const hexSliceLookupTable = function() {
        const alphabet = "0123456789abcdef";
        const table = new Array(256);
        for (let i = 0; i < 16; ++i) {
          const i16 = i * 16;
          for (let j = 0; j < 16; ++j) {
            table[i16 + j] = alphabet[i] + alphabet[j];
          }
        }
        return table;
      }();
      function defineBigIntMethod(fn) {
        return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
      }
      function BufferBigIntNotDefined() {
        throw new Error("BigInt not supported");
      }
    })(buffer);
    return buffer;
  }
  var bufferExports = requireBuffer();
  const AUTHORIZED_ORIGINS_KEY = "local:authorized_origins";
  const getAuthorizedOrigins = async () => {
    const origins = await storage.getItem(AUTHORIZED_ORIGINS_KEY);
    return origins || [];
  };
  const isOriginAuthorized = async (origin) => {
    const origins = await getAuthorizedOrigins();
    return origins.includes(origin);
  };
  background;
  const devConfig = {
    Env: "dev",
    Chain: "testnet",
    Mode: "client",
    Peers: [
      "b@025fb789035bc2f0c74384503401222e53f72eefdebf0886517ff26ac7985f52ad@https://satstestnet-peer-p1.sat20.org",
      "s@0367f26af23dc40fdad06752c38264fe621b7bbafb1d41ab436b87ded192f1336e@https://satstestnet-peer-p0.sat20.org"
    ],
    IndexerL1: {
      Scheme: "https",
      Host: "apidev.sat20.org",
      Proxy: "btc/testnet"
    },
    IndexerL2: {
      Scheme: "https",
      Host: "apidev.sat20.org",
      Proxy: "satsnet/testnet"
    },
    Log: "debug"
  };
  const testConfig = {
    Env: "test",
    Chain: "testnet",
    Mode: "client",
    Peers: [
      "b@025fb789035bc2f0c74384503401222e53f72eefdebf0886517ff26ac7985f52ad@seed.sat20.org:19529",
      "s@0367f26af23dc40fdad06752c38264fe621b7bbafb1d41ab436b87ded192f1336e@39.108.96.46:19529"
    ],
    IndexerL1: {
      Scheme: "https",
      Host: "apitest.sat20.org",
      Proxy: "btc/testnet"
    },
    IndexerL2: {
      Scheme: "https",
      Host: "apitest.sat20.org",
      Proxy: "satsnet/testnet"
    },
    Log: "debug"
  };
  const prodConfig = {
    Env: "prod",
    Chain: "mainnet",
    Mode: "client",
    Peers: [
      "b@025fb789035bc2f0c74384503401222e53f72eefdebf0886517ff26ac7985f52ad@seed.sat20.org:19529",
      "s@0367f26af23dc40fdad06752c38264fe621b7bbafb1d41ab436b87ded192f1336e@39.108.96.46:19529"
    ],
    IndexerL1: {
      Scheme: "https",
      Host: "apiprd.sat20.org",
      Proxy: "btc/testnet"
    },
    IndexerL2: {
      Scheme: "https",
      Host: "apiprd.sat20.org",
      Proxy: "satsnet/testnet"
    },
    Log: "debug"
  };
  const logLevel = 5;
  const config = {
    dev: devConfig,
    test: testConfig,
    prod: prodConfig
  };
  const getConfig = (env) => {
    return config[env];
  };
  background;
  globalThis.Buffer = bufferExports.Buffer;
  function listenToKeepAliveChannel() {
    chrome.runtime.onConnect.addListener((newPort) => {
      if (newPort.name !== "KEEP_ALIVE_INTERVAL") return;
      newPort.onMessage.addListener((msg) => {
        if (msg.type !== "KEEP_ALIVE") return;
        newPort.postMessage({ type: "KEEP_ALIVE", payload: "PONG" });
      });
    });
  }
  const definition = defineBackground(() => {
    console.log("Background service worker started.");
    let isWasmReady = false;
    const messageQueue = [];
    const processQueuedMessages = async () => {
      console.log(`Processing queued messages, count: ${messageQueue.length}`);
      while (messageQueue.length > 0) {
        const { port, event } = messageQueue.shift();
        await handleMessage(port, event);
      }
    };
    const handleMessage = async (port, event) => {
      const eventData = event;
      const { action, type, data } = eventData;
      const { origin, messageId } = eventData.metadata;
      eventData.metadata.from = Message.MessageFrom.BACKGROUND;
      eventData.metadata.to = Message.MessageTo.INJECTED;
      try {
        await walletStorage.initializeState();
        const hasWallet = await service.getHasWallet();
        if (!hasWallet) {
          port.postMessage({
            ...eventData,
            data: null,
            error: walletError.noWallet
          });
          return;
        }
        const METHODS_REQUIRING_AUTHORIZATION = [
          Message.MessageAction.GET_ACCOUNTS,
          Message.MessageAction.GET_PUBLIC_KEY,
          Message.MessageAction.GET_BALANCE,
          Message.MessageAction.GET_NETWORK,
          Message.MessageAction.BUILD_BATCH_SELL_ORDER,
          Message.MessageAction.SPLIT_BATCH_SIGNED_PSBT,
          Message.MessageAction.SPLIT_BATCH_SIGNED_PSBT_SATSNET,
          Message.MessageAction.SEND_BITCOIN,
          Message.MessageAction.SIGN_MESSAGE,
          Message.MessageAction.SIGN_PSBT,
          Message.MessageAction.SIGN_PSBTS,
          Message.MessageAction.PUSH_TX,
          Message.MessageAction.PUSH_PSBT,
          Message.MessageAction.GET_INSCRIPTIONS,
          Message.MessageAction.SEND_INSCRIPTION,
          Message.MessageAction.SWITCH_NETWORK,
          Message.MessageAction.FINALIZE_SELL_ORDER,
          Message.MessageAction.ADD_INPUTS_TO_PSBT,
          Message.MessageAction.ADD_OUTPUTS_TO_PSBT,
          Message.MessageAction.EXTRACT_TX_FROM_PSBT,
          Message.MessageAction.EXTRACT_TX_FROM_PSBT_SATSNET,
          Message.MessageAction.SPLIT_ASSET,
          // --- Added Actions ---
          Message.MessageAction.LOCK_UTXO,
          Message.MessageAction.LOCK_UTXO_SATSNET,
          Message.MessageAction.UNLOCK_UTXO,
          Message.MessageAction.UNLOCK_UTXO_SATSNET,
          Message.MessageAction.GET_ALL_LOCKED_UTXO,
          Message.MessageAction.GET_ALL_LOCKED_UTXO_SATSNET,
          Message.MessageAction.LOCK_TO_CHANNEL,
          Message.MessageAction.UNLOCK_FROM_CHANNEL,
          // --- Added UTXO Getter Actions ---
          Message.MessageAction.GET_UTXOS,
          Message.MessageAction.GET_UTXOS_SATSNET,
          Message.MessageAction.GET_UTXOS_WITH_ASSET,
          Message.MessageAction.GET_UTXOS_WITH_ASSET_SATSNET,
          Message.MessageAction.GET_UTXOS_WITH_ASSET_V2,
          Message.MessageAction.GET_UTXOS_WITH_ASSET_V2_SATSNET,
          Message.MessageAction.GET_ASSET_AMOUNT,
          Message.MessageAction.GET_ASSET_AMOUNT_SATSNET,
          Message.MessageAction.MERGE_BATCH_SIGNED_PSBT
        ];
        if (METHODS_REQUIRING_AUTHORIZATION.includes(action)) {
          const authorized = await isOriginAuthorized(origin);
          if (!authorized) {
            port.postMessage({
              // Use port directly
              ...eventData,
              data: null,
              error: {
                code: -32603,
                message: "未授权的来源，请先调用 REQUEST_ACCOUNTS 方法"
              }
            });
            return;
          }
        }
        let resData = null;
        let errData = null;
        if (type === Message.MessageType.REQUEST) {
          let reqErr, reqRes;
          switch (action) {
            case Message.MessageAction.BUILD_BATCH_SELL_ORDER:
              resData = await service.buildBatchSellOrder_SatsNet(
                data.utxos,
                data.address,
                data.network
              );
              break;
            case Message.MessageAction.SPLIT_BATCH_SIGNED_PSBT:
              resData = await service.splitBatchSignedPsbt(
                data.signedHex,
                data.network
              );
              break;
            case Message.MessageAction.SPLIT_BATCH_SIGNED_PSBT_SATSNET:
              resData = await service.splitBatchSignedPsbt_SatsNet(
                data.signedHex,
                data.network
              );
              break;
            case Message.MessageAction.EXTRACT_TX_FROM_PSBT:
              const [extractErr, extractRes] = await service.extractTxFromPsbt(
                data.psbtHex,
                data.chain
              );
              if (extractErr || !extractRes) {
                errData = {
                  code: -22,
                  message: (extractErr == null ? void 0 : extractErr.message) || "提取交易失败"
                };
              } else {
                resData = extractRes.tx;
              }
              break;
            case Message.MessageAction.GET_ACCOUNTS:
              resData = await service.getAccounts();
              break;
            case Message.MessageAction.GET_PUBLIC_KEY:
              resData = await service.getPublicKey();
              break;
            case Message.MessageAction.GET_NETWORK:
              resData = await service.getNetwork();
              break;
            case Message.MessageAction.GET_BALANCE:
              resData = await service.getBalance();
              break;
            case Message.MessageAction.PUSH_TX:
              resData = await service.pushTx(data.rawtx);
              break;
            case Message.MessageAction.PUSH_PSBT:
              const [err, res] = await service.pushPsbt(data.psbtHex);
              if (err) {
                errData = {
                  code: -22,
                  message: err.message
                };
              } else {
                resData = res;
              }
              break;
            case Message.MessageAction.FINALIZE_SELL_ORDER:
              const [finalizeErr, finalizeRes] = await service.finalizeSellOrder_SatsNet(
                data.psbtHex,
                data.utxos,
                data.buyerAddress,
                data.serverAddress,
                data.network,
                data.serviceFee,
                data.networkFee
              );
              if (finalizeErr) {
                errData = {
                  code: -22,
                  message: finalizeErr.message
                };
              } else {
                resData = finalizeRes;
              }
              break;
            case Message.MessageAction.MERGE_BATCH_SIGNED_PSBT:
              resData = await service.mergeBatchSignedPsbt_SatsNet(
                data.psbts,
                data.network
              );
              break;
            case Message.MessageAction.ADD_INPUTS_TO_PSBT:
              const [inputsErr, inputsRes] = await service.addInputsToPsbt(
                data.psbtHex,
                data.utxos
              );
              if (inputsErr) {
                errData = {
                  code: -22,
                  message: inputsErr.message
                };
              } else {
                resData = inputsRes;
              }
              break;
            case Message.MessageAction.ADD_OUTPUTS_TO_PSBT:
              const [outputsErr, outputsRes] = await service.addOutputsToPsbt(
                data.psbtHex,
                data.utxos
              );
              if (outputsErr) {
                errData = {
                  code: -22,
                  message: outputsErr.message
                };
              } else {
                resData = outputsRes;
              }
              break;
            // --- Added Cases for REQUEST ---
            case Message.MessageAction.GET_ALL_LOCKED_UTXO:
              [reqErr, reqRes] = await service.getAllLockedUtxo(data.address);
              if (reqErr) {
                errData = { code: -30, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_ALL_LOCKED_UTXO_SATSNET:
              [reqErr, reqRes] = await service.getAllLockedUtxo_SatsNet(data.address);
              if (reqErr) {
                errData = { code: -31, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            // --- End Added Cases ---
            // --- Added Cases for UTXO Getters ---
            case Message.MessageAction.GET_UTXOS:
              [reqErr, reqRes] = await service.getUtxos();
              if (reqErr) {
                errData = { code: -40, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_UTXOS_SATSNET:
              [reqErr, reqRes] = await service.getUtxos_SatsNet();
              if (reqErr) {
                errData = { code: -41, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_UTXOS_WITH_ASSET:
              [reqErr, reqRes] = await service.getUtxosWithAsset(data.address, data.amt, data.assetName);
              if (reqErr) {
                errData = { code: -42, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_UTXOS_WITH_ASSET_SATSNET:
              [reqErr, reqRes] = await service.getUtxosWithAsset_SatsNet(data.address, data.amt, data.assetName);
              if (reqErr) {
                errData = { code: -43, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_UTXOS_WITH_ASSET_V2:
              [reqErr, reqRes] = await service.getUtxosWithAssetV2(data.address, data.amt, data.assetName);
              if (reqErr) {
                errData = { code: -44, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_UTXOS_WITH_ASSET_V2_SATSNET:
              [reqErr, reqRes] = await service.getUtxosWithAssetV2_SatsNet(data.address, data.amt, data.assetName);
              if (reqErr) {
                errData = { code: -45, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_ASSET_AMOUNT:
              [reqErr, reqRes] = await service.getAssetAmount(data.address, data.assetName);
              if (reqErr) {
                errData = { code: -46, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.GET_ASSET_AMOUNT_SATSNET:
              [reqErr, reqRes] = await service.getAssetAmount_SatsNet(data.address, data.assetName);
              if (reqErr) {
                errData = { code: -47, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            case Message.MessageAction.LOCK_UTXO_SATSNET:
              [reqErr, reqRes] = await service.lockUtxo_SatsNet(data.address, data.utxo, data.reason);
              if (reqErr) {
                errData = { code: -48, message: reqErr.message };
              } else {
                resData = { success: true };
              }
              break;
            case Message.MessageAction.GET_TICKER_INFO:
              [reqErr, reqRes] = await service.getTickerInfo(data.asset);
              if (reqErr) {
                errData = { code: -50, message: reqErr.message };
              } else {
                resData = reqRes;
              }
              break;
            default:
              console.warn(`Unhandled REQUEST action: ${action}`);
              errData = { code: -32601, message: "Method not found" };
              break;
          }
          const responseData = {
            ...eventData,
            data: resData
          };
          if (errData) {
            responseData.error = errData;
          }
          port.postMessage(responseData);
        } else if (type === Message.MessageType.APPROVE) {
          const REQUIRES_APPROVAL = [
            Message.MessageAction.REQUEST_ACCOUNTS,
            // Example existing
            Message.MessageAction.SWITCH_NETWORK,
            Message.MessageAction.SEND_BITCOIN,
            Message.MessageAction.SIGN_MESSAGE,
            Message.MessageAction.SIGN_PSBT,
            Message.MessageAction.SIGN_PSBTS,
            Message.MessageAction.SEND_INSCRIPTION,
            Message.MessageAction.SPLIT_ASSET,
            // --- Added Actions Requiring Approval ---
            Message.MessageAction.LOCK_UTXO,
            Message.MessageAction.UNLOCK_UTXO,
            Message.MessageAction.UNLOCK_UTXO_SATSNET,
            // --- Added Channel Actions ---
            Message.MessageAction.LOCK_TO_CHANNEL,
            Message.MessageAction.UNLOCK_FROM_CHANNEL,
            Message.MessageAction.BATCH_SEND_ASSETS_SATSNET
          ];
          if (REQUIRES_APPROVAL.includes(action)) {
            const windowsToRemove = [];
            for (const [windowIdStr, data2] of approveMap.entries()) {
              if (data2.eventData.metadata.origin === origin) {
                windowsToRemove.push(data2.windowId);
              }
            }
            for (const winId of windowsToRemove) {
              try {
                await browser.windows.remove(winId);
                approveMap.delete(winId.toString());
                console.log(`Closed previous approval window ${winId} for origin ${origin}.`);
              } catch (error) {
                console.warn(`Failed to remove previous window ${winId}, maybe already closed:`, error);
                approveMap.delete(winId.toString());
              }
            }
            const newWindow = await createPopup(
              browser.runtime.getURL(`/popup.html#/wallet/approve`)
            );
            if (newWindow == null ? void 0 : newWindow.id) {
              createdWindowId = newWindow.id;
              approveMap.set(createdWindowId.toString(), {
                // Use string key for map
                windowId: createdWindowId,
                // Store numeric ID in value
                eventData: event
                // Store original event data
              });
              console.log(`Approval window ${createdWindowId} created for action ${action} and request stored.`);
            } else {
              console.error("Failed to create approval window.");
              port.postMessage({
                // Use port directly
                ...eventData,
                error: {
                  code: -1,
                  message: "Failed to create approval popup"
                },
                data: null
              });
            }
          } else {
            console.warn(`Received APPROVE message for action ${action} which doesn't require approval.`);
            port.postMessage({
              // Use port directly
              ...eventData,
              error: { code: -32600, message: "Invalid Request: Action does not require approval." },
              data: null
            });
          }
        }
      } catch (error) {
        console.error("Error handling message:", error);
        port.postMessage({
          // Use port directly
          ...eventData,
          data: null,
          error: {
            code: -32603,
            // Internal error code
            message: (error == null ? void 0 : error.message) || "处理消息时发生内部错误"
            // Include error message if available
          }
        });
      }
    };
    const loadStpWasm = async () => {
      const go = new Go();
      const wasmPath = browser.runtime.getURL("/wasm/stpd.wasm");
      const env = walletStorage.getValue("env") || "test";
      const response = await fetch(wasmPath);
      const wasmBinary = await response.arrayBuffer();
      const wasmModule = await WebAssembly.instantiate(
        wasmBinary,
        go.importObject
      );
      go.run(wasmModule.instance);
      await globalThis.stp_wasm.init(
        getConfig(env),
        logLevel
      );
    };
    const loadWalletWasm = async () => {
      try {
        importScripts("/wasm/wasm_exec.js");
        const go = new Go();
        const env = walletStorage.getValue("env") || "test";
        const wasmPath = browser.runtime.getURL("/wasm/sat20wallet.wasm");
        const response = await fetch(wasmPath);
        const wasmBinary = await response.arrayBuffer();
        const wasmModule = await WebAssembly.instantiate(
          wasmBinary,
          go.importObject
        );
        go.run(wasmModule.instance);
        await globalThis.sat20wallet_wasm.init(
          getConfig(env),
          logLevel
        );
        await loadStpWasm();
        isWasmReady = true;
        console.log("WASM loaded successfully, processing queued messages");
        await processQueuedMessages();
      } catch (error) {
        console.error("Failed to load WASM:", error);
        throw error;
      }
    };
    const approveMap = /* @__PURE__ */ new Map();
    listenToKeepAliveChannel();
    let createdWindowId = null;
    const portMap = {};
    const popupListener = async (message) => {
      const eventData = message;
      const { action, data, metadata = {} } = eventData;
      const { windowId, from, messageId } = metadata;
      if (from === Message.MessageFrom.POPUP) {
        if (action === Message.MessageAction.APPROVE_RESPONSE) {
          eventData.metadata.from = Message.MessageFrom.BACKGROUND;
          eventData.metadata.to = Message.MessageTo.INJECTED;
          if (portMap.content) {
            await portMap.content.postMessage(eventData);
          } else {
            console.error(
              "Content script port not available for APPROVE_RESPONSE"
            );
          }
          if (windowId) {
            approveMap.delete(windowId.toString());
            try {
              await browser.windows.remove(windowId);
            } catch (e) {
              console.warn(`Window ${windowId} might already be closed:`, e);
            }
          }
        } else if (action === Message.MessageAction.REJECT_RESPONSE) {
          eventData.metadata.from = Message.MessageFrom.BACKGROUND;
          eventData.metadata.to = Message.MessageTo.INJECTED;
          if (portMap.content) {
            portMap.content.postMessage({
              ...eventData,
              data: null,
              error: walletError.userReject
            });
          } else {
            console.error(
              "Content script port not available for REJECT_RESPONSE"
            );
          }
          if (windowId) {
            approveMap.delete(windowId.toString());
            try {
              await browser.windows.remove(windowId);
            } catch (e) {
              console.warn(`Window ${windowId} might already be closed:`, e);
            }
          }
        }
      }
    };
    browser.runtime.onMessage.addListener(
      async (message, sender, sendResponse) => {
        const { type, action, metadata } = message;
        if (type === Message.MessageType.REQUEST && action === Message.MessageAction.GET_APPROVE_DATA && (metadata == null ? void 0 : metadata.windowId)) {
          const { windowId } = metadata;
          const approveData = approveMap.get(windowId.toString());
          if (approveData) {
            sendResponse({
              action: Message.MessageAction.GET_APPROVE_DATA_RESPONSE,
              data: approveData.eventData
            });
          } else {
            console.warn(`GET_APPROVE_DATA requested for unknown windowId: ${windowId}`);
            sendResponse(void 0);
          }
          return true;
        } else if (type === Message.MessageType.REQUEST && action === Message.MessageAction.ENV_CHANGED) {
          console.log("ENV_CHANGED", message);
          await globalThis.stp_wasm.release();
          await globalThis.stp_wasm.init(getConfig(message.data.env), logLevel);
          await globalThis.sat20wallet_wasm.release();
          await globalThis.sat20wallet_wasm.init(getConfig(message.data.env), logLevel);
        }
        return void 0;
      }
    );
    browser.runtime.onConnect.addListener(async (port) => {
      var _a2, _b2, _c2, _d2, _e;
      console.log("onConnect", port);
      if (port.name === Message.Port.BG_POPUP) {
        portMap.popup = port;
        console.log("Popup connected:", port);
        const windowIdMatch = (_b2 = (_a2 = port.sender) == null ? void 0 : _a2.tab) == null ? void 0 : _b2.windowId;
        if (windowIdMatch) {
          const windowIdStr = windowIdMatch.toString();
          if (approveMap.has(windowIdStr)) {
            const approveData = approveMap.get(windowIdStr);
            if (portMap.content) {
              port == null ? void 0 : port.onDisconnect.addListener(() => {
                console.log(
                  `Popup port for window ${windowIdMatch} disconnected.`
                );
                if (approveMap.has(windowIdStr)) {
                  console.log(
                    `Rejecting request via onDisconnect for window ${windowIdMatch}.`
                  );
                  portMap.content.postMessage({
                    // Use non-null assertion as we checked portMap.content
                    ...approveData.eventData,
                    metadata: {
                      ...approveData.eventData.metadata,
                      from: Message.MessageFrom.BACKGROUND,
                      to: Message.MessageTo.INJECTED
                    },
                    data: null,
                    error: walletError.userReject
                    // User closing the window is treated as rejection.
                  });
                  approveMap.delete(windowIdStr);
                } else {
                  console.log(`Request for window ${windowIdMatch} already handled (likely by onRemoved).`);
                }
              });
            } else {
              console.warn(`Popup for window ${windowIdMatch} connected, but no content script port available.`);
            }
          } else {
            console.warn(`Popup connected for window ${windowIdMatch}, but no pending request found in approveMap.`);
          }
        } else {
          console.warn(
            "Could not determine windowId for the connecting popup port."
          );
        }
        (_c2 = portMap.popup) == null ? void 0 : _c2.onMessage.addListener(popupListener);
      } else if (port.name === Message.Port.CONTENT_BG) {
        portMap.content = port;
        (_d2 = portMap.content) == null ? void 0 : _d2.onDisconnect.addListener(() => {
          console.log("Content script port disconnected.");
          portMap.content = void 0;
        });
        (_e = portMap.content) == null ? void 0 : _e.onMessage.addListener(async (event) => {
          console.log("content port onMessage", event);
          if (!isWasmReady) {
            console.log("WASM not ready, queuing message");
            messageQueue.push({ port, event });
            return;
          }
          await handleMessage(port, event);
        });
      } else if (port.name === "KEEP_ALIVE_INTERVAL") {
        console.log("Keep alive interval port connected.");
        port.postMessage({ type: "KEEP_ALIVE", payload: "PONG" });
      }
    });
    browser.windows.onRemoved.addListener((closedWindowId) => {
      console.log(`Window ${closedWindowId} was removed.`);
      const windowIdStr = closedWindowId.toString();
      if (approveMap.has(windowIdStr)) {
        const approveData = approveMap.get(windowIdStr);
        if (portMap.content) {
          console.log(
            `Rejecting request via onRemoved for window ${closedWindowId}.`
          );
          portMap.content.postMessage({
            ...approveData.eventData,
            // Include original request details
            metadata: {
              ...approveData.eventData.metadata,
              from: Message.MessageFrom.BACKGROUND,
              to: Message.MessageTo.INJECTED
            },
            data: null,
            // No data on rejection
            error: walletError.userReject
            // User closing the window is treated as rejection.
          });
          approveMap.delete(windowIdStr);
        } else {
          console.warn(`Window ${closedWindowId} removed, but no content script port to send rejection.`);
          approveMap.delete(windowIdStr);
        }
      } else {
        console.log(`Window ${closedWindowId} removed, but no corresponding request found (might be already handled or unrelated).`);
      }
    });
    loadWalletWasm().catch((error) => {
      console.error("Failed to initialize WASM:", error);
    });
    console.log("Background service worker ready.");
  });
  background;
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  let ws;
  function getDevServerWebSocket() {
    if (ws == null) {
      const serverUrl = `${"ws:"}//${"localhost"}:${3e3}`;
      logger.debug("Connecting to dev server @", serverUrl);
      ws = new WebSocket(serverUrl, "vite-hmr");
      ws.addWxtEventListener = ws.addEventListener.bind(ws);
      ws.sendCustom = (event, payload) => ws == null ? void 0 : ws.send(JSON.stringify({ type: "custom", event, payload }));
      ws.addEventListener("open", () => {
        logger.debug("Connected to dev server");
      });
      ws.addEventListener("close", () => {
        logger.debug("Disconnected from dev server");
      });
      ws.addEventListener("error", (event) => {
        logger.error("Failed to connect to dev server", event);
      });
      ws.addEventListener("message", (e) => {
        try {
          const message = JSON.parse(e.data);
          if (message.type === "custom") {
            ws == null ? void 0 : ws.dispatchEvent(
              new CustomEvent(message.event, { detail: message.data })
            );
          }
        } catch (err) {
          logger.error("Failed to handle message", err);
        }
      });
    }
    return ws;
  }
  function keepServiceWorkerAlive() {
    setInterval(async () => {
      await browser.runtime.getPlatformInfo();
    }, 5e3);
  }
  function reloadContentScript(payload) {
    const manifest = browser.runtime.getManifest();
    if (manifest.manifest_version == 2) {
      void reloadContentScriptMv2();
    } else {
      void reloadContentScriptMv3(payload);
    }
  }
  async function reloadContentScriptMv3({
    registration,
    contentScript
  }) {
    if (registration === "runtime") {
      await reloadRuntimeContentScriptMv3(contentScript);
    } else {
      await reloadManifestContentScriptMv3(contentScript);
    }
  }
  async function reloadManifestContentScriptMv3(contentScript) {
    const id = `wxt:${contentScript.js[0]}`;
    logger.log("Reloading content script:", contentScript);
    const registered = await browser.scripting.getRegisteredContentScripts();
    logger.debug("Existing scripts:", registered);
    const existing = registered.find((cs) => cs.id === id);
    if (existing) {
      logger.debug("Updating content script", existing);
      await browser.scripting.updateContentScripts([{ ...contentScript, id }]);
    } else {
      logger.debug("Registering new content script...");
      await browser.scripting.registerContentScripts([{ ...contentScript, id }]);
    }
    await reloadTabsForContentScript(contentScript);
  }
  async function reloadRuntimeContentScriptMv3(contentScript) {
    logger.log("Reloading content script:", contentScript);
    const registered = await browser.scripting.getRegisteredContentScripts();
    logger.debug("Existing scripts:", registered);
    const matches = registered.filter((cs) => {
      var _a2, _b2;
      const hasJs = (_a2 = contentScript.js) == null ? void 0 : _a2.find((js) => {
        var _a3;
        return (_a3 = cs.js) == null ? void 0 : _a3.includes(js);
      });
      const hasCss = (_b2 = contentScript.css) == null ? void 0 : _b2.find((css) => {
        var _a3;
        return (_a3 = cs.css) == null ? void 0 : _a3.includes(css);
      });
      return hasJs || hasCss;
    });
    if (matches.length === 0) {
      logger.log(
        "Content script is not registered yet, nothing to reload",
        contentScript
      );
      return;
    }
    await browser.scripting.updateContentScripts(matches);
    await reloadTabsForContentScript(contentScript);
  }
  async function reloadTabsForContentScript(contentScript) {
    const allTabs = await browser.tabs.query({});
    const matchPatterns = contentScript.matches.map(
      (match) => new MatchPattern(match)
    );
    const matchingTabs = allTabs.filter((tab) => {
      const url = tab.url;
      if (!url) return false;
      return !!matchPatterns.find((pattern) => pattern.includes(url));
    });
    await Promise.all(
      matchingTabs.map(async (tab) => {
        try {
          await browser.tabs.reload(tab.id);
        } catch (err) {
          logger.warn("Failed to reload tab:", err);
        }
      })
    );
  }
  async function reloadContentScriptMv2(_payload) {
    throw Error("TODO: reloadContentScriptMv2");
  }
  {
    try {
      const ws2 = getDevServerWebSocket();
      ws2.addWxtEventListener("wxt:reload-extension", () => {
        browser.runtime.reload();
      });
      ws2.addWxtEventListener("wxt:reload-content-script", (event) => {
        reloadContentScript(event.detail);
      });
      if (true) {
        ws2.addEventListener(
          "open",
          () => ws2.sendCustom("wxt:background-initialized")
        );
        keepServiceWorkerAlive();
      }
    } catch (err) {
      logger.error("Failed to setup web socket connection with dev server", err);
    }
    browser.commands.onCommand.addListener((command) => {
      if (command === "wxt:reload-extension") {
        browser.runtime.reload();
      }
    });
  }
  let result;
  try {
    initPlugins();
    result = definition.main();
    if (result instanceof Promise) {
      console.warn(
        "The background's main() function return a promise, but it must be synchronous"
      );
    }
  } catch (err) {
    logger.error("The background crashed on startup!");
    throw err;
  }
  const result$1 = result;
  return result$1;
}();
background;
