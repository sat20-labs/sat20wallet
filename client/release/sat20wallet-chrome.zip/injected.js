var injected = function() {
  "use strict";var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  function defineUnlistedScript(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  /**
  * @vue/shared v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  const EMPTY_OBJ = Object.freeze({});
  const extend = Object.assign;
  const isArray = Array.isArray;
  const isFunction = (val) => typeof val === "function";
  const isString = (val) => typeof val === "string";
  const isSymbol = (val) => typeof val === "symbol";
  const isObject = (val) => val !== null && typeof val === "object";
  let _globalThis;
  const getGlobalThis = () => {
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  };
  /**
  * @vue/reactivity v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
  );
  function isReactive(value) {
    if (isReadonly(value)) {
      return isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
  }
  function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
  }
  function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
  }
  function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? toRaw(raw) : observed;
  }
  function isRef(r) {
    return r ? r["__v_isRef"] === true : false;
  }
  /**
  * @vue/runtime-core v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  const stack = [];
  function pushWarningContext(vnode) {
    stack.push(vnode);
  }
  function popWarningContext() {
    stack.pop();
  }
  let isWarning = false;
  function warn$1(msg, ...args) {
    if (isWarning) return;
    isWarning = true;
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
      callWithErrorHandling(
        appWarnHandler,
        instance,
        11,
        [
          // eslint-disable-next-line no-restricted-syntax
          msg + args.map((a) => {
            var _a, _b;
            return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
          }).join(""),
          instance && instance.proxy,
          trace.map(
            ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
          ).join("\n"),
          trace
        ]
      );
    } else {
      const warnArgs = [`[Vue warn]: ${msg}`, ...args];
      if (trace.length && // avoid spamming console during tests
      true) {
        warnArgs.push(`
`, ...formatTrace(trace));
      }
      console.warn(...warnArgs);
    }
    isWarning = false;
  }
  function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
      return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
      const last = normalizedStack[0];
      if (last && last.vnode === currentVNode) {
        last.recurseCount++;
      } else {
        normalizedStack.push({
          vnode: currentVNode,
          recurseCount: 0
        });
      }
      const parentInstance = currentVNode.component && currentVNode.component.parent;
      currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
  }
  function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
      logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
    });
    return logs;
  }
  function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
      vnode.component,
      vnode.type,
      isRoot
    )}`;
    const close = `>` + postfix;
    return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
  }
  function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
      res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
      res.push(` ...`);
    }
    return res;
  }
  function formatProp(key, value, raw) {
    if (isString(value)) {
      value = JSON.stringify(value);
      return raw ? value : [`${key}=${value}`];
    } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
      return raw ? value : [`${key}=${value}`];
    } else if (isRef(value)) {
      value = formatProp(key, toRaw(value.value), true);
      return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction(value)) {
      return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
      value = toRaw(value);
      return raw ? value : [`${key}=`, value];
    }
  }
  const ErrorTypeStrings$1 = {
    ["sp"]: "serverPrefetch hook",
    ["bc"]: "beforeCreate hook",
    ["c"]: "created hook",
    ["bm"]: "beforeMount hook",
    ["m"]: "mounted hook",
    ["bu"]: "beforeUpdate hook",
    ["u"]: "updated",
    ["bum"]: "beforeUnmount hook",
    ["um"]: "unmounted hook",
    ["a"]: "activated hook",
    ["da"]: "deactivated hook",
    ["ec"]: "errorCaptured hook",
    ["rtc"]: "renderTracked hook",
    ["rtg"]: "renderTriggered hook",
    [0]: "setup function",
    [1]: "render function",
    [2]: "watcher getter",
    [3]: "watcher callback",
    [4]: "watcher cleanup function",
    [5]: "native event handler",
    [6]: "component event handler",
    [7]: "vnode hook",
    [8]: "directive hook",
    [9]: "transition hook",
    [10]: "app errorHandler",
    [11]: "app warnHandler",
    [12]: "ref function",
    [13]: "async component loader",
    [14]: "scheduler flush",
    [15]: "component update",
    [16]: "app unmount cleanup function"
  };
  function callWithErrorHandling(fn, instance, type, args) {
    try {
      return args ? fn(...args) : fn();
    } catch (err) {
      handleError(err, instance, type);
    }
  }
  function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
    if (instance) {
      let cur = instance.parent;
      const exposedInstance = instance.proxy;
      const errorInfo = ErrorTypeStrings$1[type];
      while (cur) {
        const errorCapturedHooks = cur.ec;
        if (errorCapturedHooks) {
          for (let i = 0; i < errorCapturedHooks.length; i++) {
            if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
              return;
            }
          }
        }
        cur = cur.parent;
      }
      if (errorHandler) {
        callWithErrorHandling(errorHandler, null, 10, [
          err,
          exposedInstance,
          errorInfo
        ]);
        return;
      }
    }
    logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
  }
  function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
    {
      const info = ErrorTypeStrings$1[type];
      if (contextVNode) {
        pushWarningContext(contextVNode);
      }
      warn$1(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
      if (contextVNode) {
        popWarningContext();
      }
      if (throwInDev) {
        throw err;
      } else {
        console.error(err);
      }
    }
  }
  const queue = [];
  let flushIndex = -1;
  const pendingPostFlushCbs = [];
  let activePostFlushCbs = null;
  let postFlushIndex = 0;
  const resolvedPromise = /* @__PURE__ */ Promise.resolve();
  let currentFlushPromise = null;
  const RECURSION_LIMIT = 100;
  function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
      const middle = start + end >>> 1;
      const middleJob = queue[middle];
      const middleJobId = getId(middleJob);
      if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
        start = middle + 1;
      } else {
        end = middle;
      }
    }
    return start;
  }
  function queueJob(job) {
    if (!(job.flags & 1)) {
      const jobId = getId(job);
      const lastJob = queue[queue.length - 1];
      if (!lastJob || // fast path when the job id is larger than the tail
      !(job.flags & 2) && jobId >= getId(lastJob)) {
        queue.push(job);
      } else {
        queue.splice(findInsertionIndex(jobId), 0, job);
      }
      job.flags |= 1;
      queueFlush();
    }
  }
  function queueFlush() {
    if (!currentFlushPromise) {
      currentFlushPromise = resolvedPromise.then(flushJobs);
    }
  }
  function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
      if (activePostFlushCbs && cb.id === -1) {
        activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
      } else if (!(cb.flags & 1)) {
        pendingPostFlushCbs.push(cb);
        cb.flags |= 1;
      }
    } else {
      pendingPostFlushCbs.push(...cb);
    }
    queueFlush();
  }
  function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
      const deduped = [...new Set(pendingPostFlushCbs)].sort(
        (a, b) => getId(a) - getId(b)
      );
      pendingPostFlushCbs.length = 0;
      if (activePostFlushCbs) {
        activePostFlushCbs.push(...deduped);
        return;
      }
      activePostFlushCbs = deduped;
      {
        seen = seen || /* @__PURE__ */ new Map();
      }
      for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
        const cb = activePostFlushCbs[postFlushIndex];
        if (checkRecursiveUpdates(seen, cb)) {
          continue;
        }
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        if (!(cb.flags & 8)) cb();
        cb.flags &= -2;
      }
      activePostFlushCbs = null;
      postFlushIndex = 0;
    }
  }
  const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
  function flushJobs(seen) {
    {
      seen = seen || /* @__PURE__ */ new Map();
    }
    const check = (job) => checkRecursiveUpdates(seen, job);
    try {
      for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job && !(job.flags & 8)) {
          if (check(job)) {
            continue;
          }
          if (job.flags & 4) {
            job.flags &= ~1;
          }
          callWithErrorHandling(
            job,
            job.i,
            job.i ? 15 : 14
          );
          if (!(job.flags & 4)) {
            job.flags &= ~1;
          }
        }
      }
    } finally {
      for (; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job) {
          job.flags &= -2;
        }
      }
      flushIndex = -1;
      queue.length = 0;
      flushPostFlushCbs(seen);
      currentFlushPromise = null;
      if (queue.length || pendingPostFlushCbs.length) {
        flushJobs(seen);
      }
    }
  }
  function checkRecursiveUpdates(seen, fn) {
    const count = seen.get(fn) || 0;
    if (count > RECURSION_LIMIT) {
      const instance = fn.i;
      const componentName = instance && getComponentName(instance.type);
      handleError(
        `Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`,
        null,
        10
      );
      return true;
    }
    seen.set(fn, count + 1);
    return false;
  }
  const hmrDirtyComponents = /* @__PURE__ */ new Map();
  {
    getGlobalThis().__VUE_HMR_RUNTIME__ = {
      createRecord: tryWrap(createRecord),
      rerender: tryWrap(rerender),
      reload: tryWrap(reload)
    };
  }
  const map = /* @__PURE__ */ new Map();
  function createRecord(id, initialDef) {
    if (map.has(id)) {
      return false;
    }
    map.set(id, {
      initialDef: normalizeClassComponent(initialDef),
      instances: /* @__PURE__ */ new Set()
    });
    return true;
  }
  function normalizeClassComponent(component) {
    return isClassComponent(component) ? component.__vccOpts : component;
  }
  function rerender(id, newRender) {
    const record = map.get(id);
    if (!record) {
      return;
    }
    record.initialDef.render = newRender;
    [...record.instances].forEach((instance) => {
      if (newRender) {
        instance.render = newRender;
        normalizeClassComponent(instance.type).render = newRender;
      }
      instance.renderCache = [];
      instance.update();
    });
  }
  function reload(id, newComp) {
    const record = map.get(id);
    if (!record) return;
    newComp = normalizeClassComponent(newComp);
    updateComponentDef(record.initialDef, newComp);
    const instances = [...record.instances];
    for (let i = 0; i < instances.length; i++) {
      const instance = instances[i];
      const oldComp = normalizeClassComponent(instance.type);
      let dirtyInstances = hmrDirtyComponents.get(oldComp);
      if (!dirtyInstances) {
        if (oldComp !== record.initialDef) {
          updateComponentDef(oldComp, newComp);
        }
        hmrDirtyComponents.set(oldComp, dirtyInstances = /* @__PURE__ */ new Set());
      }
      dirtyInstances.add(instance);
      instance.appContext.propsCache.delete(instance.type);
      instance.appContext.emitsCache.delete(instance.type);
      instance.appContext.optionsCache.delete(instance.type);
      if (instance.ceReload) {
        dirtyInstances.add(instance);
        instance.ceReload(newComp.styles);
        dirtyInstances.delete(instance);
      } else if (instance.parent) {
        queueJob(() => {
          instance.parent.update();
          dirtyInstances.delete(instance);
        });
      } else if (instance.appContext.reload) {
        instance.appContext.reload();
      } else if (typeof window !== "undefined") {
        window.location.reload();
      } else {
        console.warn(
          "[HMR] Root or manually mounted instance modified. Full reload required."
        );
      }
      if (instance.root.ce && instance !== instance.root) {
        instance.root.ce._removeChildStyle(oldComp);
      }
    }
    queuePostFlushCb(() => {
      hmrDirtyComponents.clear();
    });
  }
  function updateComponentDef(oldComp, newComp) {
    extend(oldComp, newComp);
    for (const key in oldComp) {
      if (key !== "__file" && !(key in newComp)) {
        delete oldComp[key];
      }
    }
  }
  function tryWrap(fn) {
    return (id, arg) => {
      try {
        return fn(id, arg);
      } catch (e) {
        console.error(e);
        console.warn(
          `[HMR] Something went wrong during Vue component hot-reload. Full reload required.`
        );
      }
    };
  }
  getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
  getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
  const PublicInstanceProxyHandlers = {};
  {
    PublicInstanceProxyHandlers.ownKeys = (target) => {
      warn$1(
        `Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`
      );
      return Reflect.ownKeys(target);
    };
  }
  {
    const g = getGlobalThis();
    const registerGlobalSetter = (key, setter) => {
      let setters;
      if (!(setters = g[key])) setters = g[key] = [];
      setters.push(setter);
      return (v) => {
        if (setters.length > 1) setters.forEach((set) => set(v));
        else setters[0](v);
      };
    };
    registerGlobalSetter(
      `__VUE_INSTANCE_SETTERS__`,
      (v) => v
    );
    registerGlobalSetter(
      `__VUE_SSR_SETTERS__`,
      (v) => v
    );
  }
  const classifyRE = /(?:^|[-_])(\w)/g;
  const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
  function getComponentName(Component, includeInferred = true) {
    return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
  }
  function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
      const match = Component.__file.match(/([^/\\]+)\.\w+$/);
      if (match) {
        name = match[1];
      }
    }
    if (!name && instance && instance.parent) {
      const inferFromRegistry = (registry) => {
        for (const key in registry) {
          if (registry[key] === Component) {
            return key;
          }
        }
      };
      name = inferFromRegistry(
        instance.components || instance.parent.type.components
      ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
  }
  function isClassComponent(value) {
    return isFunction(value) && "__vccOpts" in value;
  }
  function initCustomFormatter() {
    if (typeof window === "undefined") {
      return;
    }
    const vueStyle = { style: "color:#3ba776" };
    const numberStyle = { style: "color:#1677ff" };
    const stringStyle = { style: "color:#f5222d" };
    const keywordStyle = { style: "color:#eb2f96" };
    const formatter = {
      __vue_custom_formatter: true,
      header(obj) {
        if (!isObject(obj)) {
          return null;
        }
        if (obj.__isVue) {
          return ["div", vueStyle, `VueInstance`];
        } else if (isRef(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, genRefFlag(obj)],
            "<",
            // avoid debugger accessing value affecting behavior
            formatValue("_value" in obj ? obj._value : obj),
            `>`
          ];
        } else if (isReactive(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow(obj) ? "ShallowReactive" : "Reactive"],
            "<",
            formatValue(obj),
            `>${isReadonly(obj) ? ` (readonly)` : ``}`
          ];
        } else if (isReadonly(obj)) {
          return [
            "div",
            {},
            ["span", vueStyle, isShallow(obj) ? "ShallowReadonly" : "Readonly"],
            "<",
            formatValue(obj),
            ">"
          ];
        }
        return null;
      },
      hasBody(obj) {
        return obj && obj.__isVue;
      },
      body(obj) {
        if (obj && obj.__isVue) {
          return [
            "div",
            {},
            ...formatInstance(obj.$)
          ];
        }
      }
    };
    function formatInstance(instance) {
      const blocks = [];
      if (instance.type.props && instance.props) {
        blocks.push(createInstanceBlock("props", toRaw(instance.props)));
      }
      if (instance.setupState !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("setup", instance.setupState));
      }
      if (instance.data !== EMPTY_OBJ) {
        blocks.push(createInstanceBlock("data", toRaw(instance.data)));
      }
      const computed2 = extractKeys(instance, "computed");
      if (computed2) {
        blocks.push(createInstanceBlock("computed", computed2));
      }
      const injected2 = extractKeys(instance, "inject");
      if (injected2) {
        blocks.push(createInstanceBlock("injected", injected2));
      }
      blocks.push([
        "div",
        {},
        [
          "span",
          {
            style: keywordStyle.style + ";opacity:0.66"
          },
          "$ (internal): "
        ],
        ["object", { object: instance }]
      ]);
      return blocks;
    }
    function createInstanceBlock(type, target) {
      target = extend({}, target);
      if (!Object.keys(target).length) {
        return ["span", {}];
      }
      return [
        "div",
        { style: "line-height:1.25em;margin-bottom:0.6em" },
        [
          "div",
          {
            style: "color:#476582"
          },
          type
        ],
        [
          "div",
          {
            style: "padding-left:1.25em"
          },
          ...Object.keys(target).map((key) => {
            return [
              "div",
              {},
              ["span", keywordStyle, key + ": "],
              formatValue(target[key], false)
            ];
          })
        ]
      ];
    }
    function formatValue(v, asRaw = true) {
      if (typeof v === "number") {
        return ["span", numberStyle, v];
      } else if (typeof v === "string") {
        return ["span", stringStyle, JSON.stringify(v)];
      } else if (typeof v === "boolean") {
        return ["span", keywordStyle, v];
      } else if (isObject(v)) {
        return ["object", { object: asRaw ? toRaw(v) : v }];
      } else {
        return ["span", stringStyle, String(v)];
      }
    }
    function extractKeys(instance, type) {
      const Comp = instance.type;
      if (isFunction(Comp)) {
        return;
      }
      const extracted = {};
      for (const key in instance.ctx) {
        if (isKeyOfType(Comp, key, type)) {
          extracted[key] = instance.ctx[key];
        }
      }
      return extracted;
    }
    function isKeyOfType(Comp, key, type) {
      const opts = Comp[type];
      if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
        return true;
      }
      if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
        return true;
      }
      if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
        return true;
      }
    }
    function genRefFlag(v) {
      if (isShallow(v)) {
        return `ShallowRef`;
      }
      if (v.effect) {
        return `ComputedRef`;
      }
      return `Ref`;
    }
    if (window.devtoolsFormatters) {
      window.devtoolsFormatters.push(formatter);
    } else {
      window.devtoolsFormatters = [formatter];
    }
  }
  /**
  * vue v3.5.13
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  function initDev() {
    {
      initCustomFormatter();
    }
  }
  {
    initDev();
  }
  var Message;
  ((Message2) => {
    ((Channel2) => {
      Channel2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Channel2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Channel || (Message2.Channel = {}));
    ((Port2) => {
      Port2["INJECT_CONTENT"] = "INJECT_CONTENT";
      Port2["CONTENT_BG"] = "CONTENT_BG";
      Port2["BG_POPUP"] = "BG_POPUP";
    })(Message2.Port || (Message2.Port = {}));
    ((MessageType2) => {
      MessageType2["REQUEST"] = "REQUEST";
      MessageType2["APPROVE"] = "APPROVE";
      MessageType2["EVENT"] = "EVENT";
      MessageType2["CONNECTION_READY"] = "CONNECTION_READY";
    })(Message2.MessageType || (Message2.MessageType = {}));
    ((MessageFrom2) => {
      MessageFrom2["INJECTED"] = "INJECTED";
      MessageFrom2["CONTENT"] = "CONTENT";
      MessageFrom2["BACKGROUND"] = "BACKGROUND";
      MessageFrom2["POPUP"] = "POPUP";
      MessageFrom2["SETTINGS_PAGE"] = "settings_page";
    })(Message2.MessageFrom || (Message2.MessageFrom = {}));
    ((MessageTo2) => {
      MessageTo2["INJECTED"] = "INJECTED";
      MessageTo2["CONTENT"] = "CONTENT";
      MessageTo2["BACKGROUND"] = "BACKGROUND";
      MessageTo2["POPUP"] = "POPUP";
    })(Message2.MessageTo || (Message2.MessageTo = {}));
    ((MessageAction2) => {
      MessageAction2["GET_APPROVE_DATA"] = "GET_APPROVE_DATA";
      MessageAction2["GET_APPROVE_DATA_RESPONSE"] = "GET_APPROVE_DATA_RESPONSE";
      MessageAction2["APPROVE_RESPONSE"] = "APPROVE_RESPONSE";
      MessageAction2["REJECT_RESPONSE"] = "REJECT_RESPONSE";
      MessageAction2["REQUEST_ACCOUNTS"] = "REQUEST_ACCOUNTS";
      MessageAction2["GET_ACCOUNTS"] = "GET_ACCOUNTS";
      MessageAction2["GET_NETWORK"] = "GET_NETWORK";
      MessageAction2["SWITCH_NETWORK"] = "SWITCH_NETWORK";
      MessageAction2["GET_PUBLIC_KEY"] = "GET_PUBLIC_KEY";
      MessageAction2["BUILD_BATCH_SELL_ORDER"] = "BUILD_BATCH_SELL_ORDER";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT"] = "SPLIT_BATCH_SIGNED_PSBT";
      MessageAction2["SPLIT_BATCH_SIGNED_PSBT_SATSNET"] = "SPLIT_BATCH_SIGNED_PSBT_SATSNET";
      MessageAction2["GET_BALANCE"] = "GET_BALANCE";
      MessageAction2["SEND_BITCOIN"] = "SEND_BITCOIN";
      MessageAction2["SIGN_MESSAGE"] = "SIGN_MESSAGE";
      MessageAction2["SIGN_PSBT"] = "SIGN_PSBT";
      MessageAction2["SIGN_PSBTS"] = "SIGN_PSBTS";
      MessageAction2["PUSH_TX"] = "PUSH_TX";
      MessageAction2["PUSH_PSBT"] = "PUSH_PSBT";
      MessageAction2["GET_INSCRIPTIONS"] = "GET_INSCRIPTIONS";
      MessageAction2["SEND_INSCRIPTION"] = "SEND_INSCRIPTION";
      MessageAction2["FINALIZE_SELL_ORDER"] = "FINALIZE_SELL_ORDER";
      MessageAction2["MERGE_BATCH_SIGNED_PSBT"] = "MERGE_BATCH_SIGNED_PSBT";
      MessageAction2["ADD_INPUTS_TO_PSBT"] = "ADD_INPUTS_TO_PSBT";
      MessageAction2["ADD_OUTPUTS_TO_PSBT"] = "ADD_OUTPUTS_TO_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT"] = "EXTRACT_TX_FROM_PSBT";
      MessageAction2["EXTRACT_TX_FROM_PSBT_SATSNET"] = "EXTRACT_TX_FROM_PSBT_SATSNET";
      MessageAction2["BACKGROUND_MESSAGE"] = "BACKGROUND_MESSAGE";
      MessageAction2["BACKGROUND_RECONNECT"] = "BACKGROUND_RECONNECT";
      MessageAction2["EVENT_MESSAGE"] = "EVENT_MESSAGE";
      MessageAction2["CONNECTION_CHECK"] = "CONNECTION_CHECK";
      MessageAction2["SPLIT_ASSET"] = "SPLIT_ASSET";
      MessageAction2["BATCH_SEND_ASSETS_SATSNET"] = "BATCH_SEND_ASSETS_SATSNET";
      MessageAction2["LOCK_UTXO"] = "LOCK_UTXO";
      MessageAction2["LOCK_UTXO_SATSNET"] = "LOCK_UTXO_SATSNET";
      MessageAction2["UNLOCK_UTXO"] = "UNLOCK_UTXO";
      MessageAction2["UNLOCK_UTXO_SATSNET"] = "UNLOCK_UTXO_SATSNET";
      MessageAction2["GET_ALL_LOCKED_UTXO"] = "GET_ALL_LOCKED_UTXO";
      MessageAction2["GET_ALL_LOCKED_UTXO_SATSNET"] = "GET_ALL_LOCKED_UTXO_SATSNET";
      MessageAction2["LOCK_TO_CHANNEL"] = "LOCK_TO_CHANNEL";
      MessageAction2["UNLOCK_FROM_CHANNEL"] = "UNLOCK_FROM_CHANNEL";
      MessageAction2["GET_UTXOS"] = "GET_UTXOS";
      MessageAction2["GET_UTXOS_SATSNET"] = "GET_UTXOS_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET"] = "GET_UTXOS_WITH_ASSET";
      MessageAction2["GET_UTXOS_WITH_ASSET_SATSNET"] = "GET_UTXOS_WITH_ASSET_SATSNET";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2"] = "GET_UTXOS_WITH_ASSET_V2";
      MessageAction2["GET_UTXOS_WITH_ASSET_V2_SATSNET"] = "GET_UTXOS_WITH_ASSET_V2_SATSNET";
      MessageAction2["GET_ASSET_AMOUNT"] = "GET_ASSET_AMOUNT";
      MessageAction2["GET_ASSET_AMOUNT_SATSNET"] = "GET_ASSET_AMOUNT_SATSNET";
      MessageAction2["ENV_CHANGED"] = "ENV_CHANGED";
      MessageAction2["GET_TICKER_INFO"] = "GET_TICKER_INFO";
    })(Message2.MessageAction || (Message2.MessageAction = {}));
  })(Message || (Message = {}));
  injected;
  const definition = defineUnlistedScript(() => {
    class Sat20 {
      constructor() {
        __publicField(this, "eventListeners", {});
        __publicField(this, "tickerCache", {});
        __publicField(this, "on", (event, handler) => {
          if (!this.eventListeners[event]) {
            this.eventListeners[event] = [];
          }
          this.eventListeners[event].push(handler);
        });
        __publicField(this, "removeListener", (event, handler) => {
          if (this.eventListeners[event]) {
            this.eventListeners[event] = this.eventListeners[event].filter(
              (h) => h !== handler
            );
          }
        });
        window.addEventListener("message", (event) => {
          const { type, data, event: eventName, metadata = {} } = event.data || {};
          const { to } = metadata;
          if (to !== Message.MessageTo.INJECTED) return;
          if (type === Message.MessageType.EVENT && eventName) {
            const listeners = this.eventListeners[eventName];
            if (listeners) {
              listeners.forEach((handler) => handler(data));
            }
          }
        });
      }
      send({ data, type, action }) {
        return new Promise((resolve, reject) => {
          const channel = new BroadcastChannel(Message.Channel.INJECT_CONTENT);
          const _messageId = `msg_${type}_${action}_${Date.now()}`;
          const listener = (event) => {
            console.log("Content Script response:", event.data);
            const { type: type2, data: data2, error, metadata = {} } = event.data || {};
            const { messageId, to } = metadata;
            if (![
              Message.MessageType.APPROVE,
              Message.MessageType.REQUEST
            ].includes(type2) && to !== Message.MessageTo.INJECTED)
              return;
            if (messageId === _messageId) {
              if (data2) {
                resolve(data2);
              }
              if (error) {
                reject(new Error(error.message));
              }
              channel.removeEventListener("message", listener);
              channel.close();
            }
          };
          channel.addEventListener("message", listener);
          window.postMessage({
            metadata: {
              origin: window.location.origin,
              messageId: _messageId,
              from: Message.MessageFrom.INJECTED,
              to: Message.MessageTo.BACKGROUND
            },
            type,
            action,
            data
          });
          setTimeout(() => {
            channel.removeEventListener("message", listener);
            channel.close();
            reject(new Error("Content Script response timeout"));
          }, 5e6);
        });
      }
      async requestAccounts() {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.REQUEST_ACCOUNTS
        });
      }
      async getAccounts() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_ACCOUNTS
        });
      }
      async getNetwork() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_NETWORK
        });
      }
      async switchNetwork(network) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SWITCH_NETWORK,
          data: { network }
        });
      }
      async getPublicKey() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_PUBLIC_KEY
        });
      }
      async buildBatchSellOrder_SatsNet(utxos, address, network) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.BUILD_BATCH_SELL_ORDER,
          data: { utxos, address, network }
        });
      }
      async splitBatchSignedPsbt_SatsNet(signedHex, network) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.SPLIT_BATCH_SIGNED_PSBT_SATSNET,
          data: { signedHex, network }
        });
      }
      async finalizeSellOrder_SatsNet(psbtHex, utxos, buyerAddress, serverAddress, network, serviceFee, networkFee) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.FINALIZE_SELL_ORDER,
          data: {
            psbtHex,
            utxos,
            buyerAddress,
            serverAddress,
            network,
            serviceFee,
            networkFee
          }
        });
      }
      async mergeBatchSignedPsbt_SatsNet(psbts, network) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.MERGE_BATCH_SIGNED_PSBT,
          data: { psbts, network }
        });
      }
      async addInputsToPsbt(psbtHex, utxos) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.ADD_INPUTS_TO_PSBT,
          data: { psbtHex, utxos }
        });
      }
      async addOutputsToPsbt(psbtHex, utxos) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.ADD_OUTPUTS_TO_PSBT,
          data: { psbtHex, utxos }
        });
      }
      async splitAsset(assetKey, amount) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SPLIT_ASSET,
          data: { asset_key: assetKey, amount }
        });
      }
      async batchSendAssets_SatsNet(assetName, amt, n) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.BATCH_SEND_ASSETS_SATSNET,
          data: { assetName, amt, n }
        });
      }
      async getBalance() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_BALANCE
        });
      }
      async sendBitcoin(address, amount, options) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SEND_BITCOIN,
          data: { address, amount, options }
        });
      }
      async signMessage(message, type) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SIGN_MESSAGE,
          data: { message, type }
        });
      }
      async signPsbt(psbtHex, options) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SIGN_PSBT,
          data: { psbtHex, options }
        });
      }
      async signPsbts(psbtHexs, options) {
        return this.send({
          type: Message.MessageType.APPROVE,
          action: Message.MessageAction.SIGN_PSBTS,
          data: { psbtHexs, options }
        });
      }
      async pushTx(rawtx, options) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.PUSH_TX,
          data: { rawtx, options }
        });
      }
      async pushPsbt(psbtHex, options) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.PUSH_PSBT,
          data: { psbtHex, options }
        });
      }
      async extractTxFromPsbt(psbtHex, chain) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.EXTRACT_TX_FROM_PSBT,
          data: { psbtHex, chain }
        });
      }
      async extractTxFromPsbt_SatsNet(psbtHex) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.EXTRACT_TX_FROM_PSBT_SATSNET,
          data: { psbtHex }
        });
      }
      async lockUtxo(address, utxo, reason) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.LOCK_UTXO,
          data: { address, utxo, reason }
        });
      }
      async lockUtxo_SatsNet(address, utxo, reason) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.LOCK_UTXO_SATSNET,
          data: { address, utxo, reason }
        });
      }
      async unlockUtxo(address, utxo) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.UNLOCK_UTXO,
          data: { address, utxo }
        });
      }
      async unlockUtxo_SatsNet(address, utxo) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.UNLOCK_UTXO_SATSNET,
          data: { address, utxo }
        });
      }
      async getAllLockedUtxo(address) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_ALL_LOCKED_UTXO,
          data: { address }
        });
      }
      async getAllLockedUtxo_SatsNet(address) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_ALL_LOCKED_UTXO_SATSNET,
          data: { address }
        });
      }
      async getUtxos() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS
        });
      }
      async getUtxos_SatsNet() {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS_SATSNET
        });
      }
      async getUtxosWithAsset(address, assetName, amt) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS_WITH_ASSET,
          data: { address, assetName, amt }
        });
      }
      async getUtxosWithAsset_SatsNet(address, assetName, amt) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS_WITH_ASSET_SATSNET,
          data: { address, assetName, amt }
        });
      }
      async getUtxosWithAssetV2(address, assetName, amt) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS_WITH_ASSET_V2,
          data: { address, assetName, amt }
        });
      }
      async getUtxosWithAssetV2_SatsNet(address, assetName, amt) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_UTXOS_WITH_ASSET_V2_SATSNET,
          data: { address, assetName, amt }
        });
      }
      async getAssetAmount(address, assetName) {
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_ASSET_AMOUNT,
          data: { address, assetName }
        });
      }
      async getAssetAmount_SatsNet(address, assetName) {
        console.log(Message.MessageAction);
        return this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_ASSET_AMOUNT_SATSNET,
          data: { address, assetName }
        });
      }
      async getTickerInfo(asset) {
        if (this.tickerCache[asset]) {
          return Promise.resolve(this.tickerCache[asset]);
        }
        const result2 = await this.send({
          type: Message.MessageType.REQUEST,
          action: Message.MessageAction.GET_TICKER_INFO,
          data: { asset }
        });
        this.tickerCache[asset] = result2;
        return result2;
      }
    }
    const sat20 = new Sat20();
    window.sat20 = sat20;
  });
  injected;
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") {
      const message = args.shift();
      method(`[wxt] ${message}`, ...args);
    } else {
      method("[wxt]", ...args);
    }
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (async () => {
    try {
      initPlugins();
      return await definition.main();
    } catch (err) {
      logger.error(
        `The unlisted script "${"injected"}" crashed on startup!`,
        err
      );
      throw err;
    }
  })();
  return result;
}();
injected;
